
using ORKFramework;
using ORKFramework.Events;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Damage Zone")]
	public class DamageZone : DamageBase
	{
		public float damageFactor = 1.0f;
		
		
		// block settings
		public bool blockDamage = false;
		
		public bool showBlockNotification = false;
		
		
		// sound settings
		public bool playSound = false;
		
		public PlayAudioCombatant sound;
	
		public void Damage(BaseAction action)
		{
			if(this.playSound && this.sound != null)
			{
				this.sound.Play(this.combatant);
			}
			
			if(this.blockDamage)
			{
				if(this.showBlockNotification)
				{
					ORK.BattleTexts.blockTextSettings.ShowText("", this.gameObject);
				}
			}
			else if(TargetHelper.CheckDeath(this.combatant, action.TargetDead))
			{
				List<Combatant> target = new List<Combatant>();
				target.Add(this.combatant);
				
				DamageDealerActivation ddActivation = action.GetDamageDealerActivation();
				if(ddActivation != null && ddActivation.animate)
				{
					List<BattleEvent> events = new List<BattleEvent>();
					ddActivation.GetAnimations(ref events, action.user);
					new DamageDealerAction(action, target, events).PerformAction();
				}
				else
				{
					action.Calculate(target, this.damageFactor, true);
				}
			}
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "DamageZone.psd");
		}
	}
}
