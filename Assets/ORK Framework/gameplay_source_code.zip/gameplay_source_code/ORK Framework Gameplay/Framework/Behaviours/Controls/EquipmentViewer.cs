
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Equipment Viewer")]
	public class EquipmentViewer : MonoBehaviour
	{
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int partID = 0;
		
		public bool setScale = false;
		
		public Vector3 equipmentScale = Vector3.one;
		
		
		// renderer settings
		public bool useChildRenderer = false;
		
		public string childRenderer = "";
		
		public bool useMaterialIndex = false;
		
		public int materialIndex = 0;
		
		
		// display conditions
		public bool onlyCombatantBattle = false;
		
		public GameState gameState = new GameState();
		
		public bool checkObjectVariables = false;
		
		public VariableCondition variableCondition = new VariableCondition();
		
		
		// child linking
		public string[] childName = new string[0];
	
		public string[] linkTo = new string[0];
		
		
		// ingame
		private bool displayed = false;
		
		private int lastID = -1;
	
		private EquipSet lastType = EquipSet.None;
	
		private GameObject prefabInstance;
		
		private Combatant combatant = null;
		
		private bool combatantChecked = false;
		
		private Transform[] childs = new Transform[0];
	
		private Transform[] links = new Transform[0];
		
		
		// materials
		private Renderer usedRenderer;
		
		private Material baseMaterial;
		
		private Material currentMaterial;
		
		void Start()
		{
			this.SetCombatant();
		}
		
		private void SetCombatant()
		{
			this.combatant = ComponentHelper.GetCombatant(this.gameObject);
			if(this.combatant != null)
			{
				this.combatantChecked = true;
				
				if(this.useChildRenderer)
				{
					Transform tmp = this.transform.root.Find(this.childRenderer);
					if(tmp == null)
					{
						tmp = this.transform.root;
					}
					this.usedRenderer = tmp.GetComponent<Renderer>();
				}
				
				if(this.usedRenderer != null)
				{
					if(this.useMaterialIndex && this.materialIndex < this.usedRenderer.materials.Length)
					{
						this.baseMaterial = this.usedRenderer.materials[this.materialIndex];
					}
					else
					{
						this.baseMaterial = this.usedRenderer.material;
					}
				}
				
				this.combatant.Equipment.Changed += this.EquipmentChanged;
				this.CheckEquipment();
			}
		}
		
		void OnDestroy()
		{
			if(this.combatant != null)
			{
				this.combatant.Equipment.Changed -= this.EquipmentChanged;
			}
		}
		
		void Update()
		{
			if(!this.combatantChecked)
			{
				this.CheckEquipment();
			}
			this.CheckVisible();
		}
		
		public void EquipmentChanged(Combatant c)
		{
			if(this.combatant == c)
			{
				this.CheckEquipment();
			}
		}
		
		public void CheckEquipment()
		{
			if(this.combatant != null)
			{
				if(this.combatant.Equipment[this.partID].Equipped || this.combatant.Equipment[this.partID].Linked)
				{
					int tmpPartID = this.partID;
					this.combatant.Equipment[tmpPartID].GetRealPartID(ref tmpPartID);
					EquipShortcut equip = this.combatant.Equipment[tmpPartID].Equipment;
					
					if(!equip.Type.Equals(this.lastType) || equip.ID != this.lastID)
					{
						if(this.prefabInstance)
						{
							GameObject.Destroy(this.prefabInstance);
						}
						if(this.usedRenderer != null)
						{
							this.SetMaterial(this.baseMaterial);
							this.currentMaterial = null;
						}
						
						this.lastType = equip.Type;
						this.lastID = equip.ID;
							
						if(equip.Setting != null)
						{
							this.displayed = true;
							
							if(equip.Setting.viewerMaterial != null && 
								this.usedRenderer != null)
							{
								this.currentMaterial = equip.Setting.viewerMaterial;
								this.SetMaterial(equip.Setting.viewerMaterial);
							}
							
							this.prefabInstance = equip.Setting.GetViewerPrefabInstance();
							if(this.prefabInstance != null)
							{
								TransformHelper.Mount(this.transform, this.prefabInstance.transform, true, 
									equip.Setting.viewerPosOff, true, equip.Setting.viewerRotOff, 
									this.setScale, this.equipmentScale);
								
								if(this.childName.Length > 0)
								{
									this.childs = new Transform[this.childName.Length];
									this.links = new Transform[this.childName.Length];
									
									for(int i=0; i<this.childName.Length; i++)
									{
										this.childs[i] = this.prefabInstance.transform.Find(this.childName[i]);
										this.links[i] = this.transform.root.Find(this.linkTo[i]);
									}
								}
								
								this.CheckVisible();
							}
						}
					}
				}
				else if(!EquipSet.None.Equals(this.lastType))
				{
					if(this.prefabInstance)
					{
						GameObject.Destroy(this.prefabInstance);
					}
					if(this.usedRenderer != null)
					{
						this.SetMaterial(this.baseMaterial);
					}
					
					this.lastType = EquipSet.None;
					this.lastID = -1;
				}
			}
			else if(!this.combatantChecked)
			{
				this.combatantChecked = true;
				this.SetCombatant();
				
				if(this.combatant == null)
				{
					GameObject.Destroy(this);
				}
			}
		}
		
		public void CheckVisible()
		{
			if(this.prefabInstance != null || this.currentMaterial != null)
			{
				bool visible = this.gameState.Check() && 
					(!this.onlyCombatantBattle || 
						Consider.No.Equals(this.gameState.inBattle) || 
						this.combatant.InBattle) && 
					(this.variableCondition.gameVariable.Length == 0 || 
						this.CheckVariables());
				
				if(!this.displayed && visible)
				{
					if(this.prefabInstance != null)
					{
						this.prefabInstance.SetActive(true);
					}
					
					if(this.usedRenderer != null && this.currentMaterial != null)
					{
						this.SetMaterial(this.currentMaterial);
					}
				}
				else if(this.displayed && !visible)
				{
					if(this.prefabInstance != null)
					{
						this.prefabInstance.SetActive(false);
					}
					
					if(this.usedRenderer != null && this.currentMaterial != null)
					{
						this.SetMaterial(this.baseMaterial);
					}
				}
				
				this.displayed = visible;
			}
		}
		
		public bool CheckVariables()
		{
			if(this.checkObjectVariables)
			{
				ObjectVariablesComponent comp = ComponentHelper.
					GetInChildren<ObjectVariablesComponent>(this.gameObject.transform.root.gameObject);
				if(comp != null)
				{
					return this.variableCondition.CheckVariables(comp.GetHandler());
				}
			}
			else
			{
				return this.variableCondition.CheckVariables();
			}
			return false;
		}
		
		void LateUpdate()
		{
			if(!ORK.Game.Paused && this.prefabInstance != null && this.childs.Length > 0)
			{
				for(int i=0; i<this.childs.Length; i++)
				{
					if(this.childs[i] != null && this.links[i] != null)
					{
						this.childs[i].position = this.links[i].position;
						this.childs[i].rotation = this.links[i].rotation;
					}
				}
			}
		}
	
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "EquipmentViewer.psd");
		}
		
		private void SetMaterial(Material mat)
		{
			if(this.usedRenderer != null)
			{
				if(this.useMaterialIndex && 
					this.materialIndex < this.usedRenderer.materials.Length)
				{
					Material[] mats = this.usedRenderer.materials;
					mats[this.materialIndex] = mat;
					this.usedRenderer.materials = mats;
				}
				else
				{
					this.usedRenderer.material = mat;
				}
			}
		}
	}
}
