
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class GUIBoxComponent : MonoBehaviour
	{
		// box/gui
		private ORKGUILayer guiLayer;
		
		private GUIBox box;
		
		private RectTransform containerTransform;
		
		private RectTransform boxTransform;
		
		private CanvasGroup canvasGroup;
		
		
		// updates
		private bool contentUpdated = false;
		
		private Color lastColor;
		
		private CanvasRenderer[] canvasRenderer;
		
		private bool[] doFlash;
		
		public bool ContentUpdated
		{
			get{ return this.contentUpdated;}
			set
			{
				this.canvasRenderer = null;
				this.doFlash = null;
				this.contentUpdated = value;
			}
		}
		
		public void Init(GUIBox guiBox, RectTransform containerTransform, RectTransform boxTransform, CanvasGroup canvasGroup)
		{
			this.box = guiBox;
			this.containerTransform = containerTransform;
			this.boxTransform = boxTransform;
			this.canvasGroup = canvasGroup;
			
			this.guiLayer = ORK.GUILayers.Get(this.box.Settings.layerID);
			
			this.UpdateBox();
		}
		
		void Update()
		{
			this.UpdateBox();
		}
		
		public void UpdateBox()
		{
			if(this.box != null && this.box.Content != null)
			{
				// scale display
				if(this.box.currentScale != Vector2.one)
				{
					Vector3 guiScale = this.guiLayer.useFullScreen ? 
						new Vector3(ORK.Core.RealScale.x * this.box.currentScale.x, 
							ORK.Core.RealScale.y * this.box.currentScale.y, 1) :
						new Vector3(ORK.Core.GUIScale.x * this.box.currentScale.x, 
							ORK.Core.GUIScale.y * this.box.currentScale.y, 1);
					if(guiScale.x <= 0.0001f)
					{
						guiScale.x = 0.0001f;
					}
					if(guiScale.y <= 0.0001f)
					{
						guiScale.y = 0.0001f;
					}
					
					Vector3 tmpPos = GUIHelper.GetRectAnchor(this.box.windowRect, this.box.scaleAnchor);
					tmpPos.x *= ORK.Core.GUIScale.x;
					tmpPos.y *= -ORK.Core.GUIScale.y;
					
					// set position of container
					this.containerTransform.anchoredPosition = Matrix4x4.TRS(
						(this.guiLayer.useFullScreen ? Vector3.zero : ORK.Core.NewUITranslate) + tmpPos - 
							new Vector3(tmpPos.x * this.box.currentScale.x, tmpPos.y * this.box.currentScale.y, 0), 
						Quaternion.identity, guiScale).MultiplyPoint3x4(new Vector2(
								this.box.windowRect.x, 
								-this.box.windowRect.y));
					
					// set size of box
					this.boxTransform.sizeDelta = new Vector2(
						this.box.windowRect.width, 
						this.box.windowRect.height);
					
					// set scale of container
					this.containerTransform.localScale = guiScale;
				}
				// non scale display
				else
				{
					// set position of container
					if(this.guiLayer.useFullScreen)
					{
						this.containerTransform.anchoredPosition = ORK.Core.FullScreenMatrix.MultiplyPoint3x4(
							new Vector2(
								this.box.windowRect.x, 
								-this.box.windowRect.y));
					}
					else
					{
						this.containerTransform.anchoredPosition = ORK.Core.NewUIMatrix.MultiplyPoint3x4(
							new Vector2(
								this.box.windowRect.x, 
								-this.box.windowRect.y));
					}
					
					
					// set size of box
					this.boxTransform.sizeDelta = new Vector2(
						this.box.windowRect.width, 
						this.box.windowRect.height);
					
					// set scale of container
					this.containerTransform.localScale = this.guiLayer.GetScale();
				}
				
				// set color
				this.UpdateColors();
				
				// interactions
				if(this.contentUpdated)
				{
					this.canvasGroup.interactable = !this.canvasGroup.interactable;
				}
				this.canvasGroup.interactable = this.box.Controlable && 
					(!this.box.focusable || this.box.Focused);
				
				this.contentUpdated = false;
			}
		}
		
		public void UpdateColors()
		{
			if(this.canvasRenderer == null)
			{
				this.canvasRenderer = this.GetComponentsInChildren<CanvasRenderer>();
				this.doFlash = new bool[this.canvasRenderer.Length];
				for(int i=0; i<this.canvasRenderer.Length; i++)
				{
					this.doFlash[i] = this.canvasRenderer[i].GetComponent<NoFlashComponent>() == null;
				}
			}
			
			if(this.box.doFlash)
			{
				for(int i=0; i<this.canvasRenderer.Length; i++)
				{
					if(this.doFlash[i] && this.canvasRenderer[i] != null)
					{
						this.canvasRenderer[i].SetColor(this.box.flashColor);
					}
				}
				this.lastColor = this.box.color;
			}
			else
			{
				Color color = this.box.controlable && this.box.focusable && 
					!this.box.Focused && this.box.InactiveColor.setColor ? 
					this.box.InactiveColor.color : this.box.color;
				
				if(this.lastColor != color || this.contentUpdated)
				{
					for(int i=0; i<this.canvasRenderer.Length; i++)
					{
						if(this.canvasRenderer[i] != null)
						{
							this.canvasRenderer[i].SetColor(color);
						}
					}
					this.lastColor = color;
				}
			}
		}
	}
}
