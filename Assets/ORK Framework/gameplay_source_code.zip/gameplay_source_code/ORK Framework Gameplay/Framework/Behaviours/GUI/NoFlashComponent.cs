
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class NoFlashComponent : MonoBehaviour
	{
		
	}
}
