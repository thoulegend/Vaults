
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	public abstract class BaseColliderZone : MonoBehaviour
	{
		public bool IsWithin(Vector3 point)
		{
			Collider collider = this.GetComponent<Collider>();
			if(collider != null)
			{
				point.y = collider.bounds.center.y;
				if(collider.bounds.Contains(point))
				{
					point.y = collider.bounds.max.y + 1;
					RaycastHit hit;
					if(collider.Raycast(new Ray(point, -Vector3.up), out hit, collider.bounds.size.y))
					{
						return true;
					}
				}
			}
			else
			{
				Collider2D collider2D = this.GetComponent<Collider2D>();
				if(collider2D != null)
				{
					return collider2D.OverlapPoint(point);
				}
			}
			return false;
		}
	}
}
