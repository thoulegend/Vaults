
using UnityEngine;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class ChangeField : BaseData
	{
		[ORKEditorHelp("Field Name", "The name of the field that will be changed.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string fieldName = "";
		
		[ORKEditorHelp("Is Property", "Change the value of a property.\n" +
			"If disabled, the value of a field will be changed.", "")]
		public bool isProperty = false;
		
		[ORKEditorHelp("Field Type", "Select the type of the field.", "")]
		public ParameterType type = ParameterType.String;
		
		[ORKEditorHelp("String Value", "Define the string the field will be set to.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("type", ParameterType.String, endCheckGroup=true)]
		public string stringValue = "";
		
		[ORKEditorHelp("Bool Value", "Define the bool the field will be set to.", "")]
		[ORKEditorLayout("type", ParameterType.Bool, endCheckGroup=true)]
		public bool boolValue = false;
		
		[ORKEditorHelp("Int Value", "Define the int the field will be set to.", "")]
		[ORKEditorLayout("type", ParameterType.Int, endCheckGroup=true)]
		public int intValue = 0;
		
		[ORKEditorHelp("Float Value", "Define the float the field will be set to.", "")]
		[ORKEditorLayout("type", ParameterType.Float, endCheckGroup=true)]
		public float floatValue = 0;
		
		[ORKEditorHelp("Vector2 Value", "Define the Vector2 the field will be set to.", "")]
		[ORKEditorLayout("type", ParameterType.Vector2, endCheckGroup=true)]
		public Vector2 vector2Value = Vector2.zero;
		
		[ORKEditorHelp("Vector3 Value", "Define the Vector3 the field will be set to.", "")]
		[ORKEditorLayout("type", ParameterType.Vector3, endCheckGroup=true)]
		public Vector3 vector3Value = Vector3.zero;
		
		public ChangeField()
		{
			
		}
		
		public System.Object GetValue()
		{
			if(ParameterType.String.Equals(this.type))
			{
				return this.stringValue;
			}
			else if(ParameterType.Bool.Equals(this.type))
			{
				return this.boolValue;
			}
			else if(ParameterType.Int.Equals(this.type))
			{
				return this.intValue;
			}
			else if(ParameterType.Float.Equals(this.type))
			{
				return this.floatValue;
			}
			else if(ParameterType.Vector2.Equals(this.type))
			{
				return this.vector2Value;
			}
			else if(ParameterType.Vector3.Equals(this.type))
			{
				return this.vector3Value;
			}
			return null;
		}
		
		public void Change(System.Object instance, System.Type instanceType)
		{
			if(this.fieldName != "")
			{
				if(this.isProperty)
				{
					PropertyInfo propertyInfo = instanceType.GetProperty(this.fieldName);
					if(propertyInfo != null)
					{
						try
						{
							propertyInfo.SetValue(instance, this.GetValue(), null);
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Property change failed (" + instanceType + "): " + 
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
					}
				}
				else
				{
					FieldInfo fieldInfo = instanceType.GetField(this.fieldName, 
						BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance );
					if(fieldInfo != null)
					{
						try
						{
							fieldInfo.SetValue(instance, this.GetValue());
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Field change failed (" + instanceType + "): " + 
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
					}
				}
			}
		}
	}
}
