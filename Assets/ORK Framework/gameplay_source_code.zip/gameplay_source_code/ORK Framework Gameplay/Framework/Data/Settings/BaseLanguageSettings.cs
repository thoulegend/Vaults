
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public abstract class BaseLanguageSettings : BaseSettings
	{
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		/// <summary>
		/// Gets the description.
		/// </summary>
		/// <returns>
		/// The description.
		/// </returns>
		/// <param name='index'>
		/// The data index.
		/// </param>
		public abstract string GetDescription(int index);
		
		/// <summary>
		/// Gets the icon of a data.
		/// </summary>
		/// <returns>
		/// The icon.
		/// </returns>
		/// <param name='index'>
		/// The data index.
		/// </param>
		public abstract Texture2D GetIcon(int index);
		
		/// <summary>
		/// Gets the GUIContent of a data.
		/// </summary>
		/// <returns>
		/// The GUIContent.
		/// </returns>
		/// <param name='index'>
		/// The data index.
		/// </param>
		public GUIContent GetContent(int index)
		{
			return new GUIContent(this.GetName(index), this.GetIcon(index));
		}
	}
}
