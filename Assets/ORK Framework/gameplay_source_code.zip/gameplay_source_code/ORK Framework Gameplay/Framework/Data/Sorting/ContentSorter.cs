
using System.Collections.Generic;

namespace ORKFramework
{
	public class ContentSorter : BaseData
	{
		[ORKEditorHelp("Sort By", "Select how the data will be sorted:\n" +
			"- None: The data isn't sorted and will be listet as it appears.\n" +
			"- Name: The data is sorted by name (e.g. item name, ability name).\n" +
			"- ID: The data is sorted by ID (i.e. the index of the data).\n" +
			"- Type: The data is sorted by type (e.g. item type, ability type).\n" +
			"- Type Name: The data is first sorted by type, then by name.\n" +
			"- Type ID: The data is first sorted by type, then by ID.", "")]
		public ContentSorting sorting = ContentSorting.Name;
		
		[ORKEditorHelp("Invert Order", "The data is sorted in inverted order.", "")]
		public bool invert = false;
		
		public ContentSorter()
		{
			
		}
		
		
		/*
		============================================================================
		Sort functions
		============================================================================
		*/
		public void SortContent(ref List<IContent> list)
		{
			if(ContentSorting.Name.Equals(this.sorting))
			{
				list.Sort(new NameContentSorter(this.invert));
			}
			else if(ContentSorting.ID.Equals(this.sorting))
			{
				list.Sort(new IDContentSorter(this.invert));
			}
			else if(ContentSorting.Type.Equals(this.sorting))
			{
				list.Sort(new TypeContentSorter(this.invert));
			}
			else if(ContentSorting.TypeName.Equals(this.sorting))
			{
				list.Sort(new TypeNameContentSorter(this.invert));
			}
			else if(ContentSorting.TypeID.Equals(this.sorting))
			{
				list.Sort(new TypeIDContentSorter(this.invert));
			}
		}
		
		public void Sort(ref List<Area> list)
		{
			if(ContentSorting.None.Equals(this.sorting))
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(Area data in list)
				{
					tmpList.Add(data as IContent);
				}
				
				this.SortContent(ref tmpList);
				
				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as Area);
				}
			}
		}
		
		public void Sort(ref List<Log> list)
		{
			if(ContentSorting.None.Equals(this.sorting))
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(Log data in list)
				{
					tmpList.Add(data as IContent);
				}
				
				this.SortContent(ref tmpList);
				
				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as Log);
				}
			}
		}
		
		public void Sort(ref List<CraftingRecipe> list)
		{
			if(ContentSorting.None.Equals(this.sorting))
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(CraftingRecipe data in list)
				{
					tmpList.Add(data as IContent);
				}
				
				this.SortContent(ref tmpList);
				
				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as CraftingRecipe);
				}
			}
		}
		
		public void Sort(ref List<Quest> list)
		{
			if(ContentSorting.None.Equals(this.sorting))
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(Quest data in list)
				{
					tmpList.Add(data as IContent);
				}
				
				this.SortContent(ref tmpList);
				
				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as Quest);
				}
			}
		}
		
		public void Sort(ref List<BestiaryEntry> list)
		{
			if(ContentSorting.None.Equals(this.sorting))
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(BestiaryEntry data in list)
				{
					tmpList.Add(data as IContent);
				}
				
				this.SortContent(ref tmpList);
				
				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as BestiaryEntry);
				}
			}
		}
		
		public void Sort(ref List<AbilityShortcut> list)
		{
			if(ContentSorting.None.Equals(this.sorting))
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(AbilityShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}
				
				this.SortContent(ref tmpList);
				
				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as AbilityShortcut);
				}
			}
		}
		
		public void Sort(ref List<EquipShortcut> list)
		{
			if(ContentSorting.None.Equals(this.sorting))
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(EquipShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}
				
				this.SortContent(ref tmpList);
				
				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as EquipShortcut);
				}
			}
		}
		
		public void Sort(ref List<IShortcut> list)
		{
			if(ContentSorting.None.Equals(this.sorting))
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(IShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}
				
				this.SortContent(ref tmpList);
				
				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as IShortcut);
				}
			}
		}
	}
}
