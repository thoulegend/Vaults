
using System.Collections.Generic;

namespace ORKFramework
{
	public class TypeNameContentSorter : IComparer<IContent>
	{
		private bool invert = false;
		
		public TypeNameContentSorter(bool invert)
		{
			this.invert = invert;
		}
		
		public int Compare(IContent x, IContent y)
		{
			if(this.invert)
			{
				int tmp = y.TypeID.CompareTo(x.TypeID);
				if(tmp == 0)
				{
					return y.GetName().CompareTo(x.GetName());
				}
				else
				{
					return tmp;
				}
			}
			else
			{
				int tmp = x.TypeID.CompareTo(y.TypeID);
				if(tmp == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				else
				{
					return tmp;
				}
			}
		}
	}
}
