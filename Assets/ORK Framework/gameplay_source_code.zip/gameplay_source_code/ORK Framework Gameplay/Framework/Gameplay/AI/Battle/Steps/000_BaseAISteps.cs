
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	public static class AIStepHelper
	{
		public static Dictionary<System.Type, NodeInfo> GetSteps()
		{
			Dictionary<System.Type, NodeInfo> list = new Dictionary<System.Type, NodeInfo>();
			
			System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
			for(int i=0; i<assembly.Length; i++)
			{
				AIStepHelper.AddFromAssembly(assembly[i], ref list);
			}
			
			return list;
		}
		
		private static void AddFromAssembly(System.Reflection.Assembly assembly, 
			ref Dictionary<System.Type, NodeInfo> list)
		{
			System.Type[] types = assembly.GetTypes();
			for(int i=0; i<types.Length; i++)
			{
				if(types[i].Namespace == "ORKFramework.AI.Steps")
				{
					System.Object[] attr = types[i].GetCustomAttributes(typeof(ORKEditorHelpAttribute), true);
					if(attr.Length > 0)
					{
						string[] help = (attr[0] as ORKEditorHelpAttribute).text;
						
						string[] subMenu = new string[0];
						attr = types[i].GetCustomAttributes(typeof(ORKNodeInfoAttribute), true);
						if(attr.Length > 0)
						{
							subMenu = (attr[0] as ORKNodeInfoAttribute).subMenu;
						}
						list.Add(types[i], new NodeInfo(help, subMenu));
					}
				}
			}
		}
	}
	
	public abstract class BaseAIStep : CoreAIStep
	{
		[ORKEditorHelp("Enabled", "This step is enabled and will be executed.\n" +
			"If disabled, the step wont execute and the next step ('Next') will be executed.", "")]
		[ORKEditorInfo(hide=true)]
		public bool active = true;
		
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public abstract BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets);
		
		protected List<Combatant> GetTargetList(TargetType type, Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			List<Combatant> list = new List<Combatant>();
			if(TargetType.Self.Equals(type))
			{
				list.Add(user);
			}
			else if(TargetType.Ally.Equals(type))
			{
				list = allies;
			}
			else if(TargetType.Enemy.Equals(type))
			{
				list = enemies;
			}
			else if(TargetType.All.Equals(type))
			{
				list.AddRange(allies);
				list.AddRange(enemies);
			}
			return list;
		}
		
		protected List<Combatant> GetPreferredTargets(Combatant user, List<Combatant> foundTargets)
		{
			if(foundTargets.Count == 0)
			{
				List<Combatant> tmp = new List<Combatant>();
				if(user.Setting.attackLastTarget && 
					user.LastTargets != null && user.LastTargets.Count > 0)
				{
					tmp.AddRange(user.LastTargets);
				}
				return tmp;
			}
			else
			{
				return foundTargets;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "";
		}
		
		public override string GetNodeDetails()
		{
			return "";
		}
		
		public override string GetNextName(int index)
		{
			return "Next";
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}
		
		public override int GetNext(int index)
		{
			return this.next;
		}
		
		public override void SetNext(int index, int next)
		{
			this.next = next;
		}
		
		
		/*
		============================================================================
		Enable functions
		============================================================================
		*/
		public override bool IsEnabled
		{
			get{ return this.active;}
		}
	}
	
	public abstract class BaseAICheckStep : BaseAIStep
	{
		[ORKEditorInfo(hide=true)]
		public int nextFail = -1;
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Success";
			}
			else if(index == 1)
			{
				return "Failed";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return 2;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}
	}
	
	[ORKEditorHelp("Random", "Randomly executes a next step out of a list of defined steps.", "")]
	[ORKNodeInfo("Base Steps")]
	public class RandomStep : BaseAIStep
	{
		[ORKEditorInfo(hide=true, instanceCallback="buttons:randomstep")]
		public int[] random = new int[] {-1};
		
		public RandomStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			currentStep = this.random[Random.Range(0, this.random.Length)];
			return null;
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			return "Random " + index;
		}
		
		public override int GetNextCount()
		{
			return this.random.Length;
		}
		
		public override int GetNext(int index)
		{
			return this.random[index];
		}
		
		public override void SetNext(int index, int next)
		{
			this.random[index] = next;
		}
	}
	
	[ORKEditorHelp("Battle AI", "Executes another battle AI to find a battle action.\n" +
		"If no action is found, 'Next' will be executed.\n" +
		"Keep in mind that using the same battle AI can result in a loop and will ultimately crash the game.", "")]
	[ORKNodeInfo("Base Steps")]
	public class BattleAIStep : BaseAIStep
	{
		[ORKEditorHelp("Battle AI", "Select the battle AI that will be executed.", "")]
		[ORKEditorInfo(ORKDataType.BattleAI)]
		public int id = 0;
		
		public BattleAIStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			currentStep = this.next;
			if(this.id >= 0 && this.id < ORK.BattleAIs.Count)
			{
				return ORK.BattleAIs.Get(this.id).GetAction(user, allies, enemies);
			}
			else
			{
				return null;
			}
		}
	}
	
	[ORKEditorHelp("Clear Found Targets", "All found targets will be removed.", "")]
	[ORKNodeInfo("Base Steps")]
	public class ClearFoundTargetsStep : BaseAIStep
	{
		public ClearFoundTargetsStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			foundTargets.Clear();
			currentStep = this.next;
			return null;
		}
	}
	
	[ORKEditorHelp("Comment", "Leave a comment in your battle AI.\n" +
		"This step does nothing and is only for commentary purposes.", "")]
	[ORKNodeInfo("Base Steps")]
	public class CommentStep : BaseAIStep
	{
		[ORKEditorHelp("Comment", "The comment.", "")]
		[ORKEditorInfo(isTextArea=true)]
		public string comment = "";
		
		public CommentStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			currentStep = this.next;
			return null;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.comment;
		}
	}
	
	[ORKEditorHelp("Change Object Variables", "Changes a combatant's object variables " +
		"(requires an 'Object Variables' component attached to the combatant's game object).", "")]
	[ORKNodeInfo("Base Steps", "Variable Steps")]
	public class ChangeObjectVariablesStep : BaseAIStep
	{
		[ORKEditorHelp("Use Found Targets", "Change the object variables on the targets found by previous steps.\n" +
			"If disabled, you need to define the target that will be changed.", "")]
		public bool onFound = false;
		
		[ORKEditorHelp("Target", "Select which combatant'S or combatant group's object variables will be changed:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("onFound", false, endCheckGroup=true)]
		public TargetType targetType = TargetType.Ally;
		
		
		// variables
		[ORKEditorInfo(separator=true)]
		public VariableSetter change = new VariableSetter();
		
		public ChangeObjectVariablesStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			this.Change(this.onFound ? foundTargets : this.GetTargetList(this.targetType, user, allies, enemies));
			currentStep = this.next;
			return null;
		}
		
		private void Change(List<Combatant> list)
		{
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && list[i].GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.GetInChildren<ObjectVariablesComponent>(list[i].GameObject);
					if(comp != null)
					{
						this.change.SetVariables(comp.GetHandler());
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.onFound ? "Found Targets" : this.targetType.ToString();
		}
	}
}
