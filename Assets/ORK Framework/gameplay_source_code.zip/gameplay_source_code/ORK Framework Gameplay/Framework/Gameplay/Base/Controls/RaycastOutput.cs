
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class RaycastOutput
	{
		public float distance = Mathf.Infinity;
		
		public Vector3 point = Vector3.zero;
		
		public Vector3 normal = Vector3.zero;
		
		public Transform transform;
		
		public RaycastOutput()
		{
			
		}
		
		public RaycastOutput(RaycastHit hit, Vector3 origin)
		{
			this.point = hit.point;
			this.normal = hit.normal;
			this.transform = hit.transform;
			
			this.distance = Vector3.Distance(origin, this.point);
		}
		
		public RaycastOutput(RaycastHit2D hit, Vector3 origin)
		{
			this.point = hit.point;
			this.normal = hit.normal;
			this.transform = hit.transform;
			
			this.distance = Vector3.Distance(origin, this.point);
		}
	}
	
	public class RaycastOutputSorter : IComparer<RaycastOutput>
	{
		public int Compare(RaycastOutput x , RaycastOutput y)
		{
			return x.distance.CompareTo(y.distance);
	    }
	}
}
