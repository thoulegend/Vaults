
using ORKFramework;
using UnityEngine;

namespace ORKFramework
{
	public class BaseStatusRequirement : BaseData
	{
		[ORKEditorHelp("Status Needed", "Which type of status will be checked.\n" +
			"- Status Value: The selected status value will be compared to a defined value.\n" +
			"- Status Effect: The selected status effect must or mustn't be applied to the combatant.\n" +
			"- Attack Attribute: The selected attack attribute will be compared to a defined value.\n" +
			"- Defence Attribute: The combatant must have the selected defence attribute, or compares it to a defined value.\n" +
			"- Level: The combatants level (or class level) will be compared to a defined value.\n" +
			"- Ability: The combatant must have this ability.\n" +
			"- Class: The combatant must be of the selected class.\n" +
			"- Death: The combatant must be dead/alive.\n" +
			"- Weapon: A defined weapon must or mustn't be equipped.\n" +
			"- Armor: A defined armor must or mustn't be equipped.\n" +
			"- Combatant: The combatant must or mustn't be a selected combatant.", "")]
		public StatusNeeded statusNeeded = StatusNeeded.StatusValue;
		
		[ORKEditorHelp("Selection", "Select the status information that will be checked for.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="statusNeeded")]
		[ORKEditorLayout(new string[] {"statusNeeded", "statusNeeded"}, 
			new System.Object[] {StatusNeeded.Level, StatusNeeded.Death}, needed=Needed.One, 
			elseCheckGroup=true, endCheckGroup=true)]
		public int selectionID = 0;
		
		[ORKEditorHelp("Attribute", "Select the needed attribute.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="statusNeeded", idFieldName="selectionID")]
		[ORKEditorLayout(new string[] {"statusNeeded", "statusNeeded"}, 
			new System.Object[] {StatusNeeded.AttackAttribute, StatusNeeded.DefenceAttribute}, 
			needed=Needed.One, endCheckGroup=true)]
		public int selectionID2 = 0;
		
		[ORKEditorHelp("Check Value", "Check the current value of the selected defence attribute.\n" +
			"If disabled, the combatant's current defence attribute is checked.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.DefenceAttribute, endCheckGroup=true, 
			setDefault=true, defaultValue=false)]
		public bool checkDefAttrVal = false;
		
		
		// comparison
		[ORKEditorHelp("Comparison", "The selected status value, attack attribute or " +
			"level is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(new string[] {"statusNeeded", "statusNeeded", "statusNeeded", "checkDefAttrVal"}, 
			new System.Object[] {StatusNeeded.StatusValue, StatusNeeded.AttackAttribute, StatusNeeded.Level, true}, 
			needed=Needed.One)]
		public ValueCheck comparison = ValueCheck.IsEqual;
		
		[ORKEditorHelp("Compare With Other", "Compares the selected status value with the current value of another status value.\n" +
			"If disabled, the status value is compared with a defined value.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.StatusValue, setDefault=true, defaultValue=false)]
		public bool compareWithOther = false;
		
		[ORKEditorHelp("Other Status Value", "Select the status value that will be used for the comparison.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue)]
		[ORKEditorLayout("compareWithOther", true, endCheckGroup=true, endGroups=2)]
		public int otherStatusValueID = 0;
		
		[ORKEditorHelp("Value", "The value that will be used for the comparison.", "")]
		[ORKEditorLayout("compareWithOther", false, endCheckGroup=true, endGroups=2)]
		public float value = 0;
		
		[ORKEditorHelp("Check In", "The value is either in percent of the maximum status value or an absolute value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(new string[] {"compareWithOther", "statusNeeded"}, 
			new System.Object[] {false, StatusNeeded.StatusValue}, endCheckGroup=true, 
			setDefault=true, defaultValue=ValueSetter.Value)]
		public ValueSetter setter = ValueSetter.Value;
		
		[ORKEditorHelp("Class Level", "If enabled, the combatants class level will be used instead of the base level.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Level, endCheckGroup=true)]
		public bool classLevel = false;
		
		
		// ability
		[ORKEditorHelp("Level", "The level of the ability that will be checked for.\n" +
			"The combatant must have at least the defined ability level.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Ability)]
		[ORKEditorLimit(1, false)]
		public int level = 1;
		
		[ORKEditorHelp("Knows Ability", "The combatant must know the ability (i.e. learned or temporary).\n" +
			"If disabled, the combatant mustn't know the ability.", "")]
		public bool knowsAbility = true;
		
		[ORKEditorHelp("Learned", "The ability has to be learned by the combatant (i.e. not an equipment ability).\n" +
			"If disabled, all abilities of the combatant are valid.", "")]
		[ORKEditorLayout("knowsAbility", true, endCheckGroup=true, endGroups=2)]
		public bool learned = false;
		
		
		// status effect
		[ORKEditorHelp("Is Applied", "The selected status effect must be applied.\n" +
			"If disabled, the effect mustn't be applied.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.StatusEffect)]
		public bool applied = false;
		
		[ORKEditorHelp("Check Stacked Quantity", "Check the quantity the status effect is stacked on the combatant.", "")]
		[ORKEditorLayout("applied", true, setDefault=true, defaultValue=false)]
		public bool checkStacked = false;
		
		[ORKEditorHelp("Comparison", "The stacked count of the status effect " +
			"is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("checkStacked", true)]
		public ValueCheck stackComparison = ValueCheck.IsEqual;
		
		[ORKEditorHelp("Stacked Quantity", "The value that will be used for the comparison.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=3)]
		public int stackedQuantity = 0;
		
		
		// death
		[ORKEditorHelp("Is Dead", "The combatant must be dead.\n" +
			"If disabled, the combatant must be alive.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Death, endCheckGroup=true)]
		public bool isDead = false;
		
		
		// equipment
		[ORKEditorHelp("Is Equipped", "The selected equipment must be equipped on the combatant.\n" +
			"If disabled, the equipment mustn't be equipped.", "")]
		[ORKEditorLayout(new string[] {"statusNeeded", "statusNeeded"}, 
			new System.Object[] {StatusNeeded.Weapon, StatusNeeded.Armor}, 
			needed=Needed.One, endCheckGroup=true)]
		public bool isEquipped = false;
		
		
		// combatant
		[ORKEditorHelp("Is Combatant", "The combatant must be the selected combatant.\n" +
			"If disabled, the combatant mustn't be the selected combatant.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Combatant, endCheckGroup=true)]
		public bool isCombatant = false;
		
		public BaseStatusRequirement()
		{
			
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return this.statusNeeded.ToString();
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CheckRequirement(Combatant combatant)
		{
			if(combatant != null)
			{
				if(StatusNeeded.StatusValue.Equals(this.statusNeeded))
				{
					return combatant.Status[this.selectionID].CompareTo(
						this.compareWithOther ? combatant.Status[this.otherStatusValueID].GetValue() : (int)this.value, 
						this.comparison, this.setter, combatant);
				}
				else if(StatusNeeded.StatusEffect.Equals(this.statusNeeded))
				{
					return this.applied == combatant.Status.IsEffectSet(this.selectionID) && 
						(!this.checkStacked || ValueHelper.CheckValue(
							combatant.Status.GetStackedEffectCount(this.selectionID), 
							this.stackedQuantity, this.stackComparison));
				}
				else if(StatusNeeded.AttackAttribute.Equals(this.statusNeeded))
				{
					return ValueHelper.CheckValue(
						combatant.Status.GetAttackAttribute(this.selectionID).GetValue(this.selectionID2), 
						this.value, this.comparison);
				}
				else if(StatusNeeded.DefenceAttribute.Equals(this.statusNeeded))
				{
					if(this.checkDefAttrVal)
					{
						return ValueHelper.CheckValue(
							combatant.Status.GetDefenceAttribute(this.selectionID).GetValue(this.selectionID2), 
							this.value, this.comparison);
					}
					else
					{
						return combatant.Status.GetDefenceAttributeID(this.selectionID).GetID() == this.selectionID2;
					}
				}
				else if(StatusNeeded.Ability.Equals(this.statusNeeded))
				{
					return (this.knowsAbility && 
							((this.learned && combatant.Abilities.HasLearned(this.selectionID, this.level)) ||
							(!this.learned && combatant.Abilities.Has(this.selectionID, this.level)))) ||
						(!this.knowsAbility && !combatant.Abilities.Has(this.selectionID, this.level));
				}
				else if(StatusNeeded.Level.Equals(this.statusNeeded))
				{
					return ValueHelper.CheckValue(
						this.classLevel ? combatant.ClassLevel : combatant.Level, 
						this.value, this.comparison);
				}
				else if(StatusNeeded.Class.Equals(this.statusNeeded))
				{
					return combatant.ClassID == this.selectionID;
				}
				else if(StatusNeeded.Death.Equals(this.statusNeeded))
				{
					return combatant.Dead == this.isDead;
				}
				else if(StatusNeeded.Weapon.Equals(this.statusNeeded))
				{
					return combatant.Equipment.IsEquipped(EquipSet.Weapon, this.selectionID) == this.isEquipped;
				}
				else if(StatusNeeded.Armor.Equals(this.statusNeeded))
				{
					return combatant.Equipment.IsEquipped(EquipSet.Armor, this.selectionID) == this.isEquipped;
				}
				else if(StatusNeeded.Combatant.Equals(this.statusNeeded))
				{
					return (combatant.ID == this.selectionID) == this.isCombatant;
				}
			}
			return false;
		}
		
		public bool CheckRequirementPreview(Combatant combatant)
		{
			if(combatant != null)
			{
				if(StatusNeeded.StatusValue.Equals(this.statusNeeded))
				{
					return combatant.Status[this.selectionID].CompareToPreview(
						this.compareWithOther ? 
							combatant.Status[this.otherStatusValueID].GetPreviewValue(false) : 
							(int)this.value, 
						this.comparison, this.setter, combatant);
				}
				else if(StatusNeeded.StatusEffect.Equals(this.statusNeeded))
				{
					return this.applied == combatant.Status.IsEffectSet(this.selectionID) && 
						(!this.checkStacked || ValueHelper.CheckValue(
							combatant.Status.GetStackedEffectCount(this.selectionID), 
							this.stackedQuantity, this.stackComparison));
				}
				else if(StatusNeeded.AttackAttribute.Equals(this.statusNeeded))
				{
					return ValueHelper.CheckValue(
						combatant.Status.GetAttackAttribute(this.selectionID).GetPreviewValue(this.selectionID2), 
						this.value, this.comparison);
				}
				else if(StatusNeeded.DefenceAttribute.Equals(this.statusNeeded))
				{
					if(this.checkDefAttrVal)
					{
						return ValueHelper.CheckValue(
							combatant.Status.GetDefenceAttribute(this.selectionID).GetPreviewValue(this.selectionID2), 
							this.value, this.comparison);
					}
					else
					{
						return combatant.Status.GetDefenceAttributeID(this.selectionID).GetID() == this.selectionID2;
					}
				}
				else if(StatusNeeded.Ability.Equals(this.statusNeeded))
				{
					return (this.knowsAbility && 
							((this.learned && combatant.Abilities.HasLearned(this.selectionID, this.level)) ||
							(!this.learned && combatant.Abilities.Has(this.selectionID, this.level)))) ||
						(!this.knowsAbility && !combatant.Abilities.Has(this.selectionID, this.level));
				}
				else if(StatusNeeded.Level.Equals(this.statusNeeded))
				{
					return ValueHelper.CheckValue(
						this.classLevel ? combatant.ClassLevel : combatant.Level, 
						this.value, this.comparison);
				}
				else if(StatusNeeded.Class.Equals(this.statusNeeded))
				{
					return combatant.ClassID == this.selectionID;
				}
				else if(StatusNeeded.Death.Equals(this.statusNeeded))
				{
					return combatant.Dead == this.isDead;
				}
				else if(StatusNeeded.Weapon.Equals(this.statusNeeded))
				{
					return combatant.Equipment.IsEquipped(EquipSet.Weapon, this.selectionID) == this.isEquipped;
				}
				else if(StatusNeeded.Armor.Equals(this.statusNeeded))
				{
					return combatant.Equipment.IsEquipped(EquipSet.Armor, this.selectionID) == this.isEquipped;
				}
				else if(StatusNeeded.Combatant.Equals(this.statusNeeded))
				{
					return (combatant.ID == this.selectionID) == this.isCombatant;
				}
			}
			return false;
		}
		
		public bool CheckRequirementBestiary(Combatant combatant)
		{
			if(combatant != null)
			{
				combatant.FindBestiaryEntry();
				
				if(StatusNeeded.StatusValue.Equals(this.statusNeeded))
				{
					if(combatant.Bestiary != null && combatant.Bestiary.status.statusValues)
					{
						return combatant.Status[this.selectionID].CompareTo(
							this.compareWithOther ? combatant.Status[this.otherStatusValueID].GetValue() : (int)this.value, 
							this.comparison, this.setter, combatant);
					}
				}
				else if(StatusNeeded.StatusEffect.Equals(this.statusNeeded))
				{
					return this.applied == combatant.Status.IsEffectSet(this.selectionID) && 
						(!this.checkStacked || ValueHelper.CheckValue(
							combatant.Status.GetStackedEffectCount(this.selectionID), 
							this.stackedQuantity, this.stackComparison));
				}
				else if(StatusNeeded.AttackAttribute.Equals(this.statusNeeded))
				{
					if(combatant.Bestiary != null && 
						combatant.Bestiary.status.attackAttribute[this.selectionID].attribute[this.selectionID2])
					{
						return ValueHelper.CheckValue(
							combatant.Status.GetAttackAttribute(this.selectionID).GetValue(this.selectionID2), 
							this.value, this.comparison);
					}
				}
				else if(StatusNeeded.DefenceAttribute.Equals(this.statusNeeded))
				{
					if(combatant.Bestiary != null)
					{
						if(this.checkDefAttrVal)
						{
							if(combatant.Bestiary.status.defenceAttribute[this.selectionID].attribute[this.selectionID2])
							{
								return ValueHelper.CheckValue(
									combatant.Status.GetDefenceAttribute(this.selectionID).GetValue(this.selectionID2), 
									this.value, this.comparison);
							}
						}
						else if(combatant.Bestiary.status.defAttrID[this.selectionID])
						{
							return combatant.Status.GetDefenceAttributeID(this.selectionID).GetID() == this.selectionID2;
						}
					}
				}
				else if(StatusNeeded.Ability.Equals(this.statusNeeded))
				{
					return (this.knowsAbility && 
							((this.learned && combatant.Abilities.HasLearned(this.selectionID, this.level)) ||
							(!this.learned && combatant.Abilities.Has(this.selectionID, this.level)))) ||
						(!this.knowsAbility && !combatant.Abilities.Has(this.selectionID, this.level));
				}
				else if(StatusNeeded.Level.Equals(this.statusNeeded))
				{
					return ValueHelper.CheckValue(
						this.classLevel ? combatant.ClassLevel : combatant.Level, 
						this.value, this.comparison);
				}
				else if(StatusNeeded.Class.Equals(this.statusNeeded))
				{
					return combatant.ClassID == this.selectionID;
				}
				else if(StatusNeeded.Death.Equals(this.statusNeeded))
				{
					return combatant.Dead == this.isDead;
				}
				else if(StatusNeeded.Weapon.Equals(this.statusNeeded))
				{
					if(combatant.Bestiary != null && combatant.Bestiary.status.equipment)
					{
						return combatant.Equipment.IsEquipped(EquipSet.Weapon, this.selectionID) == this.isEquipped;
					}
				}
				else if(StatusNeeded.Armor.Equals(this.statusNeeded))
				{
					if(combatant.Bestiary != null && combatant.Bestiary.status.equipment)
					{
						return combatant.Equipment.IsEquipped(EquipSet.Armor, this.selectionID) == this.isEquipped;
					}
				}
				else if(StatusNeeded.Combatant.Equals(this.statusNeeded))
				{
					return (combatant.ID == this.selectionID) == this.isCombatant;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public void RegisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			if(combatant != null)
			{
				if(StatusNeeded.StatusValue.Equals(this.statusNeeded))
				{
					StatusValue sv = combatant.Status[this.selectionID];
					sv.Changed += notify.StatusValueChanged;
					if(sv.IsConsumable())
					{
						combatant.Status[sv.Setting.maxStatusID].Changed += notify.StatusValueChanged;
					}
				}
				else if(StatusNeeded.StatusEffect.Equals(this.statusNeeded))
				{
					combatant.Status.StatusEffectChanged += notify.StatusEffectChanged;
				}
				else if(StatusNeeded.AttackAttribute.Equals(this.statusNeeded))
				{
					combatant.Status.GetAttackAttribute(this.selectionID).Changed += notify.AttackAttributeChanged;
				}
				else if(StatusNeeded.DefenceAttribute.Equals(this.statusNeeded))
				{
					if(this.checkDefAttrVal)
					{
						combatant.Status.GetDefenceAttribute(this.selectionID).Changed += notify.DefenceAttributeChanged;
					}
					else
					{
						combatant.Status.GetDefenceAttributeID(this.selectionID).Changed += notify.DefenceAttributeIDChanged;
					}
				}
				else if(StatusNeeded.Ability.Equals(this.statusNeeded))
				{
					combatant.Abilities.AbilitiesChanged += notify.AbilitiesChanged;
				}
				else if(StatusNeeded.Level.Equals(this.statusNeeded))
				{
					if(this.classLevel)
					{
						combatant.ClassLevelChanged += notify.ClassLevelChanged;
					}
					else
					{
						combatant.LevelChanged += notify.LevelChanged;
					}
				}
				else if(StatusNeeded.Class.Equals(this.statusNeeded))
				{
					combatant.ClassChanged += notify.ClassChanged;
				}
				else if(StatusNeeded.Weapon.Equals(this.statusNeeded) || 
					StatusNeeded.Armor.Equals(this.statusNeeded))
				{
					combatant.Equipment.Changed += notify.EquipmentChanged;
				}
			}
		}
		
		public void UnregisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			if(combatant != null)
			{
				if(StatusNeeded.StatusValue.Equals(this.statusNeeded))
				{
					StatusValue sv = combatant.Status[this.selectionID];
					sv.Changed -= notify.StatusValueChanged;
					if(sv.IsConsumable())
					{
						combatant.Status[sv.Setting.maxStatusID].Changed -= notify.StatusValueChanged;
					}
				}
				else if(StatusNeeded.StatusEffect.Equals(this.statusNeeded))
				{
					combatant.Status.StatusEffectChanged -= notify.StatusEffectChanged;
				}
				else if(StatusNeeded.AttackAttribute.Equals(this.statusNeeded))
				{
					combatant.Status.GetAttackAttribute(this.selectionID).Changed -= notify.AttackAttributeChanged;
				}
				else if(StatusNeeded.DefenceAttribute.Equals(this.statusNeeded))
				{
					if(this.checkDefAttrVal)
					{
						combatant.Status.GetDefenceAttribute(this.selectionID).Changed -= notify.DefenceAttributeChanged;
					}
					else
					{
						combatant.Status.GetDefenceAttributeID(this.selectionID).Changed -= notify.DefenceAttributeIDChanged;
					}
				}
				else if(StatusNeeded.Ability.Equals(this.statusNeeded))
				{
					combatant.Abilities.AbilitiesChanged -= notify.AbilitiesChanged;
				}
				else if(StatusNeeded.Level.Equals(this.statusNeeded))
				{
					if(this.classLevel)
					{
						combatant.ClassLevelChanged -= notify.ClassLevelChanged;
					}
					else
					{
						combatant.LevelChanged -= notify.LevelChanged;
					}
				}
				else if(StatusNeeded.Class.Equals(this.statusNeeded))
				{
					combatant.ClassChanged -= notify.ClassChanged;
				}
				else if(StatusNeeded.Weapon.Equals(this.statusNeeded) || 
					StatusNeeded.Armor.Equals(this.statusNeeded))
				{
					combatant.Equipment.Changed -= notify.EquipmentChanged;
				}
			}
		}
	}
}
