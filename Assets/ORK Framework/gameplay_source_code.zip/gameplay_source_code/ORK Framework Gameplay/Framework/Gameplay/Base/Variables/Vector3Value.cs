
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class Vector3Value : BaseData
	{
		[ORKEditorHelp("Value Type", "Select where the Vector3 value comes from:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (Vector3).\n" +
			"- Scene Position: The scene position of the current scene (or if not set: 0, 0, 0).\n" +
			"- Player Position: The current position of the player.", "")]
		public Vector3ValueType type = Vector3ValueType.Value;
		
		
		// value
		[ORKEditorHelp("Value", "The Vector3 value that will be used.", "")]
		[ORKEditorLayout("type", Vector3ValueType.Value, endCheckGroup=true)]
		public Vector3 value = Vector3.zero;
		
		
		// variable
		[ORKEditorHelp("Variable Key (Vector3)", "The key (name) of the game variable (Vector3) that contains the value.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout("type", Vector3ValueType.GameVariable, endCheckGroup=true, setDefault=true, defaultValue="")]
		public string variableKey = "";
		
		public Vector3Value()
		{
			
		}
		
		public Vector3Value(Vector3 value)
		{
			this.value = value;
		}
		
		public Vector3 GetValue()
		{
			if(Vector3ValueType.Value.Equals(this.type))
			{
				return this.value;
			}
			else if(Vector3ValueType.GameVariable.Equals(this.type))
			{
				return ORK.Game.Variables.GetVector3(this.variableKey);
			}
			else if(Vector3ValueType.ScenePosition.Equals(this.type))
			{
				SceneTarget st = ORK.Game.Scene.GetScenePosition(Application.loadedLevelName);
				if(st != null)
				{
					return st.position;
				}
			}
			else if(Vector3ValueType.PlayerPosition.Equals(this.type) && ORK.Game.GetPlayer() != null)
			{
				return ORK.Game.GetPlayer().transform.position;
			}
			return Vector3.zero;
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(Vector3ValueType.Value.Equals(this.type))
			{
				return this.value.ToString();
			}
			else if(Vector3ValueType.GameVariable.Equals(this.type))
			{
				return this.variableKey;
			}
			else
			{
				return this.type.ToString();
			}
		}
	}
}
