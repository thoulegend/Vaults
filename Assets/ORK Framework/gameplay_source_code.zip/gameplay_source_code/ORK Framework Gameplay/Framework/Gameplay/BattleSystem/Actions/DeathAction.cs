
using System.Collections.Generic;

namespace ORKFramework
{
	public class DeathAction : BaseAction
	{
		public bool natural = true;
		
		public DeathAction(Combatant user)
		{
			this.user = user;
			this.target = user.GetAttackedBy();
			
			this.consumeTime = false;
		}
		
		public DeathAction(Combatant user, bool natural) : this(user)
		{
			this.natural = natural;
		}
		
		public override bool IsType(ActionType t)
		{
			return ActionType.Death.Equals(t);
		}
		
		
		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		protected override bool PerformCheck()
		{
			return this.user != null;
		}
		
		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.deathInfo.Show(this.user, "");
			}
			
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleDeath)
				{
					this.user.Setting.consoleDeath.Print(this.user, this.target, null);
				}
				else
				{
					ORK.ConsoleSettings.actionDeath.Print(this.user, this.target, null);
				}
			}
			
			this.user.GetDeathEvent(ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			if(ORK.BattleSettings.camera.blockEventCams)
			{
				if(ts.Count == 1 && ts[0] != null && ts[0].GameObject != null)
				{
					ORK.BattleSettings.camera.SetLatestDamage(ts[0].GameObject.transform);
				}
				else if(ts.Count > 1)
				{
					ORK.BattleSettings.camera.SetLatestDamage(ORK.Battle.GetGroupCenter(ts).transform);
				}
			}
			
			if(this.user != null)
			{
				if(animate)
				{
					this.user.Animations.Play(ORK.AnimationTypes.deathID);
				}
				this.userConsumeDone = true;
			}
		}

		protected override void ActionEndSetup()
		{
			this.user.LastAbilityID = -1;
			this.user.Died();
		}
	}
}
