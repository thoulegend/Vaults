
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class RealTimeBattle : BaseBattle
	{
		// menu keys
		[ORKEditorHelp("Battle Menu Key", "Key to call the battle menu.\n" +
			"The key is only used in 'Real Time' type battles.", "")]
		[ORKEditorInfo("Real Time Settings", "Settings for the real time battle system.\n" +
			"A combatant will perform actions at any time.", "", 
			isPopup=true, popupType=ORKDataType.InputKey, labelText="Key Settings")]
		public int battleMenuKey = 0;
		
		[ORKEditorHelp("2nd Press Closes", "A second press on the same menu key closes the menu.\n" +
			"This is only available in 'Real Time' type battles.", "")]
		public bool keyCloses = false;
		
		// options
		[ORKEditorHelp("Can Counter", "Combatants can counter attack in 'Real Time' battles.\n" +
			"If disabled, combatants can't counter attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Options")]
		public bool canCounter = true;
		
		[ORKEditorHelp("Defeat on Player Death", "The player is defeated if the player combatant is dead.\n" +
			"If disabled, the whole player battle group has to be dead.", "")]
		public bool defeatPlayerDead = false;
		
		[ORKEditorHelp("Death Immediately", "A combatant's death action will be performed immediately when dying.\n" +
			"If disabled, the death action will be performed after the current action ends.", "")]
		public bool deathImmediately = false;
		
		[ORKEditorHelp("End Immediately", "The battle will end immediately, stopping the actions that are still performing.\n" +
			"If disabled, the battle will wait for all active actions to end.", "")]
		public bool endImmediately = false;
		
		[ORKEditorHelp("Defend First", "The defend command will perform before other actions.\n" +
			"Doesn't take already performing actions into account.", "")]
		public bool defendFirst = false;
		
		[ORKEditorHelp("Pause On Menu", "The battle is paused while displaying the battle menu " +
			"(i.e. the battle pauses while you select your actions).", "")]
		public bool menuPause = true;
		
		[ORKEditorHelp("Freeze Action", "The game freezes (animations, moves, etc. will stop) when the battle menu is called.", "")]
		[ORKEditorLayout("menuPause", true, endCheckGroup=true)]
		public bool freezeAction = false;
		
		[ORKEditorHelp("Block Menu", "In-game menus are blocked while the player is in a battle.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool blockMenu = false;
		
		
		// auto attack settings
		[ORKEditorHelp("Can Auto Attack", "Combatants can perform auto attacks.", "")]
		[ORKEditorInfo("Auto Attack Settings", "Set if combatants can use auto attacks in a battle of this system type.", "")]
		public bool canAutoAttack = true;
		
		[ORKEditorHelp("Menu Block Auto Atk", "A combatant's auto attack is blocked while his battle menu is opened.\n" +
			"Another combatant's menu wont block auto attacks.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("canAutoAttack", true, endCheckGroup=true)]
		public bool blockAutoAttackMenu = false;
		
		public RealTimeBattle()
		{
			
		}
		
		public override bool CanCounter
		{
			get{ return this.canCounter;}
		}
		
		public override bool DeathImmediately
		{
			get{ return this.deathImmediately;}
		}
		
		public override bool EndImmediately
		{
			get{ return this.endImmediately;}
		}
		
		public override bool IsMenuBackAllowed
		{
			get{ return true;}
		}
		
		public override bool MenuBlockAutoAttack
		{
			get
			{
				return this.blockAutoAttackMenu;
			}
		}
		
		public override bool CanAutoAttack
		{
			get
			{
				return this.canAutoAttack;
			}
		}
		
		public override bool DefeatOnPlayerDeath
		{
			get{ return this.defeatPlayerDead;}
		}
		
		public override bool DefendFirst
		{
			get{ return this.defendFirst;}
		}
		
		
		/*
		============================================================================
		Tick functions
		============================================================================
		*/
		public override void Tick()
		{
			
		}
		
		public override bool DoCombatantTick()
		{
			if(this.menuPause && ORK.Battle.MenuActive)
			{
				return false;
			}
			return base.DoCombatantTick();
		}
		
		
		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		public override void ActionAdded(BaseAction action)
		{
			this.PerformNextAction3();
		}
		
		public override void ActionUnshifted(BaseAction action)
		{
			this.PerformNextAction3();
		}
		
		protected override void PerformNextAction3()
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(ORK.Battle.Actions.Has())
				{
					BaseAction action = ORK.Battle.Actions.NextPerformable();
					if(action != null && !action.IsCastingAbility())
					{
						this.PerformAction(action);
					}
					else
					{
						this.PerformAction(null);
					}
				}
			}
		}
	}
}
