
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework
{
	public class TurnBasedBattle : BaseBattle
	{
		[ORKEditorHelp("Turn Calculation", "Select the formula used to calculate a turn value for every combatant.\n" +
			"Afterwards the values are sorted descending - the combatant with the highest turn value performs the first action, " +
			"followed by the combatant with the next (lower) value.", "")]
		[ORKEditorInfo("Turn Based Settings", "Settings for the turn based battle system.\n" +
			"A combatant will perform actions when it's his turn.", "", 
			isPopup=true, popupType=ORKDataType.Formula)]
		public int turnFormulaID = 0;
		
		[ORKEditorHelp("Initial Value (Turn)", "The initial value passed to the turn formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		public float initialValueTurn = 0;
		
		[ORKEditorHelp("Invert Turn Order", "Inverts the order of turns, the values will be sorted ascending.\n" +
			"The combatant with the lowest turn value performs the first action.\n" +
			"If disabled, the turn order is sorted descending.", "")]
		[ORKEditorLayout("useMultiTurns", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool invertTurnOrder = false;
		
		
		// options
		[ORKEditorHelp("Can Counter", "Combatants can counter attack in 'Turn Based' battles.\n" +
			"If disabled, combatants can't counter attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Options")]
		public bool canCounter = true;
		
		[ORKEditorHelp("Defeat on Player Death", "The player is defeated if the player combatant is dead.\n" +
			"If disabled, the whole player battle group has to be dead.", "")]
		public bool defeatPlayerDead = false;
		
		[ORKEditorHelp("Death Immediately", "A combatant's death action will be performed immediately when dying.\n" +
			"If disabled, the death action will be performed after the current action ends.", "")]
		public bool deathImmediately = false;
		
		[ORKEditorHelp("End Immediately", "The battle will end immediately, stopping the actions that are still performing.\n" +
			"If disabled, the battle will wait for all active actions to end.", "")]
		public bool endImmediately = false;
		
		[ORKEditorHelp("Defend First", "The defend command will perform before other actions.\n" +
			"Doesn't take already performing actions into account.", "")]
		public bool defendFirst = false;
		
		// active command
		[ORKEditorHelp("Use Active Command", "Battle actions are executed right after selecting them, resulting in " +
			"each combatant selecting his action after the previous combatant finished it's action.\n" +
			"If disabled, the battle actions are selected at the beginning of each turn and executed " +
			"after all combatants chose their actions.", "")]
		public bool activeCommand = false;
		
		// multi-turns (CTB)
		[ORKEditorHelp("Use Multi-Turns", "A combatant can perform multiple turns " +
			"before another combatant had his turn.\n" +
			"After a combatant performed his turn, his turn value will be reset to 0 " +
			"and the turn value of all combatants will be increased " +
			"(using the 'Turn Calculation').\n" +
			"The combatant with the highest turn value will have the next turn." +
			"'Invert Turn Order' isn't available when using multi-turns.", "")]
		[ORKEditorLayout("activeCommand", true, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool useMultiTurns = false;
		
		// dynamic combat
		[ORKEditorHelp("Use Dynamic Combat", "Multiple actions are allowed at the same time.\n" +
			"Combatants will attack as soon as they can, the strict turn based battle order isn't followed.\n" +
			"Please note that only camera changes from the latest battle action (battle animations) will be performed.", "")]
		public bool dynamicCombat = false;
		
		[ORKEditorHelp("Time Between Actions (s)", "The minimum time in seconds between two battle actions.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("dynamicCombat", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minTimeBetween = 0;
		
		
		// auto attack settings
		[ORKEditorHelp("Can Auto Attack", "Combatants can perform auto attacks.", "")]
		[ORKEditorInfo("Auto Attack Settings", "Set if combatants can use auto attacks in a battle of this system type.", "")]
		public bool canAutoAttack = true;
		
		[ORKEditorHelp("Menu Block Auto Atk", "A combatant's auto attack is blocked while his battle menu is opened.\n" +
			"Another combatant's menu wont block auto attacks.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("canAutoAttack", true, endCheckGroup=true)]
		public bool blockAutoAttackMenu = false;
		
		
		// ingame
		protected Combatant selectingCombatant;
		
		private List<Combatant> turnOrder = new List<Combatant>();
		
		private int firstMoveRounds = 1;
		
		private bool performingActions = false;
		
		
		// turn order HUD updates
		public event UpdateHUD UpdateHUD;
		
		public TurnBasedBattle()
		{
			
		}
		
		public void FireHUDUpdate()
		{
			if(this.UpdateHUD != null)
			{
				this.UpdateHUD();
			}
		}
		
		public override bool CanCounter
		{
			get{ return this.canCounter;}
		}
		
		public override bool DeathImmediately
		{
			get{ return this.deathImmediately;}
		}
		
		public override bool EndImmediately
		{
			get{ return this.endImmediately;}
		}
		
		public override bool DefeatOnPlayerDeath
		{
			get{ return this.defeatPlayerDead;}
		}
		
		public override bool DefendFirst
		{
			get{ return this.defendFirst;}
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool IsDynamicCombat()
		{
			return this.dynamicCombat;
		}
		
		public override bool MenuBlockAutoAttack
		{
			get
			{
				return this.blockAutoAttackMenu;
			}
		}
		
		public override bool CanAutoAttack
		{
			get
			{
				return this.canAutoAttack;
			}
		}
		
		
		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public override void StartBattle(bool changed)
		{
			base.StartBattle(changed);
			this.selectingCombatant = null;
			this.turnOrder = new List<Combatant>();
			this.performingActions = false;
			this.FireHUDUpdate();
			
			if(!changed)
			{
				this.firstMoveRounds = 0;
				if(GroupAdvantageType.Player.Equals(ORK.Battle.Advantage))
				{
					if(ORK.BattleSettings.playerAdvantage.playerGroupCondition.firstMove)
					{
						this.firstMoveRounds = ORK.BattleSettings.playerAdvantage.playerGroupCondition.firstMoveRounds;
					}
					else if(ORK.BattleSettings.playerAdvantage.enemyGroupCondition.firstMove)
					{
						this.firstMoveRounds = ORK.BattleSettings.playerAdvantage.enemyGroupCondition.firstMoveRounds;
					}
				}
				else if(GroupAdvantageType.Enemy.Equals(ORK.Battle.Advantage))
				{
					if(ORK.BattleSettings.enemyAdvantage.playerGroupCondition.firstMove)
					{
						this.firstMoveRounds = ORK.BattleSettings.enemyAdvantage.playerGroupCondition.firstMoveRounds;
					}
					else if(ORK.BattleSettings.enemyAdvantage.enemyGroupCondition.firstMove)
					{
						this.firstMoveRounds = ORK.BattleSettings.enemyAdvantage.enemyGroupCondition.firstMoveRounds;
					}
				}
			}
			this.StartTurn();
		}
		
		private void StartTurn()
		{
			ORK.Battle.CheckBattleEnd();
			if(!ORK.Battle.BattleEnd)
			{
				this.performingActions = false;
				this.selectingCombatant = null;
				
				if(!this.dynamicCombat)
				{
					ORK.Battle.Actions.ClearStack();
				}
				
				// determine the order of actions
				List<Combatant> order = new List<Combatant>();
				List<Combatant> allyOrder = null;
				List<Combatant> enemyOrder = null;
				if(!GroupAdvantageType.None.Equals(ORK.Battle.Advantage) && this.firstMoveRounds > 0)
				{
					allyOrder = new List<Combatant>();
					enemyOrder = new List<Combatant>();
				}
				
				Combatant player = ORK.Game.ActiveGroup.Leader;
				// player group and allies
				this.GroupTurnInit(ORK.Game.Combatants.Get(player, true, Range.Infinity, 
					Consider.No, Consider.Ignore, Consider.Yes), 
					ref order, ref allyOrder);
				// enemies
				this.GroupTurnInit(ORK.Game.Combatants.Get(player, true, Range.Infinity, 
					Consider.Yes, Consider.Ignore, Consider.Yes), 
					ref order, ref enemyOrder);
				
				if(GroupAdvantageType.None.Equals(ORK.Battle.Advantage) || 
					this.firstMoveRounds < 1)
				{
					order.Sort(new TurnSorter());
				}
				else
				{
					allyOrder.Sort(new TurnSorter());
					enemyOrder.Sort(new TurnSorter());
					if(GroupAdvantageType.Player.Equals(ORK.Battle.Advantage))
					{
						for(int i=0; i<allyOrder.Count; i++)
						{
							order.Add(allyOrder[i]);
						}
						for(int i=0; i<enemyOrder.Count; i++)
						{
							order.Add(enemyOrder[i]);
						}
					}
					else if(GroupAdvantageType.Enemy.Equals(ORK.Battle.Advantage))
					{
						for(int i=0; i<enemyOrder.Count; i++)
						{
							order.Add(enemyOrder[i]);
						}
						for(int i=0; i<allyOrder.Count; i++)
						{
							order.Add(allyOrder[i]);
						}
					}
					this.firstMoveRounds--;
				}
				
				if(this.invertTurnOrder)
				{
					order.Reverse();
				}
				
				this.turnOrder = new List<Combatant>();
				for(int i=0; i<order.Count; i++)
				{
					order[i].LastTurnIndex = i;
					this.turnOrder.Add(order[i]);
				}
				this.FireHUDUpdate();
				ORK.StartCoroutine(this.GetNextAction());
			}
		}
		
		private void GroupTurnInit(List<Combatant> group, 
			ref List<Combatant> order, 
			ref List<Combatant> groupOrder)
		{
			for(int i=0; i<group.Count; i++)
			{
				if(!group[i].Dead)
				{
					if(group[i].TurnPerformed || 
						(this.activeCommand && this.useMultiTurns))
					{
						group[i].TurnValue += ORK.Formulas.Get(this.turnFormulaID).
							Calculate(this.initialValueTurn, group[i], group[i]);
						group[i].TurnPerformed = false;
					}
					else
					{
						group[i].TurnValue = 0 - this.turnOrder.Count + group[i].LastTurnIndex;
					}
					
					if(GroupAdvantageType.None.Equals(ORK.Battle.Advantage) || 
						this.firstMoveRounds < 1)
					{
						order.Add(group[i]);
					}
					else
					{
						groupOrder.Add(group[i]);
					}
				}
			}
		}
		
		public override void RemoveFromOrder(Combatant combatant)
		{
			if(!combatant.Status.NoTurnRemove)
			{
				if(this.activeCommand && this.useMultiTurns)
				{
					combatant.TurnValue = 0;
					this.turnOrder.Sort(new TurnSorter());
				}
				else
				{
					// action not yet selected
					if(this.turnOrder.Contains(combatant))
					{
						this.turnOrder.Remove(combatant);
					}
					// remove action
					else
					{
						ORK.Battle.Actions.RemoveFromUser(combatant);
					}
				}
				this.FireHUDUpdate();
			}
		}
		
		public override void OrderChange(Combatant combatant, int change)
		{
			if(!combatant.Status.NoTurnOrderChange)
			{
				if(this.activeCommand && this.useMultiTurns)
				{
					combatant.TurnValue -= change;
					this.turnOrder.Sort(new TurnSorter());
				}
				else
				{
					// action not yet selected
					if(this.turnOrder.Contains(combatant))
					{
						int newIndex = this.turnOrder.IndexOf(combatant) + change;
						newIndex = Mathf.Max(newIndex, 0);
						newIndex = Mathf.Min(newIndex, this.turnOrder.Count - 1);
						
						this.turnOrder.Remove(combatant);
						this.turnOrder.Insert(newIndex, combatant);
					}
					// move action
					else
					{
						ORK.Battle.Actions.ChangeOrderFromUser(combatant, change);
					}
				}
				this.FireHUDUpdate();
			}
		}
		
		
		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		protected IEnumerator GetNextAction()
		{
			yield return null;
			if(!ORK.Battle.BattleEnd)
			{
				if(this.turnOrder.Count > 0)
				{
					this.selectingCombatant = this.turnOrder[0];
					this.turnOrder.RemoveAt(0);
					this.FireHUDUpdate();
					
					if(this.selectingCombatant != null && 
						this.selectingCombatant.Actions.CanChoose)
					{
						this.selectingCombatant.Actions.Choose();
					}
					else
					{
						this.selectingCombatant.InitNewTurn(false);
						this.selectingCombatant = null;
						ORK.Battle.Actions.Add(null);
					}
				}
				else
				{
					this.StartTurn();
				}
			}
		}
		
		public override void ActionAdded(BaseAction action)
		{
			if(this.activeCommand || 
				(!this.performingActions && this.turnOrder.Count == 0))
			{
				this.performingActions = true;
				this.PerformNextAction();
			}
			else
			{
				ORK.StartCoroutine(this.GetNextAction());
			}
		}
		
		protected override void PerformNextAction3()
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(ORK.Battle.Actions.Has())
				{
					BaseAction action = ORK.Battle.Actions.NextPerformable();
					if(action != null && !action.IsCastingAbility())
					{
						this.PerformAction(action);
					}
					else if(this.dynamicCombat || action == null)
					{
						this.PerformAction(null);
					}
				}
				else if(this.activeCommand)
				{
					ORK.StartCoroutine(this.GetNextAction());
				}
			}
		}
		
		public override void PerformingAction(BaseAction action)
		{
			if(this.dynamicCombat)
			{
				if(this.minTimeBetween > 0)
				{
					ORK.StartCoroutine(this.ActionFinished2(action));
				}
				else
				{
					this.ActionFinished(action);
				}
			}
		}
		
		public IEnumerator ActionFinished2(BaseAction action)
		{
			yield return new WaitForSeconds(this.minTimeBetween);
			this.ActionFinished(action);
		}
		
		public override void ActionFinished(BaseAction action)
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(ORK.Battle.Actions.Has())
				{
					this.PerformNextAction();
				}
				else if(this.activeCommand)
				{
					if(this.useMultiTurns)
					{
						this.StartTurn();
					}
					else
					{
						ORK.StartCoroutine(this.GetNextAction());
					}
				}
				else if(!this.dynamicCombat || this.turnOrder.Count == 0)
				{
					this.StartTurn();
				}
			}
		}
		
		public override void ActiveActionRemoved()
		{
			if(this.dynamicCombat && ORK.Battle.Actions.Has())
			{
				this.PerformNextAction();
			}
		}
		
		
		/*
		============================================================================
		HUD functions
		============================================================================
		*/
		public List<Combatant> GetTurnOrder(int maximumLength)
		{
			List<Combatant> list = new List<Combatant>();
			
			// add currently selecting combatant
			if(this.selectingCombatant != null)
			{
				list.Add(this.selectingCombatant);
			}
			
			// multi-turn battle
			if(this.activeCommand && this.useMultiTurns)
			{
				// create dummy list
				List<Combatant> tmpList = new List<Combatant>();
				if(this.selectingCombatant != null)
				{
					tmpList.Add(this.selectingCombatant);
				}
				// make sure first combatant is added
				else if(this.turnOrder.Count > 0)
				{
					list.Add(this.turnOrder[0]);
				}
				
				for(int i=0; i<this.turnOrder.Count; i++)
				{
					if(!this.turnOrder[i].Dead)
					{
						tmpList.Add(this.turnOrder[i]);
						this.turnOrder[i].TurnValueDummy = this.turnOrder[i].TurnValue;
					}
				}
				
				if(tmpList.Count > 0)
				{
					// reset first combatant
					tmpList[0].TurnValueDummy = 0;
					
					// add all at least once
					if(maximumLength < 0)
					{
						List<Combatant> added = new List<Combatant>();
						added.Add(tmpList[0]);
						
						while(added.Count != tmpList.Count)
						{
							this.TurnOrderForecast(tmpList);
							list.Add(tmpList[0]);
							tmpList[0].TurnValueDummy = 0;
							if(!added.Contains(tmpList[0]))
							{
								added.Add(tmpList[0]);
							}
						}
					}
					// repeat dummy cycles until list is full
					else
					{
						while(list.Count < maximumLength)
						{
							this.TurnOrderForecast(tmpList);
							list.Add(tmpList[0]);
							tmpList[0].TurnValueDummy = 0;
						}
					}
				}
			}
			// other
			else
			{
				if(maximumLength < 0 || this.turnOrder.Count < maximumLength)
				{
					for(int i=0; i<this.turnOrder.Count; i++)
					{
						if(!this.turnOrder[i].Dead)
						{
							list.Add(this.turnOrder[i]);
						}
					}
				}
				else
				{
					for(int i=0; i<maximumLength - 1; i++)
					{
						if(!this.turnOrder[i].Dead)
						{
							list.Add(this.turnOrder[i]);
						}
					}
				}
			}
			
			return list;
		}
		
		private void TurnOrderForecast(List<Combatant> list)
		{
			for(int i=0; i<list.Count; i++)
			{
				list[i].TurnValueDummy += ORK.Formulas.Get(this.turnFormulaID).
					Calculate(this.initialValueTurn, list[i], list[i]);
			}
			list.Sort(new DummyTurnSorter());
		}
	}
}
