
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SelectedTargets
	{
		private Combatant owner;
		
		private Group ownerGroup;
		
		private bool isGroupTarget = false;
		
		private Combatant[] targets;
		
		public SelectedTargets(Combatant owner)
		{
			this.owner = owner;
			this.isGroupTarget = false;
		}
		
		public SelectedTargets(Group ownerGroup)
		{
			this.ownerGroup = ownerGroup;
			this.isGroupTarget = true;
		}
		
		public void Clear()
		{
			this.targets = null;
		}
		
		private void CheckTargets()
		{
			if(this.targets == null)
			{
				this.targets = new Combatant[this.isGroupTarget ? 
					ORK.BattleSettings.groupTargetSelection.Length : 
					ORK.BattleSettings.individualTargetSelection.Length];
			}
		}
		
		public int Count
		{
			get
			{
				this.CheckTargets();
				return this.targets.Length;
			}
		}
		
		public Combatant this[int index]
		{
			get
			{
				this.CheckTargets();
				if(index >= 0 && index < this.targets.Length)
				{
					return this.targets[index];
				}
				return null;
			}
			set
			{
				this.CheckTargets();
				if(index >= 0 && index < this.targets.Length)
				{
					this.targets[index] = value;
					
					if(this.isGroupTarget)
					{
						if(this.targets[index] != null)
						{
							this.targets[index].UpdateHUD -= this.ownerGroup.MarkHUDUpdate;
						}
						
						this.targets[index] = value;
						ORK.BattleSettings.groupTargetSelection[index].AddCursor(value);
						this.ownerGroup.MarkHUDUpdate();
						
						if(this.targets[index] != null)
						{
							this.targets[index].UpdateHUD += this.ownerGroup.MarkHUDUpdate;
						}
					}
					else
					{
						if(this.targets[index] != null)
						{
							this.targets[index].UpdateHUD -= this.owner.MarkHUDUpdate;
						}
						
						this.targets[index] = value;
						ORK.BattleSettings.individualTargetSelection[index].AddCursor(value);
						this.owner.MarkHUDUpdate();
						
						if(this.targets[index] != null)
						{
							this.targets[index].UpdateHUD += this.owner.MarkHUDUpdate;
						}
					}
				}
			}
		}
		
		public bool HasTarget(int index)
		{
			return this[index] != null;
		}
		
		public void SetCursors()
		{
			if(this.isGroupTarget)
			{
				for(int i=0; i<this.Count; i++)
				{
					ORK.BattleSettings.groupTargetSelection[i].AddCursor(this[i]);
				}
			}
			else
			{
				for(int i=0; i<this.Count; i++)
				{
					ORK.BattleSettings.individualTargetSelection[i].AddCursor(this[i]);
				}
			}
		}
		
		
		/*
		============================================================================
		Use functions
		============================================================================
		*/
		public Combatant GetShortcutTarget(Combatant user, IShortcut shortcut)
		{
			if(shortcut is AbilityShortcut)
			{
				return this.GetAbilityTarget(user, shortcut as AbilityShortcut);
			}
			else if(shortcut is ItemShortcut)
			{
				return this.GetItemTarget(user, shortcut as ItemShortcut);
			}
			return null;
		}
		
		public Combatant GetAutoAttackTarget(Combatant user)
		{
			if(this.isGroupTarget)
			{
				for(int i=0; i<this.Count; i++)
				{
					if(this[i] != null && 
						ORK.BattleSettings.groupTargetSelection[i].UseAutoAttackTarget(user))
					{
						return this[i];
					}
				}
			}
			else
			{
				for(int i=0; i<this.Count; i++)
				{
					if(this[i] != null && 
						ORK.BattleSettings.individualTargetSelection[i].UseAutoAttackTarget(user))
					{
						return this[i];
					}
				}
			}
			return null;
		}
		
		public Combatant GetAbilityTarget(Combatant user, AbilityShortcut ability)
		{
			if(this.isGroupTarget)
			{
				for(int i=0; i<this.Count; i++)
				{
					if(this[i] != null && ability.CanTarget(user, this[i]) && 
						ORK.BattleSettings.groupTargetSelection[i].CanUseAbility(ability.ID, ability.TypeID))
					{
						return this[i];
					}
				}
			}
			else
			{
				for(int i=0; i<this.Count; i++)
				{
					if(this[i] != null && ability.CanTarget(user, this[i]) && 
						ORK.BattleSettings.individualTargetSelection[i].CanUseAbility(ability.ID, ability.TypeID))
					{
						return this[i];
					}
				}
			}
			return null;
		}
		
		public Combatant GetItemTarget(Combatant user, ItemShortcut item)
		{
			if(this.isGroupTarget)
			{
				for(int i=0; i<this.Count; i++)
				{
					if(this[i] != null && item.CanTarget(user, this[i]) && 
						ORK.BattleSettings.groupTargetSelection[i].CanUseItem(item.ID, item.TypeID))
					{
						return this[i];
					}
				}
			}
			else
			{
				for(int i=0; i<this.Count; i++)
				{
					if(this[i] != null && item.CanTarget(user, this[i]) && 
						ORK.BattleSettings.individualTargetSelection[i].CanUseItem(item.ID, item.TypeID))
					{
						return this[i];
					}
				}
			}
			return null;
		}
	}
}
