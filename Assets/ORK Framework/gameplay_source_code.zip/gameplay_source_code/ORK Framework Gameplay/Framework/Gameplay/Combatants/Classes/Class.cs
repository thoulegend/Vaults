
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class Class : BaseLanguageData, IContentSimple
	{
		// base settings
		// class ability
		[ORKEditorHelp("Use Class Ability", "The class uses a class ability.\n" +
			"The class ability can be leveled up by the combatant.", "")]
		[ORKEditorInfo("Base Settings", "Base settings of this class.", "", labelText="Class Ability")]
		public bool useClassAbility = false;
		
		[ORKEditorLayout("useClassAbility", true, endCheckGroup=true, autoInit=true)]
		public AbilitySetting classAbility;
		
		// battle menu
		[ORKEditorHelp("Own Battle Menu", "The class has it's own battle menu.\n" +
			"This setting overrides the default battle menu.\n" +
			"This setting can be overridden by a combatant's battle menu.", "")]
		[ORKEditorInfo(separator=true, labelText="Battle Menu")]
		public bool ownBM = false;
		
		[ORKEditorHelp("Battle Menu", "Select the battle menu used by this class.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("ownBM", true)]
		public int menuID = 0;
		
		// turn based menu
		[ORKEditorHelp("Own Turn Based Menu", "Use a different battle menu in turn based battles.", "")]
		public bool useTurnBasedMenu = false;
		
		[ORKEditorHelp("Turn Based Menu", "Select the battle menu that will be used in turn based battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useTurnBasedMenu", true, endCheckGroup=true)]
		public int turnBasedMenuID = 0;
		
		// active time menu
		[ORKEditorHelp("Own Active Time Menu", "Use a different battle menu in active time battles.", "")]
		public bool useActiveTimeMenu = false;
		
		[ORKEditorHelp("Active Time Menu", "Select the battle menu that will be used in active time battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useActiveTimeMenu", true, endCheckGroup=true)]
		public int activeTimeMenuID = 0;
		
		// real time menu
		[ORKEditorHelp("Own Real Time Menu", "Use a different battle menu in real time battles.", "")]
		public bool useRealTimeMenu = false;
		
		[ORKEditorHelp("Real Time Menu", "Select the battle menu that will be used in real time battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useRealTimeMenu", true, endCheckGroup=true)]
		public int realTimeMenuID = 0;
		
		// phase battle menu
		[ORKEditorHelp("Own Phase Menu", "Use a different battle menu in phase battles.", "")]
		public bool usePhaseMenu = false;
		
		[ORKEditorHelp("Phase Menu", "Select the battle menu that will be used in phase battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("usePhaseMenu", true, endCheckGroup=true, endGroups=2)]
		public int phaseMenuID = 0;
		
		
		// control maps
		[ORKEditorHelp("Control Map", "Select the control map that will be used.", "")]
		[ORKEditorInfo(ORKDataType.ControlMap, separator=true, labelText="Control Map", 
			endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Control Map", "Adds a control map to this class.", "",
			"Remove", "Removes the control map.", "", isHorizontal=true)]
		public int[] controlMap = new int[0];
		
		
		// equipment
		public AvailableEquipment equipment = new AvailableEquipment();
		
		
		// attack attribute startvalues
		[ORKEditorInfo("Attack Attributes Start Values", "Override the default start values of attack attributes.\n" +
			"Can be overridden by combatants.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Attack Attribute", "Adds an attack attribute start value setting.", "", 
			"Remove", "Removes this attack attributes start value setting.", "", 
			removeType=ORKDataType.AttackAttributes, removeCheckField="attributeID", 
			foldout=true, foldoutText=new string[] {"Attack Attributes Start Value", 
				"Set the start values for the selected attack attribute.", ""})]
		public AtkAttrStartValue[] atkAttrStart = new AtkAttrStartValue[0];
		
		
		// defence attribute start values
		[ORKEditorInfo("Defence Attributes Start Values", "Override the default start values of defence attributes.\n" +
			"Can be overridden by combatants.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Defence Attributes", "Adds a defence attributes start value setting.", "", 
			"Remove", "Removes this defence attributes start value setting.", "", 
			removeType=ORKDataType.DefenceAttributes, removeCheckField="attributeID", 
			foldout=true, foldoutText=new string[] {"Defence Attributes Start Value", 
				"Set the start values for the selected defence attributes.", ""})]
		public DefAttrStartValue[] defAttrStart = new DefAttrStartValue[0];
		
		
		// bonus
		public BonusSettings bonus = new BonusSettings();
		
		
		// status effect auto/immunity
		[ORKEditorInfo("Status Effect Settings", "A class can grant auto status effects and " +
			"status effect immunity to a combatant.", "", endFoldout=true)]
		public AutoEffects autoEffects = new AutoEffects();
		
		
		// development
		[ORKEditorHelp("Use Class Level", "This class can be leveled up using " +
			"EXPERIENCE type status values with class level up enabled.", "")]
		[ORKEditorInfo("Development Settings", "Additionally to a combatants base level system, " +
			"classes can also be leveled up and have status value development.", "")]
		public bool useClassLevel = false;
		
		[ORKEditorHelp("Status Development", "Select the status development used by this class.", "")]
		[ORKEditorInfo(ORKDataType.StatusDevelopment)]
		[ORKEditorLayout("useClassLevel", true)]
		public int statusDevelopmentID = 0;
		
		[ORKEditorHelp("Own Level Up", "This class overrides the default level up settings (battle system).", "")]
		[ORKEditorInfo(separator=true, labelText="Class Level Up Settings")]
		public bool ownLvlUp = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownLvlUp", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public LevelUpBonus lvlUp;
		
		public AbilityDevelopment abilityDevelopment = new AbilityDevelopment();
		
		public Class()
		{
			
		}
		
		public Class(string name) : base(name)
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.ContainsArray<bool>("equipPart"))
			{
				this.equipment = new AvailableEquipment();
				data.Get("equipPart", out this.equipment.equipPart);
				data.Get("weapon", out this.equipment.weapon);
				data.Get("armor", out this.equipment.armor);
			}
		}
		
		
		/*
		============================================================================
		Development functions
		============================================================================
		*/
		public StatusDevelopment GetStatusDevelopment()
		{
			if(this.useClassLevel)
			{
				return ORK.StatusDevelopments.Get(this.statusDevelopmentID);
			}
			else
			{
				return null;
			}
		}
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get{ return this.realID;}
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}
		
		public string GetIconTextCode()
		{
			return TextCode.ClassIcon + this.realID + "#";
		}

		public Texture2D GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}
	}
}
