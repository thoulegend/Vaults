
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantAbilities : ISaveData
	{
		private Combatant owner;
		
		
		// base attacks
		private AbilityShortcut[] attack;
		
		private AbilityShortcut counter;
		
		
		// class ability
		private Dictionary<int, AbilityShortcut> classAbility = new Dictionary<int, AbilityShortcut>();
		
		
		// lists
		private AbilityShortcut[] learned = new AbilityShortcut[0];
		
		private List<EquipmentAbility> equip = new List<EquipmentAbility>();
		
		private List<AbilityShortcut> passive = new List<AbilityShortcut>();
		
		private List<AbilityShortcut> both = new List<AbilityShortcut>();
		
		private List<AbilityShortcut> field = new List<AbilityShortcut>();
		
		private List<AbilityShortcut> battle = new List<AbilityShortcut>();
		
		
		// ability trees
		private List<int> abilityTree = new List<int>();
		
		
		// events
		public event AbilitiesChanged AbilitiesChanged;
		
		public CombatantAbilities(Combatant owner)
		{
			this.owner = owner;
			
			// init base attacks
			this.attack = new AbilityShortcut[this.owner.Setting.baseAttack.Length];
			for(int i=0; i<this.attack.Length; i++)
			{
				this.attack[i] = this.owner.Setting.baseAttack[i].GetAbility(AbilityActionType.BaseAttack);
				this.attack[i].RegisterStatusChanges(this.owner);
			}
			
			// init counter attack
			this.counter = this.owner.Setting.counterAttack.GetAbility(AbilityActionType.CounterAttack);
			this.counter.RegisterStatusChanges(this.owner);
		}
		
		/// <summary>
		/// Creates the ability lists from learned and equipped abilities.
		/// </summary>
		public void CreateAbilities()
		{
			this.CreateAbilities(out this.both, UseableIn.Both);
			this.CreateAbilities(out this.field, UseableIn.Field);
			this.CreateAbilities(out this.battle, UseableIn.Battle);
			this.CreateAbilities(out this.passive, UseableIn.None);
			
			this.SetStartEffects();
			
			// notify
			if(this.AbilitiesChanged != null)
			{
				this.AbilitiesChanged(this.owner);
				this.owner.FireChanged();
			}
		}
		
		private void CreateAbilities(out List<AbilityShortcut> list, UseableIn useIn)
		{
			list = new List<AbilityShortcut>();
			List<int> added = new List<int>();
			
			// learned
			for(int i=0; i<this.learned.Length; i++)
			{
				if(this.learned[i].IsUseable(useIn))
				{
					list.Add(this.learned[i]);
					added.Add(this.learned[i].ID);
				}
			}
			
			// equipment
			for(int i=0; i<this.equip.Count; i++)
			{
				if(ORK.Abilities.Get(this.equip[i].abilityID).IsUseable(useIn))
				{
					if(added.Contains(this.equip[i].abilityID))
					{
						int k = added.IndexOf(this.equip[i].abilityID);
						if(list[k].Level < this.equip[i].abilityLevel)
						{
							list[k] = new AbilityShortcut(this.equip[i].abilityID, 
								this.equip[i].abilityLevel, AbilityActionType.Ability);
						}
					}
					else
					{
						list.Add(new AbilityShortcut(this.equip[i].abilityID, 
							this.equip[i].abilityLevel, AbilityActionType.Ability));
						added.Add(this.equip[i].abilityID);
					}
				}
			}
		}
		
		/// <summary>
		/// Gets the base attack ability.
		/// </summary>
		/// <returns>
		/// The base attack's ability.
		/// </returns>
		/// <param name='index'>
		/// The index of the base attack.
		/// Will be reset to 0 if outside of available attacks.
		/// </param>
		public AbilityShortcut GetBaseAttack(ref int index)
		{
			if(index >= this.attack.Length)
			{
				index = 0;
			}
			if(index >= 0 && index < this.attack.Length)
			{
				return this.attack[index];
			}
			return null;
		}
		
		/// <summary>
		/// Gets the counter attack ability.
		/// </summary>
		/// <returns>
		/// The counter attack's ability.
		/// </returns>
		public AbilityShortcut GetCounterAttack()
		{
			return this.counter;
		}
		
		
		/*
		============================================================================
		Status functions
		============================================================================
		*/
		/// <summary>
		/// Gets the status changes from passive abilities.
		/// </summary>
		/// <param name='status'>
		/// The status value changes (absolute).
		/// </param>
		/// <param name='statusPercent'>
		/// The status value changes (percent).
		/// </param>
		/// <param name='chance'>
		/// The chance changes.
		/// </param>
		/// <param name='atkBonus'>
		/// Attack attribute bonuses.
		/// </param>
		/// <param name='defBonus'>
		/// Defence attribute bonuses.
		/// </param>
		public void GetStatusChanges(ref int[] status, ref float[] statusPercent, 
			ref float[] chance, ref AttributeChange[] atkBonus, ref AttributeChange[] defBonus)
		{
			for(int i=0; i<this.passive.Count; i++)
			{
				this.passive[i].GetPassiveLevel().bonus.GetBonus(
					ref status, ref statusPercent, ref chance, ref atkBonus, ref defBonus);
			}
		}
		
		/// <summary>
		/// Applies the auto status effects of passive abilities.
		/// </summary>
		public void SetStartEffects()
		{
			for(int i=0; i<this.passive.Count; i++)
			{
				this.passive[i].GetPassiveLevel().autoEffects.ChangeEffects(this.owner, this.owner);
			}
		}
		
		/// <summary>
		/// Removes the auto status effects of passive abilities.
		/// </summary>
		public void RemoveStartEffects()
		{
			for(int i=0; i<this.passive.Count; i++)
			{
				this.passive[i].GetPassiveLevel().autoEffects.RemoveEffects(this.owner);
			}
		}
		
		/// <summary>
		/// Checks the passive abilities if a status effect can be applied.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the status effect can be applied; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='effectID'>
		/// The ID (index) of the status effect.
		/// </param>
		public bool CanApplyEffect(int effectID)
		{
			for(int i=0; i<this.passive.Count; i++)
			{
				if(!this.passive[i].GetPassiveLevel().autoEffects.CanApplyEffect(effectID))
				{
					return false;
				}
			}
			return true;
		}
		
		/// <summary>
		/// Checks the passive abilities if a status effect can be removed.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the status effect can be removed; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='effectID'>
		/// The ID (index) of the status effect
		/// </param>
		public bool CanRemoveEffect(int effectID)
		{
			for(int i=0; i<this.passive.Count; i++)
			{
				if(!this.passive[i].GetPassiveLevel().autoEffects.CanRemoveEffect(effectID))
				{
					return false;
				}
			}
			return true;
		}
		
		
		/*
		============================================================================
		Learn functions
		============================================================================
		*/
		/// <summary>
		/// Forgets an ability.
		/// </summary>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to display in the console.
		/// </param>
		public bool Forget(int id, bool showConsole)
		{
			if(this.HasLearned(id, 0))
			{
				AbilityShortcut ab = this.GetLearned(id);
				if(ab != null)
				{
					ArrayHelper.Remove(ref this.learned, ab);
					ab.UnregisterStatusChanges(this.owner);
					this.CreateAbilities();
					this.owner.MarkResetStatus();
					
					if(showConsole && ORK.ConsoleSettings.displayForgetting)
					{
						Ability ability = ORK.Abilities.Get(id);
						if(ability.ownConsoleForgetting)
						{
							ability.consoleForgetting.PrintForgetRange(this.owner, ability);
						}
						else
						{
							ORK.ConsoleSettings.forgetAbility.PrintForgetRange(this.owner, ability);
						}
					}
					
					return true;
				}
			}
			return false;
		}
		
		/// <summary>
		/// Learns an ability.
		/// </summary>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='lvl'>
		/// The level that will be learned
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to display in the console.
		/// </param>
		public bool Learn(int id, int lvl, bool showConsole)
		{
			if(!this.HasLearned(id, lvl))
			{
				bool add = true;
				for(int i=0; i<this.learned.Length; i++)
				{
					if(this.learned[i].ID == id)
					{
						PassiveAbility passiveLevel = this.learned[i].GetPassiveLevel();
						this.learned[i].Level = lvl;
						this.learned[i].SetUseLevel(lvl);
						add = false;
						
						if(passiveLevel != null)
						{
							passiveLevel.autoEffects.RemoveEffects(this.owner);
						}
						
						break;
					}
				}
				if(add)
				{
					AbilityShortcut ab = new AbilityShortcut(id, lvl, AbilityActionType.Ability);
					ArrayHelper.Add(ref this.learned, ab);
					ab.RegisterStatusChanges(this.owner);
				}
				
				if(showConsole && ORK.ConsoleSettings.displayLearning)
				{
					Ability ability = ORK.Abilities.Get(id);
					if(ability.ownConsoleLearning)
					{
						ability.consoleLearning.PrintLearnRange(this.owner, ability);
					}
					else
					{
						ORK.ConsoleSettings.learnAbility.PrintLearnRange(this.owner, ability);
					}
				}
				
				this.CreateAbilities();
				this.owner.MarkResetStatus();
				return true;
			}
			return false;
		}
		
		
		/*
		============================================================================
		List functions
		============================================================================
		*/
		/// <summary>
		/// Gets a useable ability (not passive), searches in base attacks, counter attack and abilities.
		/// </summary>
		/// <returns>
		/// The ability.
		/// </returns>
		/// <param name='abilityID'>
		/// The ID (index) of the ability.
		/// </param>
		public AbilityShortcut GetUseable(int abilityID)
		{
			for(int i=0; i<this.attack.Length; i++)
			{
				if(this.attack[i].ID == abilityID)
				{
					return this.attack[i];
				}
			}
			if(this.counter.ID == abilityID)
			{
				return this.counter;
			}
			for(int i=0; i<this.both.Count; i++)
			{
				if(this.both[i].ID == abilityID)
				{
					return this.both[i];
				}
			}
			return null;
		}
		
		/// <summary>
		/// Gets a list of abilities useable in a specified mode.
		/// </summary>
		/// <returns>
		/// The ability list.
		/// </returns>
		/// <param name='useIn'>
		/// Either useable in <c>Field</c>, <c>Battle</c>, <c>Both</c> or <c>None</c> (passive abilities).
		/// </param>
		public List<AbilityShortcut> GetAbilities(UseableIn useIn)
		{
			if(UseableIn.Field.Equals(useIn))
			{
				return this.field;
			}
			else if(UseableIn.Battle.Equals(useIn))
			{
				return this.battle;
			}
			else if(UseableIn.Both.Equals(useIn))
			{
				return this.both;
			}
			else if(UseableIn.None.Equals(useIn))
			{
				return this.passive;
			}
			return new List<ORKFramework.AbilityShortcut>();
		}
		
		/// <summary>
		/// Gets a learned ability.
		/// </summary>
		/// <returns>
		/// The ability if learned, else <c>null</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		public AbilityShortcut GetLearned(int id)
		{
			for(int i=0; i<this.learned.Length; i++)
			{
				if(this.learned[i].ID == id)
				{
					return this.learned[i];
				}
			}
			return null;
		}
		
		/// <summary>
		/// Gets a known ability.
		/// </summary>
		/// <returns>
		/// The ability if known, else <c>null</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		public AbilityShortcut Get(int id)
		{
			for(int i=0; i<this.both.Count; i++)
			{
				if(this.both[i].ID == id)
				{
					return this.both[i];
				}
			}
			for(int i=0; i<this.passive.Count; i++)
			{
				if(this.passive[i].ID == id)
				{
					return this.passive[i];
				}
			}
			return null;
		}
		
		/// <summary>
		/// Gets a known ability and tries to set it's use level (only non-passive abilities).
		/// </summary>
		/// <returns>
		/// The ability if known, else <c>null</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='lvl'>
		/// The level that should be used.
		/// </param>
		public AbilityShortcut Get(int id, int lvl)
		{
			for(int i=0; i<this.both.Count; i++)
			{
				if(this.both[i].ID == id)
				{
					this.both[i].SetUseLevel(lvl);
					return this.both[i];
				}
			}
			for(int i=0; i<this.passive.Count; i++)
			{
				if(this.passive[i].ID == id)
				{
					return this.passive[i];
				}
			}
			return null;
		}
		
		/// <summary>
		/// Gets an ability matching a defined ability.
		/// </summary>
		/// <param name='shortcut'>
		/// The AbilityShortcut to look for.
		/// </param>
		public AbilityShortcut Get(AbilityShortcut shortcut)
		{
			if(AbilityActionType.BaseAttack.Equals(shortcut.Type))
			{
				for(int i=0; i<this.attack.Length; i++)
				{
					if(this.attack[i].ID == shortcut.ID &&
						this.attack[i].Level >= shortcut.Level)
					{
						this.attack[i].SetUseLevel(shortcut.Level);
						return this.attack[i];
					}
				}
			}
			else if(AbilityActionType.CounterAttack.Equals(shortcut.Type))
			{
				if(this.counter.ID == shortcut.ID && 
					this.counter.Level >= shortcut.Level)
				{
					this.counter.SetUseLevel(shortcut.Level);
					return this.counter;
				}
			}
			else if(AbilityActionType.Ability.Equals(shortcut.Type))
			{
				for(int i=0; i<this.both.Count; i++)
				{
					if(this.both[i].ID == shortcut.ID &&
						this.both[i].Level >= shortcut.Level)
					{
						this.both[i].SetUseLevel(shortcut.Level);
						return this.both[i];
					}
				}
			}
			return null;
		}
		
		/// <summary>
		/// Gets a list of all available ability types.
		/// </summary>
		/// <returns>
		/// The ability types as a list of integers (IDs of the types).
		/// </returns>
		public List<int> GetTypes()
		{
			List<int> list = new List<int>();
			for(int i=0; i<this.both.Count; i++)
			{
				if(!list.Contains(this.both[i].TypeID))
				{
					list.Add(this.both[i].TypeID);
				}
			}
			for(int i=0; i<this.passive.Count; i++)
			{
				if(!list.Contains(this.passive[i].TypeID))
				{
					list.Add(this.passive[i].TypeID);
				}
			}
			return list;
		}
		
		/// <summary>
		/// Gets a list of all available ability types useable in a specified mode.
		/// </summary>
		/// <returns>
		/// The ability types as a list of integers (IDs of the types).
		/// </returns>
		/// <param name='useIn'>
		/// Either useable in <c>Field</c>, <c>Battle</c>, <c>Both</c> or <c>None</c> (passive abilities).
		/// </param>
		public List<int> GetTypes(UseableIn useIn)
		{
			List<int> list = new List<int>();
			List<AbilityShortcut> abilities = this.GetAbilities(useIn);
			for(int i=0; i<abilities.Count; i++)
			{
				if(!list.Contains(abilities[i].TypeID))
				{
					list.Add(abilities[i].TypeID);
				}
			}
			return list;
		}
		
		/// <summary>
		/// Gets a list of abilities by ability type.
		/// </summary>
		/// <returns>
		/// The list of abilities.
		/// </returns>
		/// <param name='index'>
		/// The ID (index) of the ability type to look for.
		/// </param>
		/// <param name='addAttacks'>
		/// <c>true</c> to add base attack abilities.
		/// </param>
		/// <param name='addCounters'>
		/// <c>true</c> to add counter attack abilities.
		/// </param>
		/// <param name='addClass'>
		/// <c>true</c> to add class abilities.
		/// </param>
		/// <param name='addActive'>
		/// <c>true</c> to add active abilities.
		/// </param>
		/// <param name='addPassive'>
		/// <c>true</c> to add passive abilities.
		/// </param>
		public List<AbilityShortcut> GetByType(int index, bool addAttacks, bool addCounters, bool addClass, bool addActive, bool addPassive)
		{
			List<AbilityShortcut> list = new List<AbilityShortcut>();
			
			// base attacks
			if(addAttacks)
			{
				for(int i=0; i<this.attack.Length; i++)
				{
					if(index < 0 || this.attack[i].TypeID == index)
					{
						list.Add(this.attack[i]);
					}
				}
			}
			// counter attacks
			if(addCounters && (index < 0 || this.counter.TypeID == index))
			{
				list.Add(this.counter);
			}
			// class ability
			if(addClass && this.HasClassAbility() && 
				(index < 0 || this.classAbility[this.owner.ClassID].TypeID == index))
			{
				list.Add(this.classAbility[this.owner.ClassID]);
			}
			// active abilities
			if(addActive)
			{
				for(int i=0; i<this.both.Count; i++)
				{
					if(index < 0 || this.both[i].TypeID == index)
					{
						list.Add(this.both[i]);
					}
				}
			}
			// passive abilities
			if(addPassive)
			{
				for(int i=0; i<this.passive.Count; i++)
				{
					if(index < 0 || this.passive[i].TypeID == index)
					{
						list.Add(this.passive[i]);
					}
				}
			}
			
			return list;
		}
		
		/// <summary>
		/// Gets a list of abilities by ability type useable in a specified mode.
		/// </summary>
		/// <returns>
		/// The list of abilities.
		/// </returns>
		/// <param name='index'>
		/// The ID (index) of the ability type.
		/// </param>
		/// <param name='useIn'>
		/// Either useable in <c>Field</c>, <c>Battle</c>, <c>Both</c> or <c>None</c> (passive abilities).
		/// </param>
		public List<AbilityShortcut> GetByType(int index, UseableIn useIn)
		{
			if(index < 0)
			{
				return this.GetAbilities(useIn);
			}
			else
			{
				List<AbilityShortcut> list = new List<AbilityShortcut>();
				List<AbilityShortcut> abilities = this.GetAbilities(useIn);
				for(int i=0; i<abilities.Count; i++)
				{
					if(abilities[i].TypeID == index)
					{
						list.Add(abilities[i]);
					}
				}
				return list;
			}
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		/// <summary>
		/// Determines whether the specified ability can receive experience.
		/// The ability has to be a base attack, counter attack or a learned ability to receive experience.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability can receive experience; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='ab'>
		/// The AbilityShortcut representing the ability.
		/// </param>
		public bool CanGetUseExperience(AbilityShortcut ab)
		{
			if(this.counter == ab)
			{
				return true;
			}
			for(int i=0; i<this.attack.Length; i++)
			{
				if(this.attack[i] == ab)
				{
					return true;
				}
			}
			for(int i=0; i<this.learned.Length; i++)
			{
				if(this.learned[i] == ab)
				{
					return true;
				}
			}
			return false;
		}
		
		/// <summary>
		/// Determines whether the specified ability has been learned.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability has been learned; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='ab'>
		/// The AbilityShortcut representing the ability.
		/// </param>
		public bool IsLearned(AbilityShortcut ab)
		{
			for(int i=0; i<this.learned.Length; i++)
			{
				if(this.learned[i] == ab)
				{
					return true;
				}
			}
			return false;
		}
		
		/// <summary>
		/// Determines whether the specified ability has been learned.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability has been learned; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='lvl'>
		/// The minimum level that has to be learned.
		/// </param>
		public bool HasLearned(int id, int lvl)
		{
			for(int i=0; i<this.learned.Length; i++)
			{
				if(this.learned[i].ID == id &&
					this.learned[i].Level >= lvl)
				{
					return true;
				}
			}
			return false;
		}
		
		/// <summary>
		/// Determines whether the specified ability is available.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability is available; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='shortcut'>
		/// The AbilityShortcut representing the ability.
		/// </param>
		public bool Has(AbilityShortcut shortcut)
		{
			if(AbilityActionType.BaseAttack.Equals(shortcut.Type))
			{
				for(int i=0; i<this.attack.Length; i++)
				{
					if(this.attack[i].ID == shortcut.ID &&
						this.attack[i].Level >= shortcut.Level)
					{
						return true;
					}
				}
			}
			else if(AbilityActionType.CounterAttack.Equals(shortcut.Type))
			{
				return this.counter.ID == shortcut.ID && 
					this.counter.Level >= shortcut.Level;
			}
			else if(AbilityActionType.Ability.Equals(shortcut.Type))
			{
				for(int i=0; i<this.both.Count; i++)
				{
					if(this.both[i].ID == shortcut.ID &&
						this.both[i].Level >= shortcut.Level)
					{
						return true;
					}
				}
			}
			return false;
		}
		
		/// <summary>
		/// Determines whether the specified ability is available.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability is available; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='lvl'>
		/// The minimum level that has to be learned.
		/// </param>
		public bool Has(int id, int lvl)
		{
			for(int i=0; i<this.both.Count; i++)
			{
				if(this.both[i].ID == id &&
					this.both[i].Level >= lvl)
				{
					return true;
				}
			}
			for(int i=0; i<this.passive.Count; i++)
			{
				if(this.passive[i].ID == id &&
					this.passive[i].Level >= lvl)
				{
					return true;
				}
			}
			return false;
		}
		
		/// <summary>
		/// Determines whether the specified ability type is available.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability type is available; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='index'>
		/// The ID (index) of the ability type.
		/// </param>
		public bool HasType(int index)
		{
			for(int i=0; i<this.both.Count; i++)
			{
				if(this.both[i].TypeID == index)
				{
					return true;
				}
			}
			for(int i=0; i<this.passive.Count; i++)
			{
				if(this.passive[i].TypeID == index)
				{
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Equipment functions
		============================================================================
		*/
		/// <summary>
		/// Adds an ability that is attached to an equipment.
		/// </summary>
		/// <param name='ea'>
		/// The equipment ability.
		/// </param>
		public void AddEquipmentAbility(EquipmentAbility ea)
		{
			if(!this.equip.Contains(ea))
			{
				this.equip.Add(ea);
				this.CreateAbilities();
				this.owner.MarkResetStatus();
			}
		}
		
		/// <summary>
		/// Removes an ability that is attached an equipment.
		/// </summary>
		/// <param name='ea'>
		/// The equipment ability.
		/// </param>
		public void RemoveEquipmentAbility(EquipmentAbility ea)
		{
			if(this.equip.Contains(ea))
			{
				this.equip.Remove(ea);
				this.CreateAbilities();
				
				if(ORK.Abilities.Get(ea.abilityID).IsUseable(UseableIn.None))
				{
					new AbilityShortcut(ea.abilityID, ea.abilityLevel, 
						AbilityActionType.Ability).RemoveStartEffects(this.owner);
				}
				
				this.owner.MarkResetStatus();
			}
		}
		
		/// <summary>
		/// Resets all equipment abilities.
		/// All abilities coming from equipments will be removed and the current equipment will be checked for abilities.
		/// </summary>
		public void ResetEquipmentAbilities()
		{
			this.equip = new List<EquipmentAbility>();
			for(int i=0; i<ORK.EquipmentParts.Count; i++)
			{
				if(this.owner.Equipment[i].Equipped)
				{
					this.owner.Equipment[i].Equipment.CheckAbilities(this.owner);
				}
			}
			this.CreateAbilities();
		}
		
		
		/*
		============================================================================
		Class ability functions
		============================================================================
		*/
		/// <summary>
		/// Checks if the current class of the combatant has a class ability and adds it, if it's not yet added to the combatant.
		/// </summary>
		public void UpdateClassAbility()
		{
			if(!this.classAbility.ContainsKey(this.owner.ClassID))
			{
				Class c = ORK.Classes.Get(this.owner.ClassID);
				if(c.useClassAbility)
				{
					this.classAbility.Add(this.owner.ClassID, c.classAbility.GetAbility(AbilityActionType.Ability));
				}
			}
		}
		
		/// <summary>
		/// Determines whether the class ability of the combatant's current class is available.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the class ability is available; otherwise, <c>false</c>.
		/// </returns>
		public bool HasClassAbility()
		{
			return this.classAbility.ContainsKey(this.owner.ClassID) && 
				this.classAbility[this.owner.ClassID] != null;
		}
		
		/// <summary>
		/// Gets the class ability.
		/// </summary>
		/// <returns>
		/// The class ability (if available); otherwise <c>null</c>.
		/// </returns>
		public AbilityShortcut GetClassAbility()
		{
			if(this.classAbility.ContainsKey(this.owner.ClassID))
			{
				return this.classAbility[this.owner.ClassID];
			}
			return null;
		}
		
		
		/*
		============================================================================
		Ability tree functions
		============================================================================
		*/
		/// <summary>
		/// Learns an ability tree.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability tree has been learned; otherwise <c>false</c>.
		/// </returns>
		/// <param name='abilityTreeID'>
		/// The ID (index) of the ability tree.
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to show learning the ability tree in the console.
		/// </param>
		public bool LearnTree(int abilityTreeID, bool showConsole)
		{
			if(!this.abilityTree.Contains(abilityTreeID))
			{
				this.abilityTree.Add(abilityTreeID);
				
				if(showConsole && ORK.ConsoleSettings.displayLearning)
				{
					AbilityTree tree = ORK.AbilityTrees.Get(abilityTreeID);
					if(tree.ownConsoleLearning)
					{
						tree.consoleLearning.PrintLearnRange(this.owner, tree);
					}
					else
					{
						ORK.ConsoleSettings.learnAbilityTree.PrintLearnRange(this.owner, tree);
					}
				}
				
				return true;
			}
			return false;
		}
		
		/// <summary>
		/// Forgets an ability tree.
		/// </summary>
		/// <param name='abilityTreeID'>
		/// The ID (index) of the ability tree.
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to show learning the ability tree in the console.
		/// </param>
		public void ForgetTree(int abilityTreeID, bool showConsole)
		{
			if(this.abilityTree.Contains(abilityTreeID))
			{
				this.abilityTree.Remove(abilityTreeID);
				
				if(showConsole && ORK.ConsoleSettings.displayForgetting)
				{
					AbilityTree tree = ORK.AbilityTrees.Get(abilityTreeID);
					if(tree.ownConsoleForgetting)
					{
						tree.consoleForgetting.PrintForgetRange(this.owner, tree);
					}
					else
					{
						ORK.ConsoleSettings.forgetAbilityTree.PrintForgetRange(this.owner, tree);
					}
				}
			}
		}
		
		/// <summary>
		/// Determines whether the combatant has learned an ability tree.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability tree has been learned; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='abilityTreeID'>
		/// The ID (index) of the ability tree.
		/// </param>
		public bool HasTree(int abilityTreeID)
		{
			return this.abilityTree.Contains(abilityTreeID);
		}
		
		/// <summary>
		/// Gets a list of learned ability trees.
		/// </summary>
		/// <returns>
		/// The list of ability trees.
		/// The ability trees are represented by their ID (index).
		/// </returns>
		public List<int> GetTrees()
		{
			return new List<int>(this.abilityTree);
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			if(this.counter != null)
			{
				data.Set("counter", this.counter.SaveGame());
			}
			
			DataObject[] tmp = new DataObject[this.attack.Length];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.attack[i].SaveGame();
			}
			data.Set("attack", tmp);
			
			DataObject cab = new DataObject();
			foreach(KeyValuePair<int, AbilityShortcut> pair in this.classAbility)
			{
				cab.Set(pair.Key.ToString(), pair.Value.SaveGame());
			}
			data.Set("cab", cab);
			
			tmp = new DataObject[this.learned.Length];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.learned[i].SaveGame();
			}
			data.Set("learned", tmp);
			
			data.Set("abilityTree", this.abilityTree.ToArray());
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				DataObject tmp = data.GetFile("counter");
				if(tmp != null)
				{
					this.counter = new AbilityShortcut();
					this.counter.LoadGame(tmp);
					this.counter.RegisterStatusChanges(this.owner);
				}
				
				DataObject[] tmp2 = data.GetFileArray("attack");
				if(tmp2 != null)
				{
					this.attack = new AbilityShortcut[tmp2.Length];
					for(int i=0; i<tmp2.Length; i++)
					{
						this.attack[i] = new AbilityShortcut();
						this.attack[i].LoadGame(tmp2[i]);
						this.attack[i].RegisterStatusChanges(this.owner);
					}
				}
				
				DataObject cab = data.GetFile("cab");
				if(cab != null)
				{
					Dictionary<string, AbilityShortcut> list = cab.GetData<AbilityShortcut>(typeof(AbilityShortcut));
					if(list != null)
					{
						foreach(KeyValuePair<string, AbilityShortcut> pair in list)
						{
							this.classAbility.Add(int.Parse(pair.Key), pair.Value);
						}
					}
				}
				
				tmp2 = data.GetFileArray("learned");
				if(tmp2 != null)
				{
					this.learned = new AbilityShortcut[tmp2.Length];
					for(int i=0; i<tmp2.Length; i++)
					{
						this.learned[i] = new AbilityShortcut();
						this.learned[i].LoadGame(tmp2[i]);
						this.learned[i].RegisterStatusChanges(this.owner);
					}
				}
				
				int[] tmp3;
				data.Get("abilityTree", out tmp3);
				if(tmp3 != null)
				{
					this.abilityTree = new List<int>(tmp3);
				}
			}
		}
	}
}
