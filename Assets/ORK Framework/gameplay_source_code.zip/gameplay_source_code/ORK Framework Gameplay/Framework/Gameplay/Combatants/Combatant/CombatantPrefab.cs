
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantPrefab : BaseData
	{
		// prefab
		[ORKEditorHelp("Prefab", "Select the prefab of this combatant.\n" +
			"The prefab is used to spawn the combatant in the field and in battle.", "")]
		public GameObject prefab;
		
		[ORKEditorHelp("Child as Root", "The defined child object of the game object " +
			"(selected prefab) will be used as root object.\n" +
			"This can be used e.g. if the prefab root isn't the moving object.\n" +
			"Usage: Path/to/Child. Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string prefabRoot = "";
		
		[ORKEditorHelp("Box Radius", "The box radius is a radius around the combatant and represents " +
		 	"the combatants width.\n" +
		 	"It's used to calculate distances, e.g. for movement and range checks.\n" +
			"E.g.: Two combatants are 10 world units apart, one combatant has a box width of 4, " +
			"the other has a box width of 1.5 - the calculated distance would be 4.5.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float boxRadius = 0;
		
		[ORKEditorHelp("Spawn Offset", "Offset added to the combatants game object position when spawning.", "")]
		public Vector3 spawnOffset = Vector3.zero;
		
		
		// status requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;
		
		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "", 
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be met to use this prefab.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[0];
		
		
		// variable conditions
		[ORKEditorHelp("Use Object Variable", "Use object variables of the combatant.\n" +
			"The combatant's game object must have an 'Object Variables' component attached, " +
			"else the check fails.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Conditions")]
		public bool useObjectVariable = false;
		
		public VariableCondition condition = new VariableCondition();
		
		public CombatantPrefab()
		{
			
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(Combatant combatant)
		{
			return this.prefab != null && combatant != null && 
				StatusRequirement.Check(combatant, this.req, this.needed) && 
				this.CheckVariables(combatant);
		}
		
		public bool CheckVariables(Combatant combatant)
		{
			if(this.useObjectVariable)
			{
				if(combatant != null && combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						return this.condition.CheckVariables(comp.GetHandler());
					}
				}
			}
			else
			{
				return this.condition.CheckVariables(ORK.Game.Variables);
			}
			return false;
		}
	}
}
