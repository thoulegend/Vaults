
using UnityEngine;
using ORKFramework.Animations;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantStatus : ISaveData
	{
		private Combatant owner;
		
		private StatusChangeInformation preview;
		
		
		// values
		private StatusValue[] value;
		
		private float[] chanceBonus = new float[13];
		
		
		// effects
		private List<StatusEffect> effect = new List<StatusEffect>();
		
		private int stopMove = 0;
		
		private int stopMovement = 0;
	
		private int autoAttack = 0;
	
		private int attackAllies = 0;
	
		private int blockAttack = 0;
	
		private int blockAbilities = 0;
	
		private int blockItems = 0;
	
		private int blockDefend = 0;
	
		private int blockEscape = 0;
	
		private int blockEquipmentChange = 0;
	
		private int blockCommand = 0;
	
		private int reflectAbilities = 0;
		
		private int noTurnOrderChange = 0;
		
		private int noTurnRemove = 0;
		
		
		// attributes
		private AttackAttribute[] attackAttribute;
		
		private DefenceAttribute[] defenceAttribute;
		
		private DefAttrID[] defAttrID;
		
		
		// events
		public event StatusEffectChanged StatusEffectChanged;
		
		public CombatantStatus(Combatant owner)
		{
			this.owner = owner;
			
			// value values
			this.value = new StatusValue[ORK.StatusValues.Count];
			for(int i=0; i<this.value.Length; i++)
			{
				this.value[i] = ORK.StatusValues.Create(i, this.owner);
			}
			
			// defence attribute IDs
			this.defAttrID = new DefAttrID[ORK.DefenceAttributes.Count];
			for(int i=0; i<this.defAttrID.Length; i++)
			{
				this.defAttrID[i] = new DefAttrID(i, this.owner);
			}
		}
		
		public StatusValue this[int index]
		{
			get{ return this.value[index];}
		}
		
		
		/*
		============================================================================
		Selected shortcut functions
		============================================================================
		*/
		public void SelectedShortcutChanged(IShortcut shortcut)
		{
			if(shortcut is EquipPartWrapperShortcut)
			{
				EquipPartWrapperShortcut partWrapper = shortcut as EquipPartWrapperShortcut;
				this.ResetPreview(this.GetStatusChanges(this.owner.Equipment.GetFakeEquip(partWrapper.PartID, partWrapper.Equip)));
			}
			else if(shortcut is EquipShortcut)
			{
				this.ResetPreview(this.GetStatusChanges(this.owner.Equipment.GetFakeEquip(-1, shortcut as EquipShortcut)));
			}
			else if(this.preview != null)
			{
				this.ResetPreview(null);
			}
		}
		
		public bool PreviewAvailable
		{
			get{ return this.preview != null;}
		}
		
		public StatusChangeInformation Preview
		{
			get{ return this.preview;}
		}
		
		
		/*
		============================================================================
		Initialization functions
		============================================================================
		*/
		public void Init(StatusDevelopment classStatDev)
		{
			DifficultyFaction factionMultipliers = ORK.Difficulties.Get(ORK.Game.Difficulty).GetMultipliers(this.owner.Group.FactionID);
			
			// EXPERIENCE and NORMAL type status values
			for(int i=0; i<this.value.Length; i++)
			{
				if(!this.value[i].IsConsumable())
				{
					int initValue = 0;
					
					// EXPERIENCE type class level up
					if(classStatDev != null && this.value[i].IsClassLevel())
					{
						if(this.value[i].Setting.initExpToLevel)
						{
							initValue += classStatDev.GetValueAtLevel(i, this.owner.ClassLevel);
						}
						else
						{
							initValue = this.value[i].Setting.minValue;
						}
					}
					// EXPERIENCE type
					else if(this.value[i].IsExperience())
					{
						if(this.owner.Setting.noStatusDevelopment)
						{
							initValue += this.owner.Setting.startValue[i];
						}
						else if(this.value[i].Setting.initExpToLevel)
						{
							initValue += this.GetValueAtLevel(i, this.owner.Level);
						}
						else
						{
							initValue = this.value[i].Setting.minValue;
						}
					}
					// NORMAL type
					else
					{
						if(this.owner.Setting.noStatusDevelopment)
						{
							initValue += this.owner.Setting.startValue[i];
						}
						else
						{
							initValue += this.GetValueAtLevel(i, this.owner.Level);
						}
						if(classStatDev != null && !this.value[i].IsExperience())
						{
							initValue += classStatDev.GetValueAtLevel(i, this.owner.ClassLevel);
						}
					}
					
					// difficulty value multipliers
					if(factionMultipliers != null)
					{
						initValue = (int)(initValue * factionMultipliers.statusMultiplier[i]);
					}
					this.value[i].InitValue(initValue);
				}
			}
			
			// CONSUMABLE type status values
			for(int i=0; i<this.value.Length; i++)
			{
				if(this.value[i].IsConsumable())
				{
					int initValue = 0;
					
					if(this.owner.Setting.noStatusDevelopment)
					{
						initValue += this.owner.Setting.startValue[this.value[i].Setting.maxStatusID];
					}
					else
					{
						initValue += this.GetValueAtLevel(this.value[i].Setting.maxStatusID, this.owner.Level);
					}
					if(classStatDev != null)
					{
						initValue += classStatDev.GetValueAtLevel(
							this.value[i].Setting.maxStatusID, this.owner.ClassLevel);
					}
					
					// difficulty value multipliers
					if(factionMultipliers != null)
					{
						initValue = (int)(initValue * factionMultipliers.statusMultiplier[this.value[i].Setting.maxStatusID]);
					}
					this.value[i].InitValue(initValue);
				}
			}
			
			// attack attributes
			this.attackAttribute = new AttackAttribute[ORK.AttackAttributes.Count];
			for(int i=0; i<this.attackAttribute.Length; i++)
			{
				// difficulty attack attributes multipliers
				if(factionMultipliers != null)
				{
					this.attackAttribute[i] = new AttackAttribute(ORK.AttackAttributes.Get(i), 
						this.owner, factionMultipliers.atkAttrMultiplier[i]);
				}
				else
				{
					this.attackAttribute[i] = new AttackAttribute(ORK.AttackAttributes.Get(i), 
						this.owner, 1);
				}
			}
			
			// defence attributes
			this.defenceAttribute = new DefenceAttribute[ORK.DefenceAttributes.Count];
			for(int i=0; i<this.defenceAttribute.Length; i++)
			{
				// difficulty defence attributes multipliers
				if(factionMultipliers != null)
				{
					this.defenceAttribute[i] = new DefenceAttribute(ORK.DefenceAttributes.Get(i), 
						this.owner, factionMultipliers.defAttrMultiplier[i]);
				}
				else
				{
					this.defenceAttribute[i] = new DefenceAttribute(ORK.DefenceAttributes.Get(i), 
						this.owner, 1);
				}
			}
			
			// defence attribute IDs
			for(int i=0; i<this.defAttrID.Length; i++)
			{
				this.defAttrID[i].InitID(this.owner.Setting.defenceAttributeID[i]);
			}
		}
		
		public void AddComponents()
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				this.effect[i].AddPrefabs(this.owner);
			}
		}
		
		public void EndBattle()
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				this.effect[i].EndBattle();
			}
		}
		
		
		/*
		============================================================================
		Bonus functions
		============================================================================
		*/
		public float GetHitBonus()
		{
			return this.chanceBonus[0];
		}
		
		public float GetCounterBonus()
		{
			return this.chanceBonus[1];
		}
		
		public float GetCriticalBonus()
		{
			return this.chanceBonus[2];
		}
		
		public float GetBlockBonus()
		{
			return this.chanceBonus[3];
		}
		
		public float GetEscapeBonus()
		{
			return this.chanceBonus[4];
		}
		
		public float GetWalkBonus()
		{
			return this.chanceBonus[5];
		}
		
		public float GetRunBonus()
		{
			return this.chanceBonus[6];
		}
		
		public float GetSprintBonus()
		{
			return this.chanceBonus[7];
		}
		
		public float GetItemStealBonus()
		{
			return this.chanceBonus[8];
		}
		
		public float GetMoneyStealBonus()
		{
			return this.chanceBonus[9];
		}
		
		public float GetItemLimitBonus()
		{
			return this.chanceBonus[10];
		}
		
		public float GetRandomBattleBonus()
		{
			return this.chanceBonus[11];
		}
		
		public float GetExperienceFactorBonus()
		{
			return this.chanceBonus[12];
		}
		
		
		/*
		============================================================================
		Level functions
		============================================================================
		*/
		public int GetValueAtLevel(int statusID, int lvl)
		{
			if(this.owner.Setting.noStatusDevelopment)
			{
				return this.owner.Setting.startValue[statusID];
			}
			else
			{
				return ORK.StatusDevelopments.Get(this.owner.Setting.statusDevelopmentID).GetValueAtLevel(statusID, lvl);
			}
		}
		
		
		/*
		============================================================================
		Attack attribute functions
		============================================================================
		*/
		public AttackAttribute GetAttackAttribute(int index)
		{
			return this.attackAttribute[index];
		}
		
		public int[] GetEffectAttackAttributes()
		{
			int[] atkAttr = new int[this.attackAttribute.Length];
			for(int i=0; i<atkAttr.Length; i++)
			{
				atkAttr[i] = -1;
			}
			for(int i=0; i<this.effect.Count; i++)
			{
				for(int j=0; j<this.effect[i].Setting.setAttackAttribute.Length; j++)
				{
					// only set the first found
					if(this.effect[i].Setting.setAttackAttribute[j].setAttribute &&
						atkAttr[j] == -1)
					{
						atkAttr[j] = this.effect[i].Setting.setAttackAttribute[j].attribute;
					}
				}
			}
			return atkAttr;
		}
		
		
		/*
		============================================================================
		Defence attribute functions
		============================================================================
		*/
		public int[] GetDefenceAttributeIDs()
		{
			int[] ids = new int[this.defAttrID.Length];
			for(int i=0; i<ids.Length; i++)
			{
				ids[i] = this.defAttrID[i].GetID();
			}
			return ids;
		}
		
		public DefAttrID GetDefenceAttributeID(int index)
		{
			return this.defAttrID[index];
		}
		
		public DefenceAttribute GetDefenceAttribute(int index)
		{
			return this.defenceAttribute[index];
		}
		
		
		/*
		============================================================================
		Status value functions
		============================================================================
		*/
		public void CheckStatusBounds()
		{
			for(int i=0; i<ORK.StatusValues.Count; i++)
			{
				this.value[i].CheckBounds(false, false);
			}
			this.owner.CheckDeath();
			this.owner.CheckLevelUp();
		}
		
		public void Regenerate()
		{
			for(int i=0; i<this.value.Length; i++)
			{
				if(this.value[i].IsConsumable() && 
					!this.value[i].Setting.noRegeneration)
				{
					this.value[i].SetValue(this.value[i].GetMaxValue(), false, false, false, true, false, false);
				}
			}
		}
		
		public void SetConsumableStartValues()
		{
			for(int i=0; i<this.value.Length; i++)
			{
				if(this.value[i].IsConsumable())
				{
					if(ValueSetter.Value.Equals(this.value[i].Setting.startSetIn))
					{
						this.value[i].InitValue(this.value[i].Setting.startValue);
					}
					else if(ValueSetter.Percent.Equals(this.value[i].Setting.startSetIn))
					{
						this.value[i].InitValue((int)((this.value[i].GetMaxValue() * this.value[i].Setting.startValue) / 100));
					}
					this.value[i].CheckBounds(true, false);
				}
			}
		}
		
		public void ResetStatus()
		{
			StatusChangeInformation info = this.GetStatusChanges(null);
			
			this.chanceBonus = info.chanceBonus;
			
			// add attack attribute bonus
			for(int i=0; i<this.attackAttribute.Length; i++)
			{
				this.attackAttribute[i].ResetValues(info.atkAttr[i].bonus);
			}
			
			// add defence attribute bonus
			for(int i=0; i<this.defenceAttribute.Length; i++)
			{
				this.defenceAttribute[i].ResetValues(info.defAttr[i].bonus);
			}
			
			// set defence attribute IDs
			for(int i=0; i<this.defAttrID.Length; i++)
			{
				if(info.defIDs[i] != this.defAttrID[i].GetID())
				{
					this.defAttrID[i].SetID(info.defIDs[i]);
				}
			}
			
			// add value bonus
			for(int i=0; i<this.value.Length; i++)
			{
				if(this.value[i].IsNormal())
				{
					this.value[i].ResetValue(info.statusValue[i], false);
				}
			}
			// calculate combined values
			for(int i=0; i<this.value.Length; i++)
			{
				this.value[i].FinalValue(info.statusValuePercent[i]);
			}
			// check bounds
			for(int i=0; i<this.value.Length; i++)
			{
				this.value[i].CheckBounds(true, false);
			}
			
			// reset value changes
			for(int i=0; i<this.effect.Count; i++)
			{
				this.effect[i].ResetChange(this.owner);
			}
			this.owner.Inventory.CheckSpace(0);
			this.owner.Animations.UpdateAnimations();
			this.owner.UpdateMoveSpeed();
			this.owner.FireHUDUpdate();
			this.owner.Equipment.CheckAvailableParts(true);
		}
		
		public StatusChangeInformation GetStatusChanges(EquipPartSlot[] equipment)
		{
			StatusChangeInformation info = new StatusChangeInformation(this.owner);
			
			// combatant bonus
			this.owner.Setting.bonus.GetBonus(ref info.statusValue, ref info.statusValuePercent, 
				ref info.chanceBonus, ref info.atkAttr, ref info.defAttr);
			
			// class bonus
			ORK.Classes.Get(this.owner.ClassID).bonus.GetBonus(ref info.statusValue, ref info.statusValuePercent, 
				ref info.chanceBonus, ref info.atkAttr, ref info.defAttr);
			
			// ability bonus
			this.owner.Abilities.GetStatusChanges(ref info.statusValue, ref info.statusValuePercent, 
				ref info.chanceBonus, ref info.atkAttr, ref info.defAttr);
			
			// equip bonus
			if(equipment == null)
			{
				this.owner.Equipment.GetStatusChanges(ref info.statusValue, ref info.statusValuePercent, 
					ref info.chanceBonus, ref info.atkAttr, ref info.defAttr, ref info.defIDs);
			}
			else
			{
				CombatantEquipment.GetStatusChanges(equipment, ref info.statusValue, ref info.statusValuePercent, 
					ref info.chanceBonus, ref info.atkAttr, ref info.defAttr, ref info.defIDs);
			}
			
			// effects bonus and def attr IDs in reverse order (priority)
			for(int i=this.effect.Count-1; i>=0; i--)
			{
				this.effect[i].Setting.bonus.GetBonus(ref info.statusValue, ref info.statusValuePercent, 
					ref info.chanceBonus, ref info.atkAttr, ref info.defAttr);
				this.effect[i].Setting.GetDefenceAttributeIDs(ref info.defIDs);
			}
			
			// add percent value bonus to value bonus
			for(int i=0; i<this.value.Length; i++)
			{
				if(this.value[i].IsNormal() && !this.value[i].Setting.combined && 
					info.statusValuePercent[i] != 0)
				{
					info.statusValue[i] += (int)(((this.value[i].GetBaseValue() + info.statusValue[i]) * 
						info.statusValuePercent[i]) / 100);
				}
			}
			
			return info;
		}
		
		public void ResetPreview(StatusChangeInformation info)
		{
			this.preview = info;
			
			if(this.preview != null)
			{
				// add attack attribute bonus
				for(int i=0; i<this.attackAttribute.Length; i++)
				{
					float[] baseValues = this.attackAttribute[i].GetBaseValues();
					for(int j=0; j<baseValues.Length; j++)
					{
						this.preview.atkAttr[i].bonus[j] += baseValues[j];
						
						ValueHelper.Limit(ref this.preview.atkAttr[i].bonus[j], 
							this.attackAttribute[i].GetMinValue(), this.attackAttribute[i].GetMaxValue());
					}
				}
				// add defence attribute bonus
				for(int i=0; i<this.defenceAttribute.Length; i++)
				{
					float[] baseValues = this.defenceAttribute[i].GetBaseValues();
					for(int j=0; j<baseValues.Length; j++)
					{
						this.preview.defAttr[i].bonus[j] += baseValues[j];
						
						ValueHelper.Limit(ref this.preview.defAttr[i].bonus[j], 
							this.defenceAttribute[i].GetMinValue(), this.defenceAttribute[i].GetMaxValue());
					}
				}
				// add value bonus
				for(int i=0; i<this.value.Length; i++)
				{
					if(this.value[i].IsNormal())
					{
						this.preview.statusValue[i] += this.value[i].GetBaseValue();
						this.value[i].FinalPreviewValue(info.statusValuePercent[i]);
						
						ValueHelper.Limit(ref this.preview.statusValue[i], 
							this.value[i].GetMinValue(), this.value[i].GetMaxValue());
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Status effect functions
		============================================================================
		*/
		public void CheckEffectsTime(float t)
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				this.effect[i].TimeCheck(t);
			}
		}
		
		public void CheckEffectsTurn()
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				this.effect[i].TurnCheck();
			}
		}
		
		public List<StatusEffect> Effects
		{
			get{ return this.effect;}
		}
		
		public List<StatusEffect> GetHUDEffects()
		{
			List<StatusEffect> list = new List<StatusEffect>();
			for(int i=0; i<this.effect.Count; i++)
			{
				if(!this.effect[i].Setting.hidden)
				{
					list.Add(this.effect[i]);
				}
			}
			return list;
		}
		
		public void SetStartEffects()
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				this.effect[i].Setting.autoEffects.ChangeEffects(this.owner, this.owner);
			}
		}
		
		public bool CanApplyEffect(int effectID)
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				if(!this.effect[i].Setting.autoEffects.CanApplyEffect(effectID))
				{
					return false;
				}
			}
			return true;
		}
		
		public bool CanRemoveEffect(int effectID)
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				if(!this.effect[i].Setting.autoEffects.CanRemoveEffect(effectID))
				{
					return false;
				}
			}
			return true;
		}
		
		public void AddEffect(int effectID, Combatant user, StatusEffectCast cast, bool force)
		{
			if(this.IsEffectSet(effectID) && 
				!this.IsEffectStackable(effectID, user))
			{
				for(int i=0; i<this.effect.Count; i++)
				{
					if(this.effect[i].RealID == effectID && 
						(!EffectStacking.OncePerCombatant.Equals(this.effect[i].Setting.stackable) || 
							this.effect[i].User == user))
					{
						this.effect[i].ReApply(user, cast);
						
						if(ORK.ConsoleSettings.displayStatus)
						{
							if(this.effect[i].Setting.ownConsoleReapply)
							{
								this.effect[i].Setting.consoleReapply.Print(this.owner, this.effect[i]);
							}
							else
							{
								ORK.ConsoleSettings.statusReapplyEffect.Print(this.owner, this.effect[i]);
							}
						}
						
						break;
					}
				}
			}
			else
			{
				StatusEffect se = ORK.StatusEffects.Create(effectID);
				if(se.ApplyEffect(user, this.owner, cast, force))
				{
					this.effect.Add(se);
					this.effect.Sort(new StatusEffectSorter());
					se.Setting.ShowAddText(this.owner);
					se.AddPrefabs(this.owner);
					
					this.ChangeEffectCounters(se.Setting, 1);
					
					this.owner.MarkResetStatus();
					
					if(ORK.ConsoleSettings.displayStatus)
					{
						if(se.Setting.ownConsoleApply)
						{
							se.Setting.consoleApply.Print(this.owner, se);
						}
						else
						{
							ORK.ConsoleSettings.statusApplyEffect.Print(this.owner, se);
						}
					}
					
					// notify
					if(this.StatusEffectChanged != null)
					{
						this.StatusEffectChanged(this.owner, effectID);
					}
					this.owner.FireChanged();
				}
			}
		}
		
		public void RemoveEffect(int effectID, bool force)
		{
			List<StatusEffect> removeList = new List<StatusEffect>();
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.effect[i].RealID == effectID)
				{
					removeList.Add(this.effect[i]);
					if(EffectStacking.None.Equals(this.effect[i].Setting.stackable))
					{
						break;
					}
				}
			}
			
			for(int i=0; i<removeList.Count; i++)
			{
				removeList[i].RemoveEffect(this.owner, force);
			}
		}
		
		public void RemoveEffect(StatusEffect se)
		{
			this.effect.Remove(se);
			this.effect.Sort(new StatusEffectSorter());
			se.Setting.ShowRemoveText(this.owner);
			se.DestroyPrefabs();
			
			this.ChangeEffectCounters(se.Setting, -1);
			
			this.owner.MarkResetStatus();
			
			if(ORK.ConsoleSettings.displayStatus)
			{
				if(se.Setting.ownConsoleRemove)
				{
					se.Setting.consoleRemove.Print(this.owner, se);
				}
				else
				{
					ORK.ConsoleSettings.statusRemoveEffect.Print(this.owner, se);
				}
			}
			
			// notify
			if(this.StatusEffectChanged != null)
			{
				this.StatusEffectChanged(this.owner, se.RealID);
			}
			this.owner.FireChanged();
		}
		
		public bool IsEffectSet(int effectID)
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.effect[i].RealID == effectID)
				{
					return true;
				}
			}
			return false;
		}
		
		public bool IsEffectStackable(int effectID, Combatant user)
		{
			StatusEffectSetting se = ORK.StatusEffects.Get(effectID);
			if(EffectStacking.Enabled.Equals(se.stackable))
			{
				return true;
			}
			else if(EffectStacking.OncePerCombatant.Equals(se.stackable))
			{
				int stackCount = 0;
				for(int i=0; i<this.effect.Count; i++)
				{
					if(this.effect[i].RealID == effectID && 
						this.effect[i].User == user)
					{
						stackCount++;
					}
				}
				return stackCount == 0;
			}
			return false;
		}
		
		public int GetStackedEffectCount(int effectID)
		{
			int count = 0;
			
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.effect[i].RealID == effectID)
				{
					count++;
				}
			}
			
			return count;
		}
		
		private void ChangeEffectCounters(StatusEffectSetting setting, int change)
		{
			if(setting.stopMove)
			{
				this.stopMove += change;
			}
			if(setting.stopMovement)
			{
				this.stopMovement += change;
			}
			if(setting.autoAttack)
			{
				this.autoAttack += change;
			}
			if(setting.attackAllies)
			{
				this.attackAllies += change;
			}
			if(setting.blockAttack)
			{
				this.blockAttack += change;
			}
			if(setting.blockAbilities)
			{
				this.blockAbilities += change;
			}
			if(setting.blockItems)
			{
				this.blockItems += change;
			}
			if(setting.blockDefend)
			{
				this.blockDefend += change;
			}
			if(setting.blockEscape)
			{
				this.blockEscape += change;
			}
			if(setting.blockEquipmentChange)
			{
				this.blockEquipmentChange += change;
			}
			if(setting.blockCommand)
			{
				this.blockCommand += change;
			}
			if(setting.reflectAbilities)
			{
				this.reflectAbilities += change;
			}
			if(setting.noTurnOrderChange)
			{
				this.noTurnOrderChange += change;
			}
			if(setting.noTurnRemove)
			{
				this.noTurnRemove += change;
			}
		}
		
		
		/*
		============================================================================
		Effect end functions
		============================================================================
		*/
		public void CheckEffectEndAttack()
		{
			List<int> list = new List<int>();
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.effect[i].Setting.endOnAttack)
				{
					list.Add(this.effect[i].RealID);
				}
			}
			for(int i=0; i<list.Count; i++)
			{
				this.RemoveEffect(list[i], false);
			}
		}
		
		public void CheckEffectEndAbility(int abilityID, int typeID)
		{
			List<int> list = new List<int>();
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.effect[i].Setting.EndOnAbility(abilityID, typeID))
				{
					list.Add(this.effect[i].RealID);
				}
			}
			for(int i=0; i<list.Count; i++)
			{
				this.RemoveEffect(list[i], false);
			}
		}
		
		public void CheckEffectEndItem(int itemID, int typeID)
		{
			List<int> list = new List<int>();
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.effect[i].Setting.EndOnItem(itemID, typeID))
				{
					list.Add(this.effect[i].RealID);
				}
			}
			for(int i=0; i<list.Count; i++)
			{
				this.RemoveEffect(list[i], false);
			}
		}
		
		public void CheckEffectEndDeath()
		{
			List<int> list = new List<int>();
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.effect[i].Setting.endOnDeath)
				{
					list.Add(this.effect[i].RealID);
				}
			}
			for(int i=0; i<list.Count; i++)
			{
				this.RemoveEffect(list[i], true);
			}
		}
		
		
		/*
		============================================================================
		Effect check functions
		============================================================================
		*/
		public bool Reflect
		{
			get{ return this.reflectAbilities > 0;}
		}
		
		public bool NoTurnOrderChange
		{
			get{ return this.noTurnOrderChange > 0;}
		}
		
		public bool NoTurnRemove
		{
			get{ return this.noTurnRemove > 0;}
		}
		
		public bool StopMove
		{
			get{ return this.stopMove > 0;}
		}
		
		public bool StopMovement
		{
			get{ return this.stopMovement > 0;}
		}
		
		public void ChangeStopMovement(int add)
		{
			this.stopMovement += add;
			if(this.stopMovement < 0)
			{
				this.stopMovement = 0;
			}
		}
		
		public bool AutoAttack
		{
			get{ return this.autoAttack > 0;}
		}
		
		public bool AttackAllies
		{
			get{ return this.attackAllies > 0;}
		}
		
		public bool BlockAttack
		{
			get{ return this.stopMove > 0 || this.blockAttack > 0;}
		}
		
		public bool BlockAbilities
		{
			get{ return this.stopMove > 0 || this.blockAbilities > 0;}
		}
		
		public bool BlockItems
		{
			get{ return this.stopMove > 0 || this.blockItems > 0;}
		}
		
		public bool BlockDefend
		{
			get{ return this.owner.DelayTime > 0 || 
				this.stopMove > 0 || this.blockDefend > 0;}
		}
		
		public bool BlockEscape
		{
			get{ return this.owner.DelayTime > 0 || 
				this.stopMove > 0 || this.blockEscape > 0;}
		}
		
		public bool BlockEquipmentChange
		{
			get{ return this.stopMove > 0 || this.blockEquipmentChange > 0;}
		}
		
		public bool BlockCommand
		{
			get{ return this.stopMove > 0 || this.blockCommand > 0;}
		}
		
		public bool CanChangeStatusValue(int index, int change)
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				if(!this.effect[i].CanChangeStatusValue(index, change))
				{
					return false;
				}
			}
			return true;
		}
		
		public float GetEffectAbsorb(int index, int change)
		{
			float absorb = 0;
			for(int i=0; i<this.effect.Count; i++)
			{
				absorb = this.effect[i].GetEffectAbsorb(index, change);
				if(absorb != 0)
				{
					break;
				}
			}
			return absorb;
		}
		
		public bool IsAbilityTypeBlocked(int typeID)
		{
			if(this.BlockAbilities)
			{
				return true;
			}
			else
			{
				for(int i=0; i<this.effect.Count; i++)
				{
					if(this.effect[i].Setting.IsAbilityTypeBlocked(typeID))
					{
						return true;
					}
				}
			}
			return false;
		}
		
		public bool IsAbilityUseBlocked(int abilityID, int typeID)
		{
			if(this.BlockAbilities)
			{
				return true;
			}
			else
			{
				for(int i=0; i<this.effect.Count; i++)
				{
					if(this.effect[i].Setting.IsAbilityUseBlocked(abilityID, typeID))
					{
						return true;
					}
				}
			}
			return false;
		}
		
		public bool IsItemTypeBlocked(int typeID)
		{
			if(this.BlockItems)
			{
				return true;
			}
			else
			{
				for(int i=0; i<this.effect.Count; i++)
				{
					if(this.effect[i].Setting.IsItemTypeBlocked(typeID))
					{
						return true;
					}
				}
			}
			return false;
		}
		
		public bool IsItemUseBlocked(int itemID, int typeID)
		{
			if(this.BlockItems)
			{
				return true;
			}
			else
			{
				for(int i=0; i<this.effect.Count; i++)
				{
					if(this.effect[i].Setting.IsItemUseBlocked(itemID, typeID))
					{
						return true;
					}
				}
			}
			return false;
		}
		
		public bool IsAttackChangesBlocked()
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.effect[i].Setting.blockChangesAttacks)
				{
					return true;
				}
			}
			return false;
		}
		
		public bool IsAbilityChangesBlocked(int abilityID, int typeID)
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.effect[i].Setting.IsAbilityChangesBlocked(abilityID, typeID))
				{
					return true;
				}
			}
			return false;
		}
		
		public bool IsItemChangesBlocked(int itemID, int typeID)
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.effect[i].Setting.IsItemChangesBlocked(itemID, typeID))
				{
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public void GetAnimationSettings(ref List<AnimationSetting> list)
		{
			for(int i=0; i<this.effect.Count; i++)
			{
				if(this.owner.InBattle && this.effect[i].Setting.ownAnimsBattle)
				{
					list.Add(ORK.Animations.Get(this.effect[i].Setting.animationBattleID));
				}
				if(this.effect[i].Setting.ownAnims)
				{
					list.Add(ORK.Animations.Get(this.effect[i].Setting.animationID));
				}
			}
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			// value values
			DataObject[] tmp = new DataObject[ORK.StatusValues.Count];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.value[i].SaveGame();
			}
			data.Set("value", tmp);
			
			// attributes
			tmp = new DataObject[this.attackAttribute.Length];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.attackAttribute[i].SaveGame();
			}
			data.Set("attackAttribute", tmp);
			
			tmp = new DataObject[this.defenceAttribute.Length];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.defenceAttribute[i].SaveGame();
			}
			data.Set("defenceAttribute", tmp);
			
			tmp = new DataObject[this.defAttrID.Length];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.defAttrID[i].SaveGame();
			}
			data.Set("defAttrID", tmp);
			
			// status effects
			tmp = new DataObject[this.effect.Count];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.effect[i].SaveGame();
			}
			data.Set("effect", tmp);
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				// value values
				DataObject[] tmp = data.GetFileArray("value");
				if(tmp != null)
				{
					for(int i=0; i<ORK.StatusValues.Count; i++)
					{
						if(i < tmp.Length)
						{
							this.value[i].LoadGame(tmp[i]);
						}
					}
				}
				
				// attributes
				tmp = data.GetFileArray("attackAttribute");
				if(tmp != null)
				{
					for(int i=0; i<this.attackAttribute.Length; i++)
					{
						if(i < tmp.Length)
						{
							this.attackAttribute[i].LoadGame(tmp[i]);
						}
					}
				}
				
				tmp = data.GetFileArray("defenceAttribute");
				if(tmp != null)
				{
					for(int i=0; i<this.defenceAttribute.Length; i++)
					{
						if(i < tmp.Length)
						{
							this.defenceAttribute[i].LoadGame(tmp[i]);
						}
					}
				}
				
				tmp = data.GetFileArray("defAttrID");
				if(tmp != null)
				{
					for(int i=0; i<this.defAttrID.Length; i++)
					{
						if(i < tmp.Length)
						{
							this.defAttrID[i].LoadGame(tmp[i]);
						}
					}
				}
				
				// status effects
				tmp = data.GetFileArray("effect");
				if(tmp != null)
				{
					for(int i=0; i<tmp.Length; i++)
					{
						StatusEffect se = new StatusEffect(tmp[i], this.owner);
						this.effect.Add(se);
						this.ChangeEffectCounters(se.Setting, 1);
					}
				}
			}
		}
	}
}
