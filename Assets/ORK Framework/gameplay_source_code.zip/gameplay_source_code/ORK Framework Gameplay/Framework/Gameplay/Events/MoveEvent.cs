
using ORKFramework;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class MoveEvent : BaseEvent
	{
		// prefabs
		[ORKEditorHelp("Destroy Prefabs", "All spawned prefabs will be destroyed at the end of the event.", "")]
		[ORKEditorInfo("Prefabs", "Events can spawn prefabs in the scene.", "")]
		public bool destroyPrefabs = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Prefab", "Adds a prefab to this event.", "", 
			"Remove", "Removes this prefab from the event.", "", isCopy=true, 
			foldout=true, foldoutText=new string[] {"Prefab", "Prefabs can be spawned in the scene by the event.", ""})]
		public EventPrefab[] prefab = new EventPrefab[0];
		
		
		// audio
		[ORKEditorInfo("Audio Clips", "Events can play audio clips in the scene.", "", 
			endFoldout=true)]
		[ORKEditorArray(false, "Add Audio Clip", "Adds an audio clip to this event.", "", 
			"Remove", "Removes this audio clip from the event.", "", isCopy=true, 
			foldout=true, foldoutText=new string[] {"Audio Clip", "Audio clips can be played by the event.", ""})]
		public EventAudio[] audioClip = new EventAudio[0];
		
		
		// ingame
		protected List<GameObject> movingObject;
		
		public MoveEvent()
		{
			
		}
		
		public MoveEvent(List<GameObject> movingObject)
		{
			this.movingObject = movingObject;
		}
		
		
		/*
		============================================================================
		Start/End functions
		============================================================================
		*/
		public override void StartEvent(IEventStarter s, GameObject startingObject)
		{
			if(this.step.Length > 0 && !this.executing)
			{
				this.starter = s;
				
				for(int i=0; i<this.prefab.Length; i++)
				{
					this.prefab[i].Clear();
				}
				
				this.StartEvent();
			}
			else if(ComponentHelper.IsAlive(s))
			{
				s.EventEnded();
			}
		}
		
		protected override void EndEvent()
		{
			if(this.continueSteps.Count == 0)
			{
				this.executing = false;
				this.timeRunning = false;
				
				if(this.destroyPrefabs)
				{
					for(int i=0; i<this.prefab.Length; i++)
					{
						this.prefab[i].DestroyPrefab(-1, -1);
					}
				}
				
				// notify interaction
				if(ComponentHelper.IsAlive(this.starter))
				{
					this.starter.EventEnded();
				}
				this.starter = null;
			}
			else
			{
				this.endAfterContinue = true;
			}
		}
		
		
		/*
		============================================================================
		Step functions
		============================================================================
		*/
		public override void ExecuteNextStep()
		{
			if(this.executing)
			{
				this.stepFinished = false;
				if(this.currentStep >= 0 && this.currentStep < this.step.Length)
				{
					if(this.step[this.currentStep].active && 
						(!this.stopFlag || this.step[this.currentStep].ExecuteOnStop))
					{
						this.step[this.currentStep].Execute(this);
					}
					else
					{
						this.StepFinished(this.step[this.currentStep].GetNext(0));
					}
				}
				else
				{
					this.EndEvent();
				}
			}
		}
		
		
		/*
		============================================================================
		Actor functions
		============================================================================
		*/
		public override string GetActorName(int index)
		{
			return "";
		}
		
		public override Portrait GetActorPortrait(int index, int typeID)
		{
			return null;
		}
		
		public override List<GameObject> GetActorObject(int index)
		{
			return this.movingObject;
		}
		
		public override List<Combatant> GetActorCombatant(int index)
		{
			return ComponentHelper.GetCombatants(this.movingObject);
		}
		
		
		/*
		============================================================================
		Waypoint functions
		============================================================================
		*/
		public override List<GameObject> GetWaypoint(int index)
		{
			return this.movingObject;
		}
		
		
		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public override GameObject SpawnPrefab(int index, Vector3 position, Vector3 rotation)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				return this.prefab[index].SpawnPrefab(position, rotation);
			}
			return null;
		}
		
		public override void DestroyPrefab(int index, int spawnID, float time)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				this.prefab[index].DestroyPrefab(spawnID, time);
			}
		}
		
		public override List<GameObject> GetSpawnedPrefab(int index, int spawnID)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				return this.prefab[index].GetSpawnedPrefab(spawnID);
			}
			return new List<GameObject>();
		}
		
		
		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public override AudioClip GetAudioClip(int index)
		{
			if(index >= 0 && index < this.audioClip.Length)
			{
				return this.audioClip[index].GetClip();
			}
			return null;
		}
		
		
		/*
		============================================================================
		Call event functions
		============================================================================
		*/
		public override void CallEvent(ORKEventAsset eventAsset, int next)
		{
			// do nothing
		}
	}
}
