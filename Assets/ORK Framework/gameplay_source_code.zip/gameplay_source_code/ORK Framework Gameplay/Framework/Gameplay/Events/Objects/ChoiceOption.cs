
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class ChoiceOption : BaseData
	{
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		
		// text/icon
		[ORKEditorInfo(labelText="Choice Text/Icon")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public ChoiceLanguageContent[] content = ArrayHelper.CreateArray<ChoiceLanguageContent>(ORK.Languages.Count);
		
		
		// variable conditions
		[ORKEditorHelp("Use Condition", "A variable condition is used to decide if this choice is available.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Conditions")]
		public bool useCondition = false;
		
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorLayout("useCondition", true)]
		public VariableOrigin origin = VariableOrigin.Global;
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to check the object variables.\n" +
			"The check will be made on every 'Object Variables' component that is found. " +
			"If no component is found, the check failed.\n" +
			"If disabled, you need to define the object ID used to check the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created - usually resulting in a failed check.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		[ORKEditorLayout(endCheckGroup=true)]
		public VariableCondition condition = new VariableCondition();
		
		
		// item
		[ORKEditorHelp("Add Item", "An item, weapon or armor is added to the inventory if this choice is selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Item Settings")]
		public bool addItem = false;
		
		[ORKEditorLayout("addItem", true, endCheckGroup=true)]
		[ORKEditorInfo(callbackAfter="info:choiceitem")]
		public ItemGain item = new ItemGain();
		
		public ChoiceOption()
		{
			
		}
		
		public bool Available(BaseEvent baseEvent)
		{
			VariableHandler handler = null;
			if(this.useCondition)
			{
				if(VariableOrigin.Local.Equals(this.origin))
				{
					handler = baseEvent.Variables;
				}
				else if(VariableOrigin.Global.Equals(this.origin))
				{
					handler = ORK.Game.Variables;
				}
				else if(VariableOrigin.Object.Equals(this.origin))
				{
					if(this.useObject)
					{
						List<GameObject> list = this.fromObject.GetObject(baseEvent);
						for(int i=0; i<list.Count; i++)
						{
							if(list[i] != null)
							{
								ObjectVariablesComponent comp = list[i].GetComponentInChildren<ObjectVariablesComponent>();
								if(comp != null)
								{
									handler = comp.GetHandler();
								}
							}
						}
					}
					else
					{
						handler = ORK.Game.Scene.GetObjectVariables(this.objectID);
					}
				}
			}
			
			return !this.useCondition || (handler != null && this.condition.CheckVariables(handler));
		}
		
		public ChoiceContent GetContent(BaseEvent baseEvent)
		{
			ChoiceContent cc = this.content[ORK.Game.Language].GetChoiceContent(baseEvent);
			if(this.addItem && cc.Content != null && 
				cc.Content.text != "")
			{
				cc.Content.text = cc.Content.text.
					Replace("%n", this.item.GetName()).
					Replace("%", this.item.quantity.ToString());
			}
			return cc;
		}
	}
}

