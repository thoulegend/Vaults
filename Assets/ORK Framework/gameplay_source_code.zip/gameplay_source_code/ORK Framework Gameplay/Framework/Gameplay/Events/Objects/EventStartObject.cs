
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class EventStartObject
	{
		public bool checkName = false; 
		
		public bool isTag = false;
		
		public string name = "";
		
		
		// components
		public string[] components = new string[0];
		
		
		public EventStartObject()
		{
			
		}
		
		public bool CheckObject(GameObject gameObject)
		{
			return this.CheckName(gameObject) && 
				this.CheckComponents(gameObject);
		}
		
		public bool CheckName(GameObject gameObject)
		{
			return !this.checkName || 
				((this.isTag && gameObject.tag == this.name) || 
				(!this.isTag && gameObject.name == this.name));
		}
		
		public bool CheckComponents(GameObject gameObject)
		{
			if(components.Length > 0)
			{
				for(int i=0; i<this.components.Length; i++)
				{
					if(ComponentHelper.Get(gameObject, this.components[i]) == null)
					{
						return false;
					}
				}
			}
			return true;
		}
	}
}
