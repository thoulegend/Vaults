
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Close All Dialogues", "Closes all dialogues opened by this event.\n" +
		"Only dialogues from 'Show Dialogue' steps are closed.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Dialogue Steps")]
	public class CloseAllDialoguesStep : BaseEventStep
	{
		public CloseAllDialoguesStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.CloseAllGUIBoxes();
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Show Dialogue", "Displays a dialogue or choice dialogue.\n" +
		"The event continues when the dialogue or choice is accepted with the accept key.\n" +
		"Choices are selected with the horizontal and vertical key or with a click/touch.\n" +
		"Choice dialogues can have as many choices as you like, every choice has it's own next step " +
		"setting which will execute the next step based on the selected choice.\n" +
		"If you select 'Choice', the 'Next' setting is only used if no choices are available.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Dialogue Steps")]
	public class ShowDialogueStep : BaseEventStep
	{
		public DialogueChoice dialogue = new DialogueChoice();
		
		public ShowDialogueStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.dialogue.Show(baseEvent, this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.dialogue.message[0];
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Next";
			}
			else if(index == 1 && this.dialogue.allowCancel)
			{
				return "Cancel";
			}
			else if(index > 0)
			{
				if(this.dialogue.allowCancel)
				{
					return "Choice " + (index - 2) + ": " + this.dialogue.choiceOption[index - 2].content[0].name;
				}
				else
				{
					return "Choice " + (index - 1) + ": " + this.dialogue.choiceOption[index - 1].content[0].name;
				}
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			if(DialogueType.Choice.Equals(this.dialogue.type) && 
				this.dialogue.choiceOption != null)
			{
				return this.dialogue.choiceOption.Length + (this.dialogue.allowCancel ? 2 : 1);
			}
			return this.dialogue.allowCancel ? 2 : 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1 && this.dialogue.allowCancel)
			{
				return this.dialogue.cancelNext;
			}
			else if(index > 0 && this.dialogue.choiceOption != null)
			{
				if(this.dialogue.allowCancel)
				{
					return this.dialogue.choiceOption[index - 2].next;
				}
				else
				{
					return this.dialogue.choiceOption[index - 1].next;
				}
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1 && this.dialogue.allowCancel)
			{
				this.dialogue.cancelNext = next;
			}
			else if(index > 0 && this.dialogue.choiceOption != null)
			{
				if(this.dialogue.allowCancel)
				{
					this.dialogue.choiceOption[index - 2].next = next;
				}
				else
				{
					this.dialogue.choiceOption[index - 1].next = next;
				}
			}
		}
	}
	
	[ORKEditorHelp("Teleport Choice", "Displays a choice dialogue listing all available teleports.\n" +
		"The player group will be transferred to the selected teleport target - the event will end after the teleport.\n" +
		"If no teleports are available (due to variable conditions), the " +
		"teleport choice dialogue wont be displayed and 'Next' will be executed.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Dialogue Steps")]
	public class TeleportChoiceStep : BaseEventStep
	{
		public TeleportChoice choice = new TeleportChoice();
		
		public TeleportChoiceStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.choice.Show(baseEvent, this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.choice.message[0];
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Next (No Teleports)";
			}
			else if(index == 1)
			{
				return "Cancel";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return (this.choice.allowCancel || this.choice.addCancel) ? 2 : 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.choice.cancelNext;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.choice.cancelNext = next;
			}
		}
	}
	
	[ORKEditorHelp("Quest Choice", "Displays a dialogue or choice dialogue with quest information of a selected quest.\n" +
		"The selected quest wont be added to the quest list when accepted - " +
		"the dialogue only displays the quest's information using the quest layout settings. " +
		"To add the quest to the quest list, use the 'Add Quest' step.\n" +
		"If you enable canceling (i.e. declining) the quest info, 'Cancel' is executed next, " +
		"else the quest is accepted and 'Accept' is executed next.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Dialogue Steps", "Quest Steps")]
	public class QuestChoiceStep : BaseEventStep
	{
		public QuestChoice dialogue = new QuestChoice();
		
		public QuestChoiceStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.dialogue.Show(baseEvent, this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Quests.GetName(this.dialogue.questID);
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Accept";
			}
			else if(index == 1 && this.dialogue.allowCancel)
			{
				return "Cancel";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.dialogue.allowCancel ? 2 : 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1 && this.dialogue.allowCancel)
			{
				return this.dialogue.cancelNext;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1 && this.dialogue.allowCancel)
			{
				this.dialogue.cancelNext = next;
			}
		}
	}
	
	[ORKEditorHelp("Value Input Dialogue", "Displays a dialogue to input " +
		"string, bool and float values and store them in game variables.\n" +
		"The event continues when the dialogue is accepted with the accept key (or canceled).", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Dialogue Steps")]
	public class ValueInputDialogueStep : BaseEventStep
	{
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		
		// value input
		[ORKEditorInfo(separator=true, labelText="Dialogue Settings")]
		public ValueInputChoice dialogue = new ValueInputChoice();
		
		public ValueInputDialogueStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			VariableHandler variableHandler = null;
			if(VariableOrigin.Local.Equals(this.origin))
			{
				variableHandler = baseEvent.Variables;
			}
			else if(VariableOrigin.Global.Equals(this.origin))
			{
				variableHandler = ORK.Game.Variables;
			}
			else if(VariableOrigin.Object.Equals(this.origin))
			{
				if(this.useObject)
				{
					List<GameObject> list = this.fromObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							ObjectVariablesComponent comp = list[i].GetComponentInChildren<ObjectVariablesComponent>();
							if(comp != null)
							{
								variableHandler = comp.GetHandler();
								break;
							}
						}
					}
				}
				else
				{
					variableHandler = ORK.Game.Scene.GetObjectVariables(this.objectID);
				}
			}
			
			this.dialogue.Show(baseEvent, variableHandler, this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString();
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Next";
			}
			else if(index == 1 && this.dialogue.allowCancel)
			{
				return "Cancel";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.dialogue.allowCancel ? 2 : 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1 && this.dialogue.allowCancel)
			{
				return this.dialogue.cancelNext;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1 && this.dialogue.allowCancel)
			{
				this.dialogue.cancelNext = next;
			}
		}
	}
	
	[ORKEditorHelp("Show Notification", "Displays a notification (like damage/refresh texts) at the position of an object.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Dialogue Steps")]
	public class ShowNotificationStep : BaseEventStep
	{
		// object
		[ORKEditorInfo(labelText="Object")]
		public EventObjectSetting usedObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between showing the notification on two objects.\n" +
			"Only used if greater than 0 and more than one object will be scaled.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to display the notification before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// show a number
		[ORKEditorHelp("Show Number", "Show a number in the notification.\n" +
			"Use % to display the number in the notification text. The 'Count To Value' option can be used if displaying a number.", "")]
		[ORKEditorInfo(separator=true)]
		public bool showNumber = false;
		
		[ORKEditorHelp("All Same Number", "All objects display the same number.\n" +
			"If disabled, the number will be calculated (e.g. when using a formula) for each object.", "")]
		[ORKEditorLayout("showNumber", true)]
		public bool allSame = true;
		
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public EventInteger value;
		
		
		// notification
		[ORKEditorInfo(separator=true)]
		public DisplayTextSettings textSettings = new DisplayTextSettings("");
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		private int tmpValue = 0;
		
		public ShowNotificationStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.usedObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				if(this.showNumber && this.allSame)
				{
					this.tmpValue = this.value.GetValue(baseEvent);
				}
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.showNumber)
			{
				this.textSettings.ShowNumber(this.allSame ? this.tmpValue : this.value.GetValue(baseEvent), this.list[this.index]);
			}
			else
			{
				this.textSettings.ShowText("", this.list[this.index]);
			}
			this.index++;
			
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.textSettings.text[0];
		}
	}
	
	[ORKEditorHelp("Add Console Line", "Adds a text to the console.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Dialogue Steps")]
	public class AddConsoleLineStep : BaseEventStep
	{
		[ORKEditorHelp("Console Type", "Select the console type this text will be displayed in.", "")]
		[ORKEditorInfo(ORKDataType.ConsoleType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Text", "The text that will be added to the console.", "")]
		[ORKEditorInfo(isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		public AddConsoleLineStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Game.Console.AddLine(this.text[ORK.Game.Language], this.typeID);
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.ConsoleTypes.GetName(this.typeID) + ": " + this.text[0];
		}
	}
	
	[ORKEditorHelp("Clear Console", "Removes text from the console.\n" +
		"Either all text of a selected console type, or all text.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Dialogue Steps")]
	public class ClearConsoleStep : BaseEventStep
	{
		[ORKEditorHelp("All Types", "All console types will be cleared.\n" +
			"If disabled, only a selected console type will be cleared.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Console Type", "Select the console type this text will be displayed in.", "")]
		[ORKEditorInfo(ORKDataType.ConsoleType)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int typeID = 0;
		
		public ClearConsoleStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				ORK.Game.Console.Clear();
			}
			else
			{
				ORK.Game.Console.Clear(this.typeID);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "All Types" : ORK.ConsoleTypes.GetName(this.typeID);
		}
	}
	
	[ORKEditorHelp("Block HUD", "Blocks or unblocks a HUD.\n" +
		"A blocked HUD wont be displayed.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps", "Dialogue Steps")]
	public class BlockHUDStep : BaseEventStep
	{
		[ORKEditorHelp("Block/Unblock", "If enabled, the HUD will be blocked.\n" +
			"If disabled, the HUD will be unblocked.", "")]
		public bool block = false;
		
		[ORKEditorHelp("All HUDs", "Block or unblock all HUDs.\n" +
			"If disabled, only a selected HUD will be blocked or unblocked.", "")]
		public bool all = false;
		
		[ORKEditorHelp("HUD", "Select the HUD that will be blocked or unblocked.", "")]
		[ORKEditorInfo(ORKDataType.HUD)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id = 0;
		
		public BlockHUDStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				for(int i=0; i<ORK.HUDs.Count; i++)
				{
					ORK.HUDs.Get(i).Blocked = this.block;
				}
			}
			else
			{
				ORK.HUDs.Get(this.id).Blocked = this.block;
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		public override bool ExecuteOnStop
		{
			get{ return true;}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.block ? "Block " : "Unblock ") + 
				(this.all ? "All HUDs" : ORK.HUDs.GetName(this.id));
		}
	}
}
