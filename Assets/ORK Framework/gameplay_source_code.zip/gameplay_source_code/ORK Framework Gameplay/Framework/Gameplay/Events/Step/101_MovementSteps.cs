
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Change Position", "Sets or moves a game object to a new position.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Movement Steps")]
	public class ChangePositionStep : BaseEventStep
	{
		// moving object
		[ORKEditorInfo(labelText="Moving Object")]
		public EventObjectSetting moveObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between moving two objects.\n" +
			"Only used if greater than 0 and more than one object will be moved.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start moving before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// target
		[ORKEditorHelp("To Object", "Use another object's position to change the position.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Position")]
		public bool toObject = false;
		
		[ORKEditorLayout("toObject", true, autoInit=true)]
		public EventObjectSetting targetObject;
		
		[ORKEditorHelp("Use Center", "The center of all target objects will be used.\n" +
			"If disabled, the target object with the same index as the " +
			"moving object is used (or the first existing target object).", "")]
		public bool useCenter = false;
		
		[ORKEditorHelp("Local Space", "The offset is added in local space of the target.", "")]
		public bool localSpace = false;
		
		[ORKEditorHelp("Offset", "The offset added to the target's position.", "")]
		public Vector3 offset = Vector3.zero;
		
		[ORKEditorInfo(separator=true, labelText="Position")]
		[ORKEditorLayout(elseCheckGroup=true, autoInit=true)]
		public EventVector3 position;
		
		[ORKEditorHelp("Local Position", "The position is in local space of the object.\n" +
			"If disabled, the position is in world space.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool localPosition = false;
		
		
		// move settings
		[ORKEditorHelp("Move", "The object is moved over time to the new position.\n" +
			"If disabled, the object is set to the new position immediately.", "")]
		[ORKEditorInfo(separator=true, labelText="Movement Settings")]
		public bool move = false;
		
		[ORKEditorHelp("Wait", "Wait until the movement has finished before the next step is executed.", "")]
		[ORKEditorLayout(new string[] {"move", "waitBetween"}, 
			new System.Object[] {true, true}, endCheckGroup=true)]
		public bool wait = false;
		
		[ORKEditorHelp("Controller Move", "The object's CharacterController component is used to perform the move.\n" +
			"If disabled or not found, the Transform component is used instead.", "")]
		[ORKEditorLayout("move", true)]
		public bool useController = true;
		
		[ORKEditorHelp("Apply Gravity", "Automatically applies the gravity (Physics.gravity.y) to the moving object.", "")]
		[ORKEditorLayout("useController", true, endCheckGroup=true)]
		public bool applyGravity = true;
		
		[ORKEditorHelp("Face Direction", "The object will look into the direction of " +
			"the target position before moving.", "")]
		public bool face = true;
		
		[ORKEditorHelp("Stop Distance", "The distance in world units the object will stop before the target.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float distance = 0;
		
		[ORKEditorHelp("No Combatant Radius", "The combatant radius setting of the combatants will be ignored.\n" +
			"If disabled, the combatant radius of the user and target object (if combatants) will be added to the stop distance.", "")]
		public bool ignoreRadius = false;
		
		
		// speed movement
		[ORKEditorHelp("Move By Speed", "The object will move by speed and not by time.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useSpeed = false;
		
		
		// secure movement
		[ORKEditorHelp("Secure Move", "The movement will end if the game object couldn't move for a defined amount of time.\n" +
			"If disabled, the game object will move until it reached it's target.", "")]
		[ORKEditorLayout("useSpeed", true)]
		public bool secureMove = false;
		
		[ORKEditorHelp("Secure Time (s)", "The time in seconds the game object mustn't move to stop the movement.", "")]
		[ORKEditorLayout("secureMove", true, endCheckGroup=true)]
		[ORKEditorLimit(0.1f, false)]
		public float secureTime = 0.5f;
		
		[ORKEditorHelp("Speed Type", "Select the speed used to move the object:\n" +
			"- Walk: The combatant's walk speed.\n" +
			"- Run: The combatant's run speed.\n" +
			"- Sprint: The combatant's sprint speed.\n" +
			"- Value: A defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public MoveSpeedType speedType = MoveSpeedType.Run;
		
		[ORKEditorHelp("Speed", "The speed in world units per second used to move the object.\n" +
			"This setting is only used, if speed type 'Value' is selected, or if the moving object doesn't have a combatant.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float speed = 5;
		
		[ORKEditorHelp("Follow Position", "Changes to the target position are recognized while moving.\n" +
			"If disabled, the object will move to the position the target had at the start of " +
			"the move and ignore changes to the target's position.", "")]
		[ORKEditorLayout("toObject", true, endCheckGroup=true)]
		public bool followPosition = true;
		
		
		// time movement
		[ORKEditorHelp("Time (s)", "The time in seconds used to move the object.", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Interpolation", "The interpolation used for moving the object.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public EaseType interpolation = EaseType.Linear;
		
		
		// ingame
		private bool finished = false;
		
		private List<GameObject> list;
		
		private List<GameObject> target;
		
		private GameObject centerObj;
		
		private int index = 0;
		
		public ChangePositionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.centerObj = null;
			this.finished = false;
			this.list = this.moveObject.GetObject(baseEvent);
			if(this.toObject)
			{
				this.target = this.targetObject.GetObject(baseEvent);
			}
			else
			{
				this.target = null;
			}
			this.index = 0;
			
			if(this.list.Count > 0 && (!this.toObject || this.target.Count > 0))
			{
				if(this.target != null && this.useCenter && this.target.Count > 0)
				{
					if(this.target.Count == 1)
					{
						this.centerObj = this.target[0];
					}
					else
					{
						this.centerObj = new GameObject("_CenterObj");
						CenterEventMover mover = this.centerObj.AddComponent<CenterEventMover>();
						mover.SetCenter(this.target, this.localSpace, this.offset, 
							(this.move ? this.time : 0) + this.timeBetween * (this.list.Count - 1));
					}
				}
				
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				// move to position
				if(this.move)
				{
					float stopAdd = 0;
					if(!this.ignoreRadius)
					{
						Combatant comUser = ComponentHelper.GetCombatant(this.list[this.index]);
						if(comUser != null)
						{
							stopAdd += comUser.BoxRadius;
						}
					}
					
					ActorEventMover mover = ComponentHelper.Get<ActorEventMover>(this.list[this.index]);
					// move by speed
					if(this.useSpeed)
					{
						float sp = this.speed;
						if(!MoveSpeedType.Value.Equals(this.speedType))
						{
							Combatant c = ComponentHelper.GetCombatant(this.list[this.index]);
							if(c != null)
							{
								sp = c.GetMoveSpeed(this.speedType);
							}
						}
						// speed to object
						if(this.toObject)
						{
							GameObject tObj = this.GetTarget();
							if(tObj != null)
							{
								if(!this.ignoreRadius)
								{
									Combatant comTarget = ComponentHelper.GetCombatant(this.list[this.index]);
									if(comTarget != null)
									{
										stopAdd += comTarget.BoxRadius;
									}
								}
								
								if(this.followPosition)
								{
									mover.SpeedToObject(this.list[this.index].transform, 
										this.useController, this.applyGravity, this.face, 
										sp, this.distance + stopAdd, tObj.transform, 
										this.DoWait() ? baseEvent : null, 
										this.next, this.secureMove ? this.secureTime : -1);
								}
								else
								{
									Vector3 pos = Vector3.zero;
									if(this.localSpace)
									{
										pos = tObj.transform.TransformPoint(this.offset);
									}
									else
									{
										pos = tObj.transform.position + this.offset;
									}
									mover.SpeedToPosition(this.list[this.index].transform, 
										this.useController, this.applyGravity, this.face, 
										sp, this.distance + stopAdd, pos, this.DoWait() ? baseEvent : null, this.next, this.secureMove ? this.secureTime : -1);
								}
								if(this.DoWait())
								{
									this.finished = true;
								}
							}
						}
						// speed to position
						else
						{
							mover.SpeedToPosition(this.list[this.index].transform, 
								this.useController, this.applyGravity, this.face, 
								sp, this.distance + stopAdd, this.localPosition ? 
									this.list[this.index].transform.TransformPoint(this.position.GetValue(baseEvent)) : 
									this.position.GetValue(baseEvent), 
								this.DoWait() ? baseEvent : null, this.next, this.secureMove ? this.secureTime : -1);
							if(this.DoWait())
							{
								this.finished = true;
							}
						}
					}
					// move by interpolation
					else
					{
						// move to object
						if(this.toObject)
						{
							GameObject tObj = this.GetTarget();
							if(tObj != null)
							{
								Vector3 pos = this.localSpace ? 
									tObj.transform.TransformPoint(this.offset) : 
									tObj.transform.position + this.offset;
								if(this.distance + stopAdd > 0)
								{
									pos = Vector3.Lerp(pos, this.list[this.index].transform.position, 
										(this.distance + stopAdd) / Vector3.Distance(this.list[this.index].transform.position, pos));
								}
								mover.MoveToPosition(this.list[this.index].transform, this.useController, 
									this.applyGravity, this.face, pos, this.interpolation, this.time);
								if(this.DoWait())
								{
									this.finished = true;
									baseEvent.StartTime(this.time, this.next);
								}
							}
						}
						// move to position
						else
						{
							Vector3 pos = this.localPosition ? 
								this.list[this.index].transform.TransformPoint(this.position.GetValue(baseEvent)) : 
								this.position.GetValue(baseEvent);
							if(this.distance + stopAdd > 0)
							{
								pos = Vector3.Lerp(pos, this.list[this.index].transform.position, 
									(this.distance + stopAdd) / Vector3.Distance(this.list[this.index].transform.position, pos));
							}
							mover.MoveToPosition(this.list[this.index].transform, this.useController, 
								this.applyGravity, this.face, pos, this.interpolation, this.time);
							if(this.DoWait())
							{
								this.finished = true;
								baseEvent.StartTime(this.time, this.next);
							}
						}
					}
				}
				// set to position
				else
				{
					// set to object
					if(this.toObject)
					{
						GameObject tObj = this.GetTarget();
						if(tObj != null)
						{
							if(this.localSpace)
							{
								this.list[this.index].transform.position = tObj.transform.TransformPoint(this.offset);
							}
							else
							{
								this.list[this.index].transform.position = tObj.transform.position + this.offset;
							}
						}
					}
					// set to position
					else
					{
						this.list[this.index].transform.position = this.localPosition ? 
							this.list[this.index].transform.TransformPoint(this.position.GetValue(baseEvent)) : 
							this.position.GetValue(baseEvent);
					}
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(!this.finished && this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				if(this.centerObj != null && 
					this.centerObj != this.target[0])
				{
					if(this.wait)
					{
						GameObject.Destroy(this.centerObj, this.time);
					}
					else
					{
						GameObject.Destroy(this.centerObj);
					}
				}
				this.centerObj = null;
				this.finished = false;
				this.list = null;
				this.target = null;
				this.index = 0;
			}
		}
		
		private GameObject GetTarget()
		{
			if(this.target != null && this.target.Count > 0)
			{
				if(this.useCenter)
				{
					return centerObj;
				}
				else
				{
					if(this.index < this.target.Count)
					{
						return this.target[this.index];
					}
					else
					{
						return this.target[0];
					}
				}
			}
			return null;
		}
		
		private bool DoWait()
		{
			return this.wait && !this.finished && this.waitBetween && 
				this.index == this.list.Count - 1;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.move ? 
				"Move to position" + (this.useSpeed ? "" : (", " + this.time + "s")) + (this.wait ? " (wait)" : "") : 
				"Set to position";
		}
	}
	
	[ORKEditorHelp("Move Into Direction", "Moves a game object into a defined direction.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Movement Steps")]
	public class MoveDirectionStep : BaseEventStep
	{
		// moving object
		[ORKEditorInfo(labelText="Moving Object")]
		public EventObjectSetting moveObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between moving two objects.\n" +
			"Only used if greater than 0 and more than one object will be moved.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start moving before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		[ORKEditorHelp("Time (s)", "The time in seconds used to move.", "")]
		[ORKEditorInfo(separator=true, labelText="Movement Settings")]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Wait", "Wait until the movement has finished before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true)]
		public bool wait = false;
		
		[ORKEditorHelp("Speed Type", "Select the speed used to move the object:\n" +
			"- Walk: The combatant's walk speed.\n" +
			"- Run: The combatant's run speed.\n" +
			"- Sprint: The combatant's sprint speed.\n" +
			"- Value: A defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public MoveSpeedType speedType = MoveSpeedType.Run;
		
		[ORKEditorHelp("Speed", "The speed in world units per second used to move the object.\n" +
			"This setting is only used, if speed type 'Value' is selected, or if the moving object doesn't have a combatant.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float speed = 5;
		
		[ORKEditorInfo(separator=true, labelText="Direction", label=new string[] {"Use negative Y-axis values for gravity (Y=-9.81)."})]
		public EventVector3 direction = new EventVector3(new Vector3(1, Physics.gravity.y, 0));
		
		[ORKEditorHelp("Local Space", "The direction is defined in local space of the game object.\n" +
			"Use this setting e.g. to always move the game object forward, regardless its actual position in world space.", "")]
		[ORKEditorInfo(separator=true)]
		public bool localSpace = true;
		
		[ORKEditorHelp("Controller Move", "The object's CharacterController component is used to perform the move.\n" +
			"If disabled or not found, the Transform component is used instead.", "")]
		public bool useController = true;
		
		[ORKEditorHelp("Face Direction", "The object will look into the direction it moves before moving.", "")]
		public bool face = true;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public MoveDirectionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.moveObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				ActorEventMover mover = ComponentHelper.Get<ActorEventMover>(this.list[this.index]);
				Vector3 target = this.direction.GetValue(baseEvent);
				if(this.localSpace)
				{
					target = this.list[this.index].transform.TransformDirection(target);
				}
				
				// speed
				float sp = this.speed;
				if(!MoveSpeedType.Value.Equals(this.speedType))
				{
					Combatant c = ComponentHelper.GetCombatant(this.list[this.index]);
					if(c != null)
					{
						sp = c.GetMoveSpeed(this.speedType);
					}
				}
				
				mover.MoveToDirection(this.list[this.index].transform, 
					this.useController, target, this.face, sp, this.time);
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.wait)
					{
						baseEvent.StartTime(this.time, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.time + "s" + (this.wait ? " (wait)" : "");
		}
	}
	
	[ORKEditorHelp("Curve Move", "Moves a game object using curves.\n" +
		"The curve values are added to the game object's original position at the start of the step.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Movement Steps")]
	public class CurveMoveStep : BaseEventStep
	{
		// moving object
		[ORKEditorInfo(labelText="Moving Object")]
		public EventObjectSetting moveObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between moving two objects.\n" +
			"Only used if greater than 0 and more than one object will be moved.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start moving before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		[ORKEditorHelp("Wait", "Wait until the movement has finished before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true)]
		public bool wait = false;
		
		
		// settings
		[ORKEditorHelp("Local Space", "The curves are defined in local space of the game object.\n" +
			"Use this setting e.g. to always move the game object forward, regardless its actual position in world space.", "")]
		[ORKEditorInfo(separator=true)]
		public bool localSpace = true;
		
		
		// curves
		// x-axis
		[ORKEditorHelp("Move X-Axis", "Move the game object along the X-axis.", "")]
		[ORKEditorInfo(separator=true, labelText="X-Axis")]
		public bool xMove = false;
		
		[ORKEditorHelp("X-Axis Curve", "Define the curve used for the X-axis.", "")]
		[ORKEditorLayout("xMove", true, endCheckGroup=true, autoInit=true)]
		public AnimationCurve xCurve;
		
		// y-axis
		[ORKEditorHelp("Move Y-Axis", "Move the game object along the Y-axis.", "")]
		[ORKEditorInfo(separator=true, labelText="Y-Axis")]
		public bool yMove = false;
		
		[ORKEditorHelp("Y-Axis Curve", "Define the curve used for the Y-axis.", "")]
		[ORKEditorLayout("yMove", true, endCheckGroup=true, autoInit=true)]
		public AnimationCurve yCurve;
		
		// z-axis
		[ORKEditorHelp("Move Z-Axis", "Move the game object along the Z-axis.", "")]
		[ORKEditorInfo(separator=true, labelText="Z-Axis")]
		public bool zMove = false;
		
		[ORKEditorHelp("Z-Axis Curve", "Define the curve used for the Z-axis.", "")]
		[ORKEditorLayout("zMove", true, endCheckGroup=true, autoInit=true)]
		public AnimationCurve zCurve;
		
		
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		private float moveTime = 0;
		
		public CurveMoveStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.moveObject.GetObject(baseEvent);
			this.index = 0;
			
			this.moveTime = 0;
			if(this.xMove)
			{
				this.moveTime = Mathf.Max(this.moveTime, this.xCurve[this.xCurve.length - 1].time);
			}
			if(this.yMove)
			{
				this.moveTime = Mathf.Max(this.moveTime, this.yCurve[this.yCurve.length - 1].time);
			}
			if(this.zMove)
			{
				this.moveTime = Mathf.Max(this.moveTime, this.zCurve[this.zCurve.length - 1].time);
			}
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				ActorEventMover mover = ComponentHelper.Get<ActorEventMover>(this.list[this.index]);
				
				mover.MoveByCurve(this.list[this.index].transform, 
					this.xMove ? this.xCurve : null, 
					this.yMove ? this.yCurve : null, 
					this.zMove ? this.zCurve : null, 
					this.localSpace, this.moveTime);
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.wait)
					{
						baseEvent.StartTime(this.moveTime, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
	}
	
	[ORKEditorHelp("Stop Movement", "Stops movement from 'Change Position', " +
		"'Move Into Direction' and 'Curve Move' steps.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Movement Steps")]
	public class StopMovementStep : BaseEventStep
	{
		// moving object
		[ORKEditorInfo(labelText="Stopping Object")]
		public EventObjectSetting stopObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between stopping two objects.\n" +
			"Only used if greater than 0 and more than one object will be stopped.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to stop moving before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public StopMovementStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.stopObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				ComponentHelper.Get<ActorEventMover>(this.list[this.index]).StopMoving();
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
	}
	
	[ORKEditorHelp("Change Scale", "Sets or fades the scale of a game object.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Movement Steps")]
	public class ChangeScaleStep : BaseEventStep
	{
		// scaling object
		[ORKEditorInfo(labelText="Scaling Object")]
		public EventObjectSetting scaleObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between scaling two objects.\n" +
			"Only used if greater than 0 and more than one object will be scaled.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start scaling before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		[ORKEditorInfo(separator=true, labelText="Scale")]
		public EventVector3 scale = new EventVector3(Vector3.one);
		
		
		// fade
		[ORKEditorHelp("Fade Scale", "The scale is changed over time to the new scale.\n" +
			"If disabled, the object's scale is set to the new scale immediately.", "")]
		[ORKEditorInfo(separator=true, labelText="Fade Settings")]
		public bool fade = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds used to scale.", "")]
		[ORKEditorLayout("fade", true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Wait", "Wait until the scaling has finished before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true)]
		public bool wait = false;
		
		// interpolate
		[ORKEditorHelp("Interpolation", "The interpolation used for fading the scale.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public EaseType interpolation = EaseType.Linear;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public ChangeScaleStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.scaleObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				if(this.fade)
				{
					ActorEventScaler scaler = ComponentHelper.Get<ActorEventScaler>(this.list[this.index]);
					scaler.Scale(this.list[this.index].transform, this.time, this.scale.GetValue(baseEvent), this.interpolation);
				}
				else
				{
					this.list[this.index].transform.localScale = this.scale.GetValue(baseEvent);
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.fade && this.wait)
					{
						baseEvent.StartTime(this.time, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.fade ? 
				"Fade scale, " + this.time + "s " + (this.wait ? "(wait)" : "") : 
				"Set scale");
		}
	}
	
	[ORKEditorHelp("Block Player Control", "Blocks or unblocks the player control.\n" +
		"For each block, the block counter will increase by 1, for each unblock, the counter will decrease by 1.\n" +
		"As long as the counter is above 0 the camera control will remain blocked.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Movement Steps", "Base Steps")]
	public class BlockPlayerControlStep : BaseEventStep
	{
		[ORKEditorHelp("Block/Unblock", "If enabled, the player control will be blocked.\n" +
			"If disabled, the player control will be unblocked.", "")]
		public bool block = false;
		
		public BlockPlayerControlStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.DoPlayerBlock(this.block ? 1 : -1);
			baseEvent.StepFinished(this.next);
		}
		
		public override bool ExecuteOnStop
		{
			get{ return true;}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.block ? "Block" : "Unblock";
		}
	}
	
	[ORKEditorHelp("Check Distance", "The distance between two objects is checked against a value.\n" +
	 	"If the check is valid, 'Success' is executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Movement Steps", "Check Steps")]
	public class CheckDistanceStep : BaseEventCheckStep
	{
		[ORKEditorInfo(labelText="From Object")]
		public EventObjectSetting fromObject = new EventObjectSetting();
		
		[ORKEditorInfo(separator=true, labelText="To Object")]
		public EventObjectSetting toObject = new EventObjectSetting();
		
		[ORKEditorHelp("Check Type", "Checks if the distance is equal, not equal, less or greater than the defined distance.\n" +
			"Range inclusive checks if the distance is between two defind values, including the values.\n" +
			"Range exclusive checks if the distance is between two defined values, excluding the values.\n" +
			"Approximately checks if the distance is similar to the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true, labelText="Check")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorHelp("Needed", "Either all or only one of the objects must match the defined check.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;
		
		[ORKEditorHelp("Ignore Y Distance", "The distance along the Y-axis will be ignored, i.e. the height difference is ignored.", "")]
		public bool ignoreYDistance = true;
		
		[ORKEditorInfo(separator=true, labelText="Distance")]
		public EventFloat distance = new EventFloat();
		
		[ORKEditorInfo(separator=true, labelText="Distance 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat distance2;
		
		public CheckDistanceStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(this.fromObject.GetObject(baseEvent), 
				this.toObject.GetObject(baseEvent), 
				this.distance.GetValue(baseEvent), 
				this.distance2 != null ? this.distance2.GetValue(baseEvent) : 0))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool DoCheck(List<GameObject> from, List<GameObject> to, float value, float value2)
		{
			bool any = false;
			for(int i=0; i<from.Count; i++)
			{
				for(int j=0; j<to.Count; j++)
				{
					if(ValueHelper.CheckVariableValue(
						VectorHelper.Distance(from[i].transform.position, to[j].transform.position, this.ignoreYDistance), 
						value, value2, this.check))
					{
						if(Needed.One.Equals(needed))
						{
							return true;
						}
						else
						{
							any = true;
						}
					}
					else if(Needed.All.Equals(needed))
					{
						return false;
					}
				}
			}
			return any;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + " " + this.distance.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Block Move AI", "Blocks or unblocks the move AI either completely or for a selected object.\n" +
		"Combatant's can't use the move AI while it's blocked.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Movement Steps", "Base Steps")]
	public class BlockMoveAIStep : BaseEventStep
	{
		[ORKEditorHelp("Block/Unblock", "If enabled, the move AI will be blocked.\n" +
			"If disabled, the moveAI will be unblocked.", "")]
		public bool block = false;
		
		[ORKEditorHelp("Use Object", "Only block the move AI of a selected object.\n" +
			"If disabled, the move AI will be blocked completely (i.e. for all objects).", "")]
		public bool useObject = false;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, endCheckGroup=true, autoInit=true)]
		public EventObjectSetting onObject;
		
		public BlockMoveAIStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.useObject)
			{
				List<GameObject> list = this.onObject.GetObject(baseEvent);
				for(int i=0; i<list.Count; i++)
				{
					MoveAIComponent moveAI = ComponentHelper.GetInChildren<MoveAIComponent>(list[i]);
					if(moveAI != null)
					{
						moveAI.blocked = this.block;
					}
				}
			}
			else
			{
				ORK.Control.SetBlockMoveAI(this.block ? 1 : -1);
			}
			baseEvent.StepFinished(this.next);
		}
		
		public override bool ExecuteOnStop
		{
			get{ return true;}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.block ? "Block " : "Unblock ";
		}
	}
	
	[ORKEditorHelp("Check Transform", "An object's position, rotation or scale is checked against a value.\n" +
		"Each axis (X, Y, Z) can be checked individually.\n" +
	 	"If the check is valid, 'Success' is executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Movement Steps", "Check Steps")]
	public class CheckTransformStep : BaseEventCheckStep
	{
		[ORKEditorInfo(labelText="Object")]
		public EventObjectSetting fromObject = new EventObjectSetting();
		
		[ORKEditorHelp("Needed", "Either all or only one of the objects must match the defined check.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;
		
		[ORKEditorHelp("Value Origin", "Select the Vector3 value that will be checked:\n" +
			"- Position: The position of the transform.\n" +
			"- Rotation: The rotation (euler angles) of the transform.\n" +
			"- Scale: The scale (local scale) of the transform.", "")]
		[ORKEditorInfo(separator=true)]
		public TransformVectorOrigin origin = TransformVectorOrigin.Position;
		
		
		// X
		[ORKEditorHelp("Check X-Axis", "The X-axis of the vector will be checked.", "")]
		[ORKEditorInfo(separator=true, labelText="X-Axis")]
		public bool useX = false;
		
		[ORKEditorHelp("Check Type", "Checks if the X-axis value is equal, not equal, less or greater than a value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorLayout("useX", true)]
		public VariableValueCheck checkX = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(labelText="X Value")]
		[ORKEditorLayout(autoInit=true)]
		public EventFloat valueX;
		
		[ORKEditorInfo(labelText="X Value 2")]
		[ORKEditorLayout(new string[] {"checkX", "checkX"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, endGroups=2, autoInit=true)]
		public EventFloat valueX2;
		
		// Y
		[ORKEditorHelp("Check Y-Axis", "The Y-axis of the vector will be checked.", "")]
		[ORKEditorInfo(separator=true, labelText="Y-Axis")]
		public bool useY = false;
		
		[ORKEditorHelp("Check Type", "Checks if the Y-axis value is equal, not equal, less or greater than a value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorLayout("useY", true)]
		public VariableValueCheck checkY = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(labelText="Y Value")]
		[ORKEditorLayout(autoInit=true)]
		public EventFloat valueY;
		
		[ORKEditorInfo(labelText="Y Value 2")]
		[ORKEditorLayout(new string[] {"checkY", "checkY"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, endGroups=2, autoInit=true)]
		public EventFloat valueY2;
		
		// Z
		[ORKEditorHelp("Check Z-Axis", "The Z-axis of the vector will be checked.", "")]
		[ORKEditorInfo(separator=true, labelText="Z-Axis")]
		public bool useZ = false;
		
		[ORKEditorHelp("Check Type", "Checks if the Z-axis value is equal, not equal, less or greater than a value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorLayout("useZ", true)]
		public VariableValueCheck checkZ = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(labelText="Z Value")]
		[ORKEditorLayout(autoInit=true)]
		public EventFloat valueZ;
		
		[ORKEditorInfo(labelText="Z Value 2")]
		[ORKEditorLayout(new string[] {"checkZ", "checkZ"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, endGroups=2, autoInit=true)]
		public EventFloat valueZ2;
		
		public CheckTransformStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(this.fromObject.GetObject(baseEvent), baseEvent))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool DoCheck(List<GameObject> list, BaseEvent baseEvent)
		{
			bool any = false;
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					Vector3 value = Vector3.zero;
					if(TransformVectorOrigin.Position.Equals(this.origin))
					{
						value = list[i].transform.position;
					}
					else if(TransformVectorOrigin.Rotation.Equals(this.origin))
					{
						value = list[i].transform.eulerAngles;
					}
					else if(TransformVectorOrigin.Scale.Equals(this.origin))
					{
						value = list[i].transform.localScale;
					}
					
					if((!this.useX || 
							ValueHelper.CheckVariableValue(value.x, this.valueX.GetValue(baseEvent), 
								this.valueX2 != null ? this.valueX2.GetValue(baseEvent) : 0, this.checkX)) && 
						(!this.useY || 
							ValueHelper.CheckVariableValue(value.y, this.valueY.GetValue(baseEvent), 
								this.valueY2 != null ? this.valueY2.GetValue(baseEvent) : 0, this.checkY)) && 
						(!this.useZ || 
							ValueHelper.CheckVariableValue(value.z, this.valueZ.GetValue(baseEvent), 
								this.valueZ2 != null ? this.valueZ2.GetValue(baseEvent) : 0, this.checkZ)))
					{
						if(Needed.One.Equals(needed))
						{
							return true;
						}
						else
						{
							any = true;
						}
					}
					else if(Needed.All.Equals(needed))
					{
						return false;
					}
				}
			}
			return any;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString();
		}
	}
	
	[ORKEditorHelp("Transform To Variable", "Stores a transform's position, " +
		"rotation or scale into a Vector3 game variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Movement Steps", "Variable Steps")]
	public class TransformToVariableStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Origin Object")]
		public EventObjectSetting originObject = new EventObjectSetting();
		
		[ORKEditorHelp("Use Center", "The center/average of all found objects is used.\n" +
			"If disabled, the first object's transform values are used.", "")]
		public bool useCenter = false;
		
		[ORKEditorHelp("Value Origin", "Select the Vector3 value that will be checked:\n" +
			"- Position: The position of the transform.\n" +
			"- Rotation: The rotation (euler angles) of the transform.\n" +
			"- Scale: The scale (local scale) of the transform.", "")]
		[ORKEditorInfo(separator=true)]
		public TransformVectorOrigin valueOrigin = TransformVectorOrigin.Position;
		
		
		// variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Settings")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		
		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Set: Sets the current variable value to the value.\n" +
			"- Cross: The cross product of the current value (left hand side) and the defined value (right hand side).\n" +
			"- Min: A new vector created of the smallest values of the current value and the defined value.\n" +
			"- Max: A new vector created of the largest values of the current value and the defined value.\n" +
			"- Scale: Multiplies each component of the current value by the same component of the defined value.\n" +
			"- Project: Projects the current value using the defind value as 'onNormal'.\n" +
			"- Reflect: Reflects the current value using the defined value as 'inNormal.\n" +
			"More information on Vector3 operations can be found in the Unity documentation.", "")]
		public Vector3Operator vector3Operator = Vector3Operator.Set;
		
		[ORKEditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool normalize = false;
		
		public TransformToVariableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Vector3 tmpVal = Vector3.zero;
			
			// get value
			if(this.useCenter)
			{
				if(TransformVectorOrigin.Position.Equals(this.valueOrigin))
				{
					tmpVal = TransformHelper.GetCenterPosition(this.originObject.GetObject(baseEvent));
				}
				else if(TransformVectorOrigin.Rotation.Equals(this.valueOrigin))
				{
					tmpVal = TransformHelper.GetAverageEulerAngles(this.originObject.GetObject(baseEvent));
				}
				else if(TransformVectorOrigin.Scale.Equals(this.valueOrigin))
				{
					tmpVal = TransformHelper.GetAverageScale(this.originObject.GetObject(baseEvent));
				}
			}
			else
			{
				GameObject obj = TransformHelper.GetFirstObject(this.originObject.GetObject(baseEvent));
				if(obj != null)
				{
					if(TransformVectorOrigin.Position.Equals(this.valueOrigin))
					{
						tmpVal = obj.transform.position;
					}
					else if(TransformVectorOrigin.Rotation.Equals(this.valueOrigin))
					{
						tmpVal = obj.transform.eulerAngles;
					}
					else if(TransformVectorOrigin.Scale.Equals(this.valueOrigin))
					{
						tmpVal = obj.transform.localScale;
					}
				}
			}
			
			// change variable
			if(VariableOrigin.Local.Equals(this.origin))
			{
				baseEvent.Variables.ChangeVector3(this.key.GetValue(), 
					tmpVal, this.vector3Operator, this.normalize);
			}
			else if(VariableOrigin.Global.Equals(this.origin))
			{
				ORK.Game.Variables.ChangeVector3(this.key.GetValue(), 
					tmpVal, this.vector3Operator, this.normalize);
			}
			else if(VariableOrigin.Object.Equals(this.origin))
			{
				if(this.useObject)
				{
					List<GameObject> list = this.fromObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							ObjectVariablesComponent[] comps = list[i].
								GetComponentsInChildren<ObjectVariablesComponent>();
							for(int j=0; j<comps.Length; j++)
							{
								comps[j].GetHandler().ChangeVector3(
									this.key.GetValue(), tmpVal, this.vector3Operator, this.normalize);
							}
						}
					}
				}
				else
				{
					ORK.Game.Scene.GetObjectVariables(this.objectID).ChangeVector3(
						this.key.GetValue(), tmpVal, this.vector3Operator, this.normalize);
				}
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + 
				this.vector3Operator.ToString() + " " + 
				this.valueOrigin.ToString();
		}
	}
	
	[ORKEditorHelp("Change Nav Mesh Target", "Set a target for a Nav Mesh agent or stop the agent.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Movement Steps")]
	public class ChangeNavMeshTargetStep : BaseEventStep
	{
		// moving object
		[ORKEditorInfo(labelText="Moving Object")]
		public EventObjectSetting moveObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between moving two objects.\n" +
			"Only used if greater than 0 and more than one object will be moved.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start moving before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// nav mesh
		[ORKEditorHelp("Stop", "Stops the Nav Mesh agent.", "")]
		[ORKEditorInfo(separator=true)]
		public bool stop = false;
		
		[ORKEditorHelp("Set Speed", "Set the speed of the Nav Mesh agent.", "")]
		[ORKEditorInfo(separator=true, labelText="Move Speed")]
		[ORKEditorLayout("stop", false, setDefault=true, defaultValue=false)]
		public bool setSpeed = false;
		
		[ORKEditorLayout("setSpeed", true, endCheckGroup=true, autoInit=true)]
		public EventFloat speed;
		
		// target
		[ORKEditorHelp("To Object", "Use another object's position as target position.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Position")]
		public bool toObject = false;
		
		[ORKEditorLayout("toObject", true, autoInit=true)]
		public EventObjectSetting targetObject;
		
		[ORKEditorHelp("Use Center", "The center of all target objects will be used.\n" +
			"If disabled, the target object with the same index as the " +
			"moving object is used (or the first existing target object).", "")]
		public bool useCenter = false;
		
		[ORKEditorHelp("Local Space", "The offset is added in local space of the target.", "")]
		public bool localSpace = false;
		
		[ORKEditorHelp("Offset", "The offset added to the target's position.", "")]
		public Vector3 offset = Vector3.zero;
		
		[ORKEditorInfo(separator=true, labelText="Position")]
		[ORKEditorLayout(elseCheckGroup=true, autoInit=true)]
		public EventVector3 position;
		
		[ORKEditorHelp("Local Position", "The position is in local space of the object.\n" +
			"If disabled, the position is in world space.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public bool localPosition = false;
		
		
		// ingame
		private bool finished = false;
		
		private List<GameObject> list;
		
		private List<GameObject> target;
		
		private GameObject centerObj;
		
		private int index = 0;
		
		public ChangeNavMeshTargetStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.centerObj = null;
			this.finished = false;
			this.list = this.moveObject.GetObject(baseEvent);
			if(this.toObject)
			{
				this.target = this.targetObject.GetObject(baseEvent);
			}
			else
			{
				this.target = null;
			}
			this.index = 0;
			
			if(this.list.Count > 0 && (!this.toObject || this.target.Count > 0))
			{
				if(this.target != null && this.useCenter && this.target.Count > 0)
				{
					if(this.target.Count == 1)
					{
						this.centerObj = this.target[0];
					}
					else
					{
						this.centerObj = new GameObject("_CenterObj");
						CenterEventMover mover = this.centerObj.AddComponent<CenterEventMover>();
						mover.SetCenter(this.target, this.localSpace, this.offset, 0 + this.timeBetween * (this.list.Count - 1));
					}
				}
				
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				NavMeshAgent agent = ComponentHelper.GetInChildren<NavMeshAgent>(this.list[this.index]);
				if(agent != null)
				{
					if(this.stop)
					{
						agent.Stop();
					}
					else
					{
						if(this.setSpeed)
						{
							agent.speed = this.speed.GetValue(baseEvent);
						}
						
						// set to object
						if(this.toObject)
						{
							GameObject tObj = this.GetTarget();
							if(tObj != null)
							{
								if(this.localSpace)
								{
									agent.SetDestination(tObj.transform.TransformPoint(this.offset));
								}
								else
								{
									agent.SetDestination(tObj.transform.position + this.offset);
								}
							}
						}
						// set to position
						else
						{
							agent.SetDestination(this.localPosition ? 
								this.list[this.index].transform.TransformPoint(this.position.GetValue(baseEvent)) : 
								this.position.GetValue(baseEvent));
						}
					}
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(!this.finished && this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				if(this.centerObj != null && 
					this.centerObj != this.target[0])
				{
					GameObject.Destroy(this.centerObj);
				}
				this.centerObj = null;
				this.finished = false;
				this.list = null;
				this.target = null;
				this.index = 0;
			}
		}
		
		private GameObject GetTarget()
		{
			if(this.target != null && this.target.Count > 0)
			{
				if(this.useCenter)
				{
					return centerObj;
				}
				else
				{
					if(this.index < this.target.Count)
					{
						return this.target[this.index];
					}
					else
					{
						return this.target[0];
					}
				}
			}
			return null;
		}
	}
	
	[ORKEditorHelp("Change Gravity", "Changes Physics.gravity or Physics2D.gravity.\n" +
		"The gravity influences all game objects with a 'Rigidbody' or 'Rigidbody2D' component.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Movement Steps", "Function Steps")]
	public class ChangeGravityStep : BaseEventStep
	{
		[ORKEditorHelp("Use 2D", "Change Physics2D.gravity instead of Physics.gravity.", "")]
		public bool use2D = false;
		
		[ORKEditorInfo(separator=true, labelText="Gravity Value")]
		public EventVector3 gravity = new EventVector3();
		
		public ChangeGravityStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.use2D)
			{
				Physics2D.gravity = this.gravity.GetValue(baseEvent);
			}
			else
			{
				Physics.gravity = this.gravity.GetValue(baseEvent);
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.gravity.GetInfoText();
		}
	}
}
