
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Play Sound", "Plays a sound.\n" +
		"An AudioSource component will be added to the target game object automatically, if none is added already.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Audio Steps")]
	public class PlaySoundStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Play On")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between playing a sound on two objects.\n" +
			"Only used if greater than 0 and more than one object will play a sound.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start playing before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// audio settings
		[ORKEditorHelp("Use Sound Type", "The combatant's defined sound of a selected sound type will be used.\n" +
			"If the object doesn't have a combatant, no audio clip will be played and the next step will be executed immediately.", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Settings")]
		public bool useSoundType = false;
		
		[ORKEditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		[ORKEditorLayout("useSoundType", true)]
		public int soundTypeID = 0;
		
		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be played.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=3)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		[ORKEditorHelp("Wait", "Wait until the audio clip has finished before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true)]
		public bool wait = false;
		
		[ORKEditorInfo(separator=true)]
		public PlayAudioSettings audio = new PlayAudioSettings();
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		private float tmpTime = 0;
		
		public PlaySoundStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.tmpTime = 0;
			this.list = this.onObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				AudioClip clip = null;
				if(this.useSoundType)
				{
					Combatant c = ComponentHelper.GetCombatant(this.list[this.index]);
					if(c != null)
					{
						clip = c.Animations.GetAudioClip(this.soundTypeID);
					}
				}
				else
				{
					clip = baseEvent.GetAudioClip(this.id);
				}
				
				if(clip != null)
				{
					float t = this.audio.PlayAudio(this.list[this.index], clip);
					if(t > this.tmpTime)
					{
						this.tmpTime = t;
					}
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.wait && this.tmpTime > 0)
					{
						baseEvent.StartTime(this.tmpTime, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
				this.tmpTime = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useSoundType ? ORK.SoundTypes.GetName(this.soundTypeID) : "Audio Clip " + this.id) + 
				(this.wait ? " (wait)" : "");
		}
	}
	
	[ORKEditorHelp("Stop Sound", "Stops a sound.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Audio Steps")]
	public class StopSoundStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Stop On")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between playing a sound on two objects.\n" +
			"Only used if greater than 0 and more than one object will play a sound.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start playing before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		[ORKEditorHelp("Pause", "The audio clip is paused/unpaused and not stopped.\n" +
			"If the clip currently is playing, it will be paused - if it isn't playing, it will be played.", "")]
		[ORKEditorInfo(separator=true)]
		public bool pause = false;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public StopSoundStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.onObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				AudioSource audio = this.list[this.index].GetComponent<AudioSource>();
				if(audio != null)
				{
					if(this.pause)
					{
						if(audio.isPlaying)
						{
							audio.Pause();
						}
						else
						{
							audio.Play();
						}
					}
					else
					{
						audio.Stop();
					}
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		public override bool ExecuteOnStop
		{
			get{ return true;}
		}
	}
	
	[ORKEditorHelp("Change Music", "Plays or stops a music clip.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Audio Steps")]
	public class ChangeMusicStep : BaseEventStep
	{
		[ORKEditorHelp("Play Type", "Select how the music should be played (or stopped):\n" +
			"- Play: Plays the music clip and stops the currently playing clip.\n" +
			"- Stop: Stops the currently playing music clip.\n" +
			"- Fade In: Fades in the music clip and stops the currently playing clip.\n" +
			"- Fade Out: Fades out the currently playing music clip and stops it.\n" +
			"- Fade To: Fades from the currently playing clip to the new one.", "")]
		public MusicPlayType type = MusicPlayType.Play;
		
		[ORKEditorHelp("Play Stored Music", "The currently stored clip will be played from it's stored time position.", "")]
		[ORKEditorLayout(new string[] {"type", "type", "type"}, 
			new System.Object[] {MusicPlayType.Play, MusicPlayType.FadeIn, MusicPlayType.FadeTo}, 
			needed=Needed.One)]
		public bool stored = false;
		
		[ORKEditorHelp("Music Clip", "Select the music clip that will be played.", "")]
		[ORKEditorInfo(ORKDataType.MusicClip)]
		[ORKEditorLayout("stored", false, endCheckGroup=true, endGroups=2)]
		public int id = 0;
		
		[ORKEditorHelp("Fade Time (s)", "The time in seconds used to fade the music clip.", "")]
		[ORKEditorLayout(new string[] {"type", "type", "type"}, 
			new System.Object[] {MusicPlayType.FadeIn, MusicPlayType.FadeOut, MusicPlayType.FadeTo}, 
			needed=Needed.One, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float fade = 1;
		
		[ORKEditorHelp("Interpolation", "The interpolation used for fading.", "")]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {MusicPlayType.FadeIn, MusicPlayType.FadeTo}, 
			needed=Needed.One, endCheckGroup=true)]
		public EaseType interpolation = EaseType.Linear;
		
		public ChangeMusicStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(MusicPlayType.Play.Equals(this.type))
			{
				if(this.stored)
				{
					ORK.Music.PlayStored(false);
				}
				else
				{
					ORK.Music.Play(this.id);
				}
			}
			else if(MusicPlayType.Stop.Equals(this.type))
			{
				ORK.Music.Stop();
			}
			else if(MusicPlayType.FadeIn.Equals(this.type))
			{
				if(this.stored)
				{
					ORK.Music.FadeInStored(this.fade, this.interpolation, false);
				}
				else
				{
					ORK.Music.FadeIn(this.id, this.fade, this.interpolation);
				}
			}
			else if(MusicPlayType.FadeOut.Equals(this.type))
			{
				ORK.Music.FadeOut(this.fade, this.interpolation);
			}
			else if(MusicPlayType.FadeTo.Equals(this.type))
			{
				if(this.stored)
				{
					ORK.Music.FadeToStored(this.fade, this.interpolation, false);
				}
				else
				{
					ORK.Music.FadeTo(this.id, this.fade, this.interpolation);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.type + (MusicPlayType.Stop.Equals(this.type) ? "" : 
				(this.stored ? " stored" : " " + ORK.MusicClips.GetName(this.id)));
		}
	}
	
	[ORKEditorHelp("Store Music", "Stores the currently playing music clip and its time position.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Audio Steps")]
	public class StoreMusicStep : BaseEventStep
	{
		public StoreMusicStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Music.StoreCurrent(false);
			baseEvent.StepFinished(this.next);
		}
	}
}
