
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Add To Inventory", "Adds items, equipment or money to a combatant's inventory.\n" +
		"If group inventory is used, it will be added to the inventory of the group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Inventory Steps")]
	public class AddToInventoryStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will receive the items.\n" +
			"If the actor doesn't have a combatant, no one will receive items.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Show Notification", "Adding the items will display a notification.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "Adding the items will be displayed in the console.", "")]
		public bool showConsole = true;
		
		[ORKEditorInfo(separator=true, labelText="Add Items")]
		[ORKEditorArray(false, "Add Item", "Adds an item to the list.", "", 
			"Remove", "Removes this item from the list.", "", 
			noRemoveCount=1, isCopy=true, isMove=true, foldout=true, foldoutText=new string[] {
				"Item", "Define the item.", ""
		})]
		public EventItemGain[] item = new EventItemGain[] {new EventItemGain()};
		
		public AddToInventoryStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Inventory> added = new List<Inventory>();
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			
			ItemGain[] tmpItem = new ItemGain[this.item.Length];
			for(int i=0; i<this.item.Length; i++)
			{
				tmpItem[i] = this.item[i].GetItemGain(baseEvent);
			}
			
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && !added.Contains(list[i].Inventory))
				{
					list[i].Inventory.Add(tmpItem, this.showNotification, this.showConsole);
					added.Add(list[i].Inventory);
					if(ORK.InventorySettings.IsGroup())
					{
						break;
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Remove From Inventory", "Removes items, equipment or money from a combatant's inventory.\n" +
		"If group inventory is used, it will be removed from the inventory of the group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Inventory Steps")]
	public class RemoveFromInventoryStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will lose the items.\n" +
			"If the actor doesn't have a combatant, no one will lose items.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Drop Items", "The items will be dropped at the position of the actor.", "")]
		public bool drop = false;
		
		[ORKEditorHelp("Show Notification", "Removing the items will display a notification.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "Removing the items will be displayed in the console.", "")]
		public bool showConsole = true;
		
		[ORKEditorInfo(separator=true, labelText="Remove Items")]
		[ORKEditorArray(false, "Add Item", "Adds an item to the list.", "", 
			"Remove", "Removes this item from the list.", "", 
			noRemoveCount=1, isCopy=true, isMove=true, foldout=true, foldoutText=new string[] {
				"Item", "Define the item.", ""
		})]
		public EventItemGain[] item = new EventItemGain[] {new EventItemGain()};
		
		public RemoveFromInventoryStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Inventory> added = new List<Inventory>();
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			
			ItemGain[] tmpItem = new ItemGain[this.item.Length];
			for(int i=0; i<this.item.Length; i++)
			{
				tmpItem[i] = this.item[i].GetItemGain(baseEvent);
			}
			
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && !added.Contains(list[i].Inventory))
				{
					if(this.drop && list[i].GameObject != null)
					{
						list[i].Inventory.Drop(tmpItem, list[i].GameObject.transform.position, 
							this.showNotification, this.showConsole);
					}
					else
					{
						list[i].Inventory.Remove(tmpItem, this.showNotification, this.showConsole);
					}
					added.Add(list[i].Inventory);
					if(ORK.InventorySettings.IsGroup())
					{
						break;
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Has In Inventory", "Checks if a combatant's inventory has items, equipment or money.\n" +
		"If group inventory is used, the inventory of the group will be checked.\n" +
		"The individual item's inventory check will only be made if the item's chance check is valid.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Inventory Steps", "Check Steps")]
	public class HasInInventoryStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked for the items.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorInfo(separator=true, labelText="Check Items")]
		[ORKEditorArray(false, "Add Item", "Adds an item to the list.", "", 
			"Remove", "Removes this item from the list.", "", 
			noRemoveCount=1, isCopy=true, isMove=true, foldout=true, foldoutText=new string[] {
				"Item", "Define the item.", ""
		})]
		public EventItemGain[] item = new EventItemGain[] {new EventItemGain()};
		
		public HasInInventoryStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = true;
			bool any = false;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			
			ItemGain[] tmpItem = new ItemGain[this.item.Length];
			for(int i=0; i<this.item.Length; i++)
			{
				tmpItem[i] = this.item[i].GetItemGain(baseEvent);
			}
			
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					any = true;
					if(!list[i].Inventory.Has(tmpItem))
					{
						check = false;
						break;
					}
				}
			}
			if(any && check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
	}
	
	[ORKEditorHelp("Drop Items", "Drops items, equipment or money at the position of an object.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Inventory Steps")]
	public class DropItemsStep : BaseEventStep
	{
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("At Center", "The items are dropped at the center position of " +
			"all selected objects (e.g. when using all spawned prefabs).\n" +
			"If disabled, the items will be dropped at the position of every object " +
			"(the chance is calculated on each position separately).", "")]
		public bool center = false;
		
		[ORKEditorInfo(separator=true, labelText="Drop Items")]
		[ORKEditorArray(false, "Add Item", "Adds an item to the list.", "", 
			"Remove", "Removes this item from the list.", "", 
			noRemoveCount=1, isCopy=true, isMove=true, foldout=true, foldoutText=new string[] {
				"Item", "Define the item.", ""
		})]
		public EventItemGain[] item = new EventItemGain[] {new EventItemGain()};
		
		public DropItemsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<GameObject> list = this.onObject.GetObject(baseEvent);
			
			if(this.center)
			{
				if(list.Count > 0)
				{
					for(int i=0; i<this.item.Length; i++)
					{
						this.item[i].GetItemGain(baseEvent).Drop(
							TransformHelper.GetCenterPosition(list), true);
					}
				}
			}
			else
			{
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						for(int j=0; j<this.item.Length; j++)
						{
							this.item[j].GetItemGain(baseEvent).Drop(
								list[i].transform.position, true);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Set Inventory Money", "Set the amount of money of a combatant's inventory.\n" +
		"If group inventory is used, it will be set in the inventory of the group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Inventory Steps")]
	public class SetInventoryMoneyStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Currency", "Select the currency that will be set.", "")]
		[ORKEditorInfo(ORKDataType.Currency)]
		public int currencyID = 0;
		
		[ORKEditorHelp("Quantity", "The amount of money the selected currency will be set to.", "")]
		[ORKEditorLimit(0, false)]
		public int amount = 0;
		
		[ORKEditorHelp("Show Notification", "Adding the currency will display a notification.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "Adding the currency will be displayed in the console.", "")]
		public bool showConsole = true;
		
		public SetInventoryMoneyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Inventory> added = new List<Inventory>();
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && !added.Contains(list[i].Inventory))
				{
					list[i].Inventory.SetMoney(this.currencyID, this.amount, 
						this.showNotification, this.showConsole);
					added.Add(list[i].Inventory);
					if(ORK.InventorySettings.IsGroup())
					{
						break;
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Set Exchange Rate", "Set a currency's exchange rate.\n" +
		"The base currency (i.e. the first currency, index 0) will be used to calculate money exchanges.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Inventory Steps")]
	public class SetExchangeRateStep : BaseEventStep
	{
		[ORKEditorHelp("Currency", "Select the currency that will be set.\n" +
			"Please note that you can't change the base currency's exchange rate - " +
			"regardless of your setting, this will always be set to 1.", "")]
		[ORKEditorInfo(ORKDataType.Currency)]
		public int currencyID = 0;
		
		[ORKEditorInfo(separator=true, labelText="Exchange Rate", 
			label=new string[] {"The lowest possible value is 0.0001!"})]
		public EventFloat exchangeRate = new EventFloat(1);
		
		public SetExchangeRateStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Game.SetExchangeRate(this.currencyID, this.exchangeRate.GetValue(baseEvent));
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Currencies.GetName(this.currencyID) + " " + this.exchangeRate.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Exchange Inventory Money", "Exchange the money in a combatant's inventory from one currency to another.\n" +
		"If group inventory is used, it will be exchanged in the inventory of the group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Inventory Steps")]
	public class ExchangeInventoryMoneyStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("From Currency", "Select the currency that will be changed from.", "")]
		[ORKEditorInfo(ORKDataType.Currency)]
		public int fromCurrencyID = 0;
		
		[ORKEditorHelp("All", "All available money in the selected currency will be exchanged.\n" +
			"If disabled, only a defined amount of money will be exchanged", "")]
		public bool all = false;
		
		[ORKEditorHelp("Quantity", "The amount of money that will be exchanged.\n" +
			"If the inventory contains less money, all available money will be exchanged (of the selected currency).", "")]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		[ORKEditorLimit(0, false)]
		public int amount = 0;
		
		[ORKEditorHelp("To Currency", "Select the currency that will be changed to.", "")]
		[ORKEditorInfo(ORKDataType.Currency)]
		public int toCurrencyID = 0;
		
		[ORKEditorHelp("Show Notification", "Adding/removing the currencies will display a notification.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "Adding/removing the currencies will be displayed in the console.", "")]
		public bool showConsole = true;
		
		public ExchangeInventoryMoneyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.fromCurrencyID != this.toCurrencyID)
			{
				List<Inventory> added = new List<Inventory>();
				List<Combatant> list = baseEvent.GetActorCombatant(this.id);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null && !added.Contains(list[i].Inventory))
					{
						int money = this.all ? 
							list[i].Inventory.GetMoney(this.fromCurrencyID) : 
							(list[i].Inventory.HasEnoughMoney(this.fromCurrencyID, this.amount) ? 
								this.amount : list[i].Inventory.GetMoney(this.fromCurrencyID));
						list[i].Inventory.SubMoney(this.fromCurrencyID, money, 
							this.showNotification, this.showConsole);
						list[i].Inventory.AddMoney(this.toCurrencyID, 
							ORK.Game.ExchangeCurrency(this.fromCurrencyID, money, this.toCurrencyID), 
							this.showNotification, this.showConsole);
						
						if(ORK.InventorySettings.IsGroup())
						{
							break;
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Clear Inventory", "Removes everything (money, items, weapons and armors) from an inventory.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Inventory Steps")]
	public class ClearInventoryStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		public ClearInventoryStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Inventory.Clear();
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
}
