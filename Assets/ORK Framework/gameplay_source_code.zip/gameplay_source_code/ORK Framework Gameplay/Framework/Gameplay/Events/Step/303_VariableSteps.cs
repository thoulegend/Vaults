
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using ORKFramework.Reflection;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Change Game Variables", "Changes game variables.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Variable Steps")]
	public class ChangeGameVariableStep : BaseEventStep
	{
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		
		// variables
		[ORKEditorInfo(separator=true)]
		public VariableSetter change = new VariableSetter();
		
		public ChangeGameVariableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(VariableOrigin.Local.Equals(this.origin))
			{
				this.change.SetVariables(baseEvent.Variables);
			}
			else if(VariableOrigin.Global.Equals(this.origin))
			{
				this.change.SetVariables(ORK.Game.Variables);
			}
			else if(VariableOrigin.Object.Equals(this.origin))
			{
				if(this.useObject)
				{
					List<GameObject> list = this.fromObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							ObjectVariablesComponent[] comps = list[i].
								GetComponentsInChildren<ObjectVariablesComponent>();
							for(int j=0; j<comps.Length; j++)
							{
								this.change.SetVariables(comps[j].GetHandler());
							}
						}
					}
				}
				else
				{
					this.change.SetVariables(ORK.Game.Scene.GetObjectVariables(this.objectID));
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString();
		}
	}
	
	[ORKEditorHelp("Check Game Variables", "Checks if game variables have certain values.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Variable Steps", "Check Steps")]
	public class CheckGameVariableStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to check the object variables.\n" +
			"The check will be made on every 'Object Variables' component that is found. " +
			"If no component is found, the check failed.\n" +
			"If disabled, you need to define the object ID used to check the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created - usually resulting in a failed check.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		
		// variables
		[ORKEditorInfo(separator=true)]
		public VariableCondition condition = new VariableCondition();
		
		public CheckGameVariableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			
			if(VariableOrigin.Local.Equals(this.origin))
			{
				check = this.condition.CheckVariables(baseEvent.Variables);
			}
			else if(VariableOrigin.Global.Equals(this.origin))
			{
				check = this.condition.CheckVariables(ORK.Game.Variables);
			}
			else if(VariableOrigin.Object.Equals(this.origin))
			{
				if(this.useObject)
				{
					List<GameObject> list = this.fromObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							ObjectVariablesComponent[] comps = list[i].
								GetComponentsInChildren<ObjectVariablesComponent>();
							int count = 0;
							for(int j=0; j<comps.Length; j++)
							{
								if(this.condition.CheckVariables(comps[j].GetHandler()))
								{
									count++;
								}
							}
							if(comps.Length == count)
							{
								check = true;
							}
							else
							{
								check = false;
								break;
							}
						}
					}
				}
				else
				{
					check = this.condition.CheckVariables(ORK.Game.Scene.GetObjectVariables(this.objectID));
				}
			}
			
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString();
		}
	}
	
	[ORKEditorHelp("Game Variable Fork", "Checks a single game variable for certain values.\n" +
		"If a variable condition is valid, it's next step will be executed.\n" +
		"If no variable condition is valid, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Variable Steps", "Check Steps")]
	public class GameVariableForkStep : BaseEventStep
	{
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to check the object variables.\n" +
			"The check will be made on every 'Object Variables' component that is found. " +
			"If no component is found, the check failed.\n" +
			"If disabled, you need to define the object ID used to check the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created - usually resulting in a failed check.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		
		// variable
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		[ORKEditorArray(false, "Add Condition", "Adds a new game variable condition.", "", 
			"Remove", "Removes the game variable condition.", "", isMove=true, isCopy=true, 
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Variable Condition", "Define the game variable condition that must be valid.", ""
		})]
		public CheckVariableNextNode[] condition = new CheckVariableNextNode[] {new CheckVariableNextNode()};
		
		public GameVariableForkStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int check = this.next;
			
			if(VariableOrigin.Local.Equals(this.origin))
			{
				this.Check(ref check, this.key.GetValue(), baseEvent.Variables);
			}
			else if(VariableOrigin.Global.Equals(this.origin))
			{
				this.Check(ref check, this.key.GetValue(), ORK.Game.Variables);
			}
			else if(VariableOrigin.Object.Equals(this.origin))
			{
				if(this.useObject)
				{
					List<GameObject> list = this.fromObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						bool found = false;
						if(list[i] != null)
						{
							ObjectVariablesComponent[] comps = list[i].
								GetComponentsInChildren<ObjectVariablesComponent>();
							for(int j=0; j<comps.Length; j++)
							{
								if(this.Check(ref check, this.key.GetValue(), comps[j].GetHandler()))
								{
									found = true;
									break;
								}
							}
						}
						if(found)
						{
							break;
						}
					}
				}
				else
				{
					this.Check(ref check, this.key.GetValue(), ORK.Game.Scene.GetObjectVariables(this.objectID));
				}
			}
			
			baseEvent.StepFinished(check);
		}
		
		private bool Check(ref int check, string varKey, VariableHandler handler)
		{
			for(int i=0; i<this.condition.Length; i++)
			{
				if(this.condition[i].Check(varKey, handler))
				{
					check = this.condition[i].next;
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.key.GetInfoText();
		}
		
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return "Condition " + (index - 1) + ": " + this.condition[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Clear Game Variables", "Removes all game variables.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Variable Steps")]
	public class ClearGameVariablesStep : BaseEventStep
	{
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		public ClearGameVariablesStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(VariableOrigin.Local.Equals(this.origin))
			{
				baseEvent.Variables.Clear();
			}
			else if(VariableOrigin.Global.Equals(this.origin))
			{
				ORK.Game.Variables.Clear();
			}
			else if(VariableOrigin.Object.Equals(this.origin))
			{
				if(this.useObject)
				{
					List<GameObject> list = this.fromObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							ObjectVariablesComponent[] comps = list[i].
								GetComponentsInChildren<ObjectVariablesComponent>();
							for(int j=0; j<comps.Length; j++)
							{
								comps[j].GetHandler().Clear();
							}
						}
					}
				}
				else
				{
					ORK.Game.Scene.GetObjectVariables(this.objectID).Clear();
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString();
		}
	}
	
	[ORKEditorHelp("Inventory To Variable", "Stores the quantity of a selected " +
		"item, currency, weapon or armor found in an inventory into a float game variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Variable Steps", "Inventory Steps")]
	public class InventoryToVariableStep : BaseEventStep
	{
		// inventory object
		[ORKEditorHelp("Actor", "Select the actor who's inventory will be used.\n" +
			"If the actor doesn't have a combatant, nothing will be stored into the game variable.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		// variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Settings")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		
		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		public FormulaOperator floatOperator = FormulaOperator.Add;
		
		
		// item selection
		[ORKEditorHelp("Type", "Select the type, either an item, weapon, armor or money.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Item Settings")]
		public ItemDropType type = ItemDropType.Item;
		
		[ORKEditorHelp("Selection", "Select the item, currency or equipment (based on the selected type).", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="type")]
		public int itemID = 0;
		
		public InventoryToVariableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int quantity = -1;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(ItemDropType.Item.Equals(this.type))
					{
						quantity = list[i].Inventory.GetItemCount(this.itemID);
					}
					else if(ItemDropType.Money.Equals(this.type))
					{
						quantity = list[i].Inventory.GetMoney(this.itemID);
					}
					else if(ItemDropType.Weapon.Equals(this.type))
					{
						quantity = list[i].Inventory.GetWeaponCount(this.itemID);
					}
					else if(ItemDropType.Armor.Equals(this.type))
					{
						quantity = list[i].Inventory.GetArmorCount(this.itemID);
					}
					break;
				}
			}
			
			if(quantity != -1)
			{
				if(VariableOrigin.Local.Equals(this.origin))
				{
					baseEvent.Variables.ChangeFloat(this.key.GetValue(), 
						quantity, this.floatOperator);
				}
				else if(VariableOrigin.Global.Equals(this.origin))
				{
					ORK.Game.Variables.ChangeFloat(this.key.GetValue(), 
						quantity, this.floatOperator);
				}
				else if(VariableOrigin.Object.Equals(this.origin))
				{
					if(this.useObject)
					{
						List<GameObject> list2 = this.fromObject.GetObject(baseEvent);
						for(int i=0; i<list2.Count; i++)
						{
							if(list2[i] != null)
							{
								ObjectVariablesComponent[] comps = list2[i].
									GetComponentsInChildren<ObjectVariablesComponent>();
								for(int j=0; j<comps.Length; j++)
								{
									comps[j].GetHandler().ChangeFloat(
										this.key.GetValue(), quantity, this.floatOperator);
								}
							}
						}
					}
					else
					{
						ORK.Game.Scene.GetObjectVariables(this.objectID).ChangeFloat(
							this.key.GetValue(), quantity, this.floatOperator);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.type.ToString();
		}
	}
	
	[ORKEditorHelp("Raycast To Variable", "Stores the hit point of a raycast into a Vector3 game variable.\n" +
		"If something was hit, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Variable Steps")]
	public class RaycastToVariableStep : BaseEventCheckStep, IStepUpdate
	{
		// variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(labelText="Variable Settings")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Set: Sets the current variable value to the value.\n" +
			"- Cross: The cross product of the current value (left hand side) and the defined value (right hand side).\n" +
			"- Min: A new vector created of the smallest values of the current value and the defined value.\n" +
			"- Max: A new vector created of the largest values of the current value and the defined value.\n" +
			"- Scale: Multiplies each component of the current value by the same component of the defined value.\n" +
			"- Project: Projects the current value using the defind value as 'onNormal'.\n" +
			"- Reflect: Reflects the current value using the defined value as 'inNormal.\n" +
			"More information on Vector3 operations can be found in the Unity documentation.", "")]
		public Vector3Operator vector3Operator = Vector3Operator.Set;
		
		[ORKEditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool vector3Normalize = false;
		
		[ORKEditorHelp("Fail sets Origin", "Set the game variable to the raycast's origin position if nothing is hit.\n" +
			"If disabled, the variable wont be set.", "")]
		public bool failSetOrigin = false;
		
		
		// input
		[ORKEditorHelp("Use Input", "Use mouse/touch input to select the target of the raycast.\n" +
			"If disabled, the raycast will be cast using the defined settings.", "")]
		[ORKEditorInfo(separator=true, labelText="Input Settings")]
		public bool useInput = false;
		
		[ORKEditorLayout("useInput", true, autoInit=true)]
		public MouseTouchControl mouseTouch;
		
		// wait
		[ORKEditorHelp("Wait", "The event will wait for a set amount of time for the mouse/touch input.\n" +
			"If disabled, the event will wait until the mouse/touch input has been received.", "")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool wait = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds to wait for the mouse/touch input.", "")]
		[ORKEditorLayout("wait", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		
		// raycast settings
		[ORKEditorHelp("Distance", "The distance the raycast will use.\n" +
			"If nothing is hit within this distance, no target will be found.", "")]
		[ORKEditorInfo(separator=true, labelText="Raycast Settings")]
		public float distance = 100.0f;
		
		[ORKEditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		public LayerMask layerMask = -1;
		
		[ORKEditorHelp("Ray Origin", "The origin position of the raycast.\n" +
			"- User: A game object (e.g. an actor) is the origin.\n" +
			"- Screen: The screen is the origin. If you use mouse/touch control, " +
			"the point you clicked/touched the screen is the origin, else the center of the screen.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public TargetRayOrigin rayOrigin = TargetRayOrigin.User;
		
		[ORKEditorHelp("Use Mouse Position", "Use the current mouse position as target for the raycast.", "")]
		[ORKEditorLayout("useInput", false, endCheckGroup=true)]
		public bool useMousePosition = false;
		
		[ORKEditorHelp("Origin Offset", "The offset will be added to the origin position of the raycast.", "")]
		public Vector3 originOffset = Vector3.zero;
		
		
		// user
		[ORKEditorHelp("Ignore User", "The game object of the user will be ignored by the raycast.", "")]
		[ORKEditorLayout("rayOrigin", TargetRayOrigin.User)]
		public bool ignoreUser = false;
		
		[ORKEditorLayout(autoInit=true)]
		public EventObjectSetting userObject;
		
		[ORKEditorHelp("Direction", "The direction in local space the raycast will be sent to.\n" +
			"E.g. X=0, Y=0, Z=1 will send the raycast forward.\n" +
			"This setting is only used when not using mouse/touch input.", "")]
		[ORKEditorLayout(new string[] {"useInput", "useMousePosition"}, 
			new System.Object[] {false, false}, 
			needed=Needed.All, endCheckGroup=true, endGroups=2)]
		public Vector3 rayDirection = Vector3.forward;
		
		public RaycastToVariableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.useInput)
			{
				baseEvent.WaitForStep(this, this.wait ? this.time : -1, this.nextFail);
			}
			else
			{
				bool found = false;
				Ray ray = new Ray(Vector3.zero, Vector3.forward);
				
				if(TargetRayOrigin.User.Equals(this.rayOrigin))
				{
					int userIndex = -1;
					List<GameObject> list = this.userObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							ray = new Ray(list[i].transform.position + this.originOffset, 
								this.useMousePosition ? 
									VectorHelper.GetDirection(list[i].transform.position + this.originOffset, 
										this.ScreenRayPoint(this.GetMousePosition(), baseEvent)) : 
									list[i].transform.TransformDirection(this.rayDirection));
							userIndex = i;
							break;
						}
					}
					
					if(userIndex >= 0)
					{
						if(this.ignoreUser)
						{
							RaycastOutput[] hit = RaycastHelper.RaycastAll(ray.origin, ray.direction, this.distance, this.layerMask);
							if(hit.Length > 0)
							{
								for(int i=0; i<hit.Length; i++)
								{
									if(!this.ignoreUser || list[userIndex].transform.root != hit[i].transform.root)
									{
										this.SetVariable(hit[i].point, baseEvent);
										found = true;
										break;
									}
								}
							}
						}
					}
				}
				else
				{
					Vector3 tmp = Vector3.zero;
					if(this.useMousePosition)
					{
						tmp = this.GetMousePosition();
					}
					else
					{
						tmp = ORK.GameSettings.GetScreenCenter() + this.originOffset;
						tmp = ORK.Core.GUIMatrix.MultiplyPoint3x4(tmp);
						tmp.y = Screen.height - tmp.y;
					}
					
					Transform cam = baseEvent.GetCamera();
					if(cam != null && cam.GetComponent<Camera>() != null)
					{
						ray = cam.GetComponent<Camera>().ScreenPointToRay(tmp);
					}
					else if(Camera.main != null)
					{
						ray = Camera.main.ScreenPointToRay(tmp);
					}
					RaycastOutput hit = null;
					if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.distance, this.layerMask))
					{
						found = true;
						this.SetVariable(hit.point, baseEvent);
					}
				}
				
				if(found)
				{
					baseEvent.StepFinished(this.next);
				}
				else
				{
					if(this.failSetOrigin)
					{
						this.SetVariable(ray.origin, baseEvent);
					}
					baseEvent.StepFinished(this.nextFail);
				}
			}
		}
		
		public bool Tick(float delta, BaseEvent baseEvent, ref int nextStep)
		{
			Vector3 point = Vector3.zero;
			if(this.mouseTouch.Interacted(ref point))
			{
				bool found = false;
				Ray ray = new Ray(Vector3.zero, Vector3.forward);
				
				if(TargetRayOrigin.User.Equals(this.rayOrigin))
				{
					int userIndex = -1;
					List<GameObject> list = this.userObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							Vector3 origin = list[i].transform.position + this.originOffset;
							ray = new Ray(origin, VectorHelper.GetDirection(origin, point));
							userIndex = i;
							break;
						}
					}
					
					if(userIndex >= 0)
					{
						if(this.ignoreUser)
						{
							RaycastOutput[] hit = RaycastHelper.RaycastAll(ray.origin, ray.direction, this.distance, this.layerMask);
							if(hit.Length > 0)
							{
								for(int i=0; i<hit.Length; i++)
								{
									if(!this.ignoreUser || list[userIndex].transform.root != hit[i].transform.root)
									{
										this.SetVariable(hit[i].point, baseEvent);
										found = true;
										break;
									}
								}
							}
						}
					}
				}
				else
				{
					Transform cam = baseEvent.GetCamera();
					if(cam != null && cam.GetComponent<Camera>() != null)
					{
						ray = cam.GetComponent<Camera>().ScreenPointToRay(point + this.originOffset);
					}
					else if(Camera.main != null)
					{
						ray = Camera.main.ScreenPointToRay(point + this.originOffset);
					}
					RaycastOutput hit = null;
					if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.distance, this.layerMask))
					{
						found = true;
						this.SetVariable(hit.point, baseEvent);
					}
				}
				
				if(found)
				{
					nextStep = this.next;
				}
				else if(this.failSetOrigin)
				{
					this.SetVariable(ray.origin, baseEvent);
				}
				return true;
			}
			return false;
		}
		
		private void SetVariable(Vector3 value, BaseEvent baseEvent)
		{
			if(VariableOrigin.Local.Equals(this.origin))
			{
				baseEvent.Variables.ChangeVector3(this.key.GetValue(), 
					value, this.vector3Operator, this.vector3Normalize);
			}
			else if(VariableOrigin.Global.Equals(this.origin))
			{
				ORK.Game.Variables.ChangeVector3(this.key.GetValue(), 
					value, this.vector3Operator, this.vector3Normalize);
			}
			else if(VariableOrigin.Object.Equals(this.origin))
			{
				if(this.useObject)
				{
					List<GameObject> list = this.fromObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							ObjectVariablesComponent[] comps = list[i].
								GetComponentsInChildren<ObjectVariablesComponent>();
							for(int j=0; j<comps.Length; j++)
							{
								comps[j].GetHandler().ChangeVector3(
									this.key.GetValue(), value, 
									this.vector3Operator, this.vector3Normalize);
							}
						}
					}
				}
				else
				{
					ORK.Game.Scene.GetObjectVariables(this.objectID).ChangeVector3(
						this.key.GetValue(), value, 
						this.vector3Operator, this.vector3Normalize);
				}
			}
		}
		
		private Vector3 GetMousePosition()
		{
			Vector3 pos = this.originOffset + (Vector3)ORK.Control.MousePosition;
			pos = ORK.Core.GUIMatrix.MultiplyPoint3x4(pos);
			pos.y = Screen.height - pos.y;
			return pos;
		}
		
		private Vector3 ScreenRayPoint(Vector3 point, BaseEvent baseEvent)
		{
			Ray ray = new Ray(Vector3.zero, Vector3.forward);
			
			Transform cam = baseEvent.GetCamera();
			if(cam != null && cam.GetComponent<Camera>() != null)
			{
				ray = cam.GetComponent<Camera>().ScreenPointToRay(point);
			}
			else if(Camera.main != null)
			{
				ray = Camera.main.ScreenPointToRay(point);
			}
			
			RaycastOutput hit = null;
			if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.distance, this.layerMask))
			{
				point = hit.point;
			}
			else
			{
				point = ray.GetPoint(this.distance);
			}
			
			return point;
		}
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.key.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Function To Variable", "Stores the return value of a function into a game variable.\n" +
		"Supports string, bool, int/float and Vector3 return values.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Variable Steps", "Function Steps")]
	public class FunctionToVariableStep : BaseEventStep
	{
		// variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(labelText="Variable Settings")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting variableObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		
		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		
		// function
		// object
		[ORKEditorInfo(separator=true, labelText="Function Object")]
		public EventObjectSetting functionObject = new EventObjectSetting();
		
		[ORKEditorHelp("Component Name", "The name of the component that contains the function.", "")]
		[ORKEditorInfo(expandWidth=true, separator=true, labelText="Function Settings")]
		public string name = "";
		
		public CallMethod method = new CallMethod();
		
		public FunctionToVariableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<GameObject> list = this.functionObject.GetObject(baseEvent);
			
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					Component comp = ComponentHelper.Get(list[i], this.name);
					if(comp != null)
					{
						System.Object value = this.method.GetReturnValue(comp);
						
						if(value is string || value is bool || 
							value is int || value is float || value is Vector3)
						{
							if(VariableOrigin.Local.Equals(this.origin))
							{
								this.SetValue(baseEvent.Variables, value);
							}
							else if(VariableOrigin.Global.Equals(this.origin))
							{
								this.SetValue(ORK.Game.Variables, value);
							}
							else if(VariableOrigin.Object.Equals(this.origin))
							{
								if(this.useObject)
								{
									List<GameObject> list2 = this.variableObject.GetObject(baseEvent);
									for(int j=0; j<list2.Count; j++)
									{
										if(list2[j] != null)
										{
											ObjectVariablesComponent[] comps = list2[j].
												GetComponentsInChildren<ObjectVariablesComponent>();
											for(int k=0; k<comps.Length; k++)
											{
												this.SetValue(comps[k].GetHandler(), value);
											}
										}
									}
								}
								else
								{
									this.SetValue(ORK.Game.Scene.GetObjectVariables(this.objectID), value);
								}
							}
						}
					}
				}
			}
			
			
			baseEvent.StepFinished(this.next);
		}
		
		private void SetValue(VariableHandler handler, System.Object value)
		{
			if(value is string)
			{
				handler.Set(this.key.GetValue(), (string)value);
			}
			else if(value is bool)
			{
				handler.Set(this.key.GetValue(), (bool)value);
			}
			else if(value is int)
			{
				handler.Set(this.key.GetValue(), (int)value);
			}
			else if(value is float)
			{
				handler.Set(this.key.GetValue(), (float)value);
			}
			else if(value is Vector3)
			{
				handler.Set(this.key.GetValue(), (Vector3)value);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.key.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Variable To Variable", "Stores the value of a game variable into another game variable.\n" +
		"You can use this step to transfer variables between variable origins (local, global and object).", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Variable Steps")]
	public class VariableToVariableStep : BaseEventStep
	{
		[ORKEditorHelp("Type", "Select the type of the game variable:\n" +
			"- String: A string variable.\n" +
			"- Bool: A bool variable.\n" +
			"- Float: A float variable.\n" +
			"- Vector3: A Vector3 variable.", "")]
		public GameVariableType type = GameVariableType.String;
		
		// source variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variable:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(separator=true, labelText="Source Variable Settings")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Source Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting variableObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		// variable key
		[ORKEditorInfo(separator=true, labelText="Source Variable Key")]
		public StringValue key = new StringValue();
		
		
		// target variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variable:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Variable Settings")]
		public VariableOrigin targetOrigin = VariableOrigin.Global;
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool targetUseObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting targetVariableObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string targetObjectID = "";
		
		// variable key
		[ORKEditorInfo(separator=true, labelText="Target Variable Key")]
		public StringValue targetKey = new StringValue();
		
		public VariableToVariableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			VariableHandler sourceHandler = null;
			if(VariableOrigin.Local.Equals(this.origin))
			{
				sourceHandler = baseEvent.Variables;
			}
			else if(VariableOrigin.Global.Equals(this.origin))
			{
				sourceHandler = ORK.Game.Variables;
			}
			else if(VariableOrigin.Object.Equals(this.origin))
			{
				if(this.useObject)
				{
					List<GameObject> list2 = this.variableObject.GetObject(baseEvent);
					for(int i=0; i<list2.Count; i++)
					{
						if(list2[i] != null)
						{
							ObjectVariablesComponent comp = list2[i].
								GetComponentInChildren<ObjectVariablesComponent>();
							if(comp != null)
							{
								sourceHandler = comp.GetHandler();
								break;
							}
						}
					}
				}
				else
				{
					sourceHandler = ORK.Game.Scene.GetObjectVariables(this.objectID);
				}
			}
			
			if(sourceHandler != null)
			{
				if(VariableOrigin.Local.Equals(this.targetOrigin))
				{
					this.SetValue(sourceHandler, baseEvent.Variables);
				}
				else if(VariableOrigin.Global.Equals(this.targetOrigin))
				{
					this.SetValue(sourceHandler, ORK.Game.Variables);
				}
				else if(VariableOrigin.Object.Equals(this.targetOrigin))
				{
					if(this.targetUseObject)
					{
						List<GameObject> list2 = this.targetVariableObject.GetObject(baseEvent);
						for(int i=0; i<list2.Count; i++)
						{
							if(list2[i] != null)
							{
								ObjectVariablesComponent[] comps = list2[i].
									GetComponentsInChildren<ObjectVariablesComponent>();
								if(comps != null)
								{
									for(int j=0; j<comps.Length; j++)
									{
										this.SetValue(sourceHandler, comps[j].GetHandler());
									}
								}
							}
						}
					}
					else
					{
						this.SetValue(sourceHandler, ORK.Game.Scene.GetObjectVariables(this.targetObjectID));
					}
				}
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		private void SetValue(VariableHandler sourceHandler, VariableHandler targetHandler)
		{
			if(targetHandler != null)
			{
				if(GameVariableType.String.Equals(this.type))
				{
					targetHandler.Set(this.targetKey.GetValue(), 
						sourceHandler.GetString(this.key.GetValue()));
				}
				else if(GameVariableType.Bool.Equals(this.type))
				{
					targetHandler.Set(this.targetKey.GetValue(), 
						sourceHandler.GetBool(this.key.GetValue()));
				}
				else if(GameVariableType.Float.Equals(this.type))
				{
					targetHandler.Set(this.targetKey.GetValue(), 
						sourceHandler.GetFloat(this.key.GetValue()));
				}
				else if(GameVariableType.Vector3.Equals(this.type))
				{
					targetHandler.Set(this.targetKey.GetValue(), 
						sourceHandler.GetVector3(this.key.GetValue()));
				}
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + " (" + this.key.GetInfoText() + ") to " + 
				this.targetOrigin.ToString() + " (" + this.targetKey.GetInfoText() + ")";
		}
	}
}
