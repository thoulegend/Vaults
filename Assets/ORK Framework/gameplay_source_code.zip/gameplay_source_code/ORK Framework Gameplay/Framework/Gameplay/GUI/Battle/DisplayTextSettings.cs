
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DisplayTextSettings : BaseData
	{
		// text settings
		[ORKEditorHelp("Text", "You can define the text to be displayed in every language.\n" +
			"Use % to display the actual information - e.g. for status values: 'EXP +%!' " +
			"The % will be replaced with the change value.\n" +
			"Please note that not every type of battle text offers the % option, " +
			"also damage/refresh status values don't include operators (+, -), so if " +
			"you want to have them displayed, simply add them to the text, e.g. -%.", "")]
		[ORKEditorInfo(labelText="Text Settings", 
			callbackBefore="label:textinfo", expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] text;
		
		[ORKEditorInfo("Text Format", "Define the appearance of the text, e.g. color, shadow, font size.", "", endFoldout=true)]
		public TextFormat textFormat = TextFormat.Default;
		
		[ORKEditorHelp("GUISkin", "The GUISkin used to display the damage/refresh text.\n" +
			"Leave empty to use the default GUISkin (defined in the battle texts settings).", "")]
		public GUISkin textSkin;
		
		
		// count to value
		[ORKEditorHelp("Count to Value", "Battle texts representing numbers (e.g. damage/refresh texts) " +
			"can optionally be counted to their final values over time.\n" +
			"If enabled, the value will start at a defined %-value of the final value and interpolate to its final value.", "")]
		[ORKEditorInfo(separator=true)]
		public bool countToValue = false;
	
		[ORKEditorHelp("Start from (%)", "The percent of the final value (i.e. the original value) the counting will begin.\n" +
			"E.g. 50 % from a value of 200 will result in start counting by 100.", "")]
		[ORKEditorLayout("countToValue", true)]
		public float startCountFrom = 0;
	
		[ORKEditorHelp("Interpolation", "The interpolation used for counting.", "")]
		public EaseType countInterpolate = EaseType.Linear;
	
		[ORKEditorHelp("Time (s)", "The time in seconds used for counting.\n" +
			"The battle text will display the final (original) value after this time.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float countTime = 1.0f;
		
		
		// position
		[ORKEditorHelp("Mount Text", "The text will be mounted to the combatant they belong to " +
			"(i.e. they'll follow the combatant if it moves).", "")]
		[ORKEditorInfo(separator=true, labelText="Position Settings")]
		public bool mountText = false;
		
		[ORKEditorHelp("Use Child", "The position of a child of the combatant game object is used when displaying the text.\n" +
			"Use / to separate child game objects, e.g. Path/to/Child.", "")]
		public string posChild = "";
		
		[ORKEditorHelp("Local Space", "The offsets are used in local space of the object.", "")]
		public bool localSpace = false;
	
		[ORKEditorHelp("Base Offset", "The base offset used on the character/enemy (or child) GameObjects position.", "")]
		public Vector3 baseOffset = Vector3.zero;
	
		[ORKEditorHelp("Random Offset From", "The random offset added to the base offset.\n" +
			"Will generate a random number for every axis based on the from-to values.", "")]
		public Vector3 randomOffsetFrom = Vector3.zero;
	
		[ORKEditorHelp("Random Offset To", "The random offset added to the base offset.\n" +
			"Will generate a random number for every axis based on the from-to values.", "")]
		public Vector3 randomOffsetTo = Vector3.zero;
		
		
		// move event
		[ORKEditorHelp("Move Event Asset", "Select a ORK move event asset that will move the text's game object in the scene.", "")]
		[ORKEditorInfo(separator=true)]
		public ORKMoveEvent moveEvent;
		
		[ORKEditorHelp("Destroy Time (s)", "The time in seconds the until the text's game object will be destroyed.\n" +
			"This is only used if no move event is used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float destroyTime = 3;
		
		
		// flash
		[ORKEditorHelp("Use Flash", "The combatant's game object will be flashed.", "")]
		[ORKEditorInfo("Flash Settings", "The combatant's game object can be flashed.", "")]
		public bool useFlash = false;
		
		[ORKEditorHelp("Flash Children", "All child game objects of the will be flashed.", "")]
		[ORKEditorLayout("useFlash", true)]
		public bool flashChildren = false;
		
		[ORKEditorHelp("Shared Material", "The shared material is changed instead of the renderer's material.\n" +
			"Using shared materials will change this material in the project!\n" +
			"All objects using this material will be changed.", "")]
		[ORKEditorInfo(separator=true)]
		public bool shared = false;
		
		[ORKEditorHelp("Set Property", "Define the name of the property that will be faded.\n" +
			"If disabled, the '_Color' property for fading the color is used.", "")]
		public bool setProp = false;
		
		[ORKEditorHelp("Property Name", "The name of the property that will be faded.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("setProp", true)]
		public string prop = "";
		
		[ORKEditorHelp("Is Float", "The property that will be faded is a float value instead of a color.\n" +
			"Only the alpha value of the fade settings is used.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool isFloat = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FadeColorSettings flash;
		
		public DisplayTextSettings()
		{
			
		}
		
		public DisplayTextSettings(string t)
		{
			this.text = ArrayHelper.CreateArray(ORK.Languages.Count, t);
		}
		
		public GUISkin GUISkin
		{
			get
			{
				return this.textSkin;
			}
		}
		
		
		/*
		============================================================================
		Text functions
		============================================================================
		*/
		public void ShowText(string info, GameObject gameObject)
		{
			if(gameObject != null)
			{
				this.CreateObjects(gameObject).ShowText(
					this.text[ORK.Game.Language].Replace("%", info), gameObject, this);
			}
		}
		
		public void ShowNumber(int info, GameObject gameObject)
		{
			if(gameObject != null)
			{
				this.CreateObjects(gameObject).ShowNumber(info, gameObject, this);
			}
		}
		
		private DisplayText CreateObjects(GameObject gameObject)
		{
			GameObject txtObj = new GameObject("_DisplayText");
			Transform trans = TransformHelper.GetChild(this.posChild, gameObject.transform);
			txtObj.transform.position = trans.position;
			if(this.mountText)
			{
				txtObj.transform.parent = trans;
			}
			return txtObj.AddComponent<DisplayText>();
		}
	}
}
