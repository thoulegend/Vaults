
using UnityEngine;

namespace ORKFramework
{
	public class GUIBoxSetting : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of this GUI box.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and base settings of this GUI box.", "", 
			expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("GUI Layer", "Select the GUI layer of this GUI box.\n" +
			"You can use layers to organize displaying your menus, HUDs and other on-screen messages.\n" +
			"Higher index layers will be drawn after lower index layers, i.e. they will be displayed above them.\n" +
			"E.g. GUI layer 0 will be displayed behind GUI layer 1.", "")]
		[ORKEditorInfo(ORKDataType.GUILayer)]
		public int layerID = 0;
		
		[ORKEditorHelp("Height Adjustment", "Select how the GUI box height adjusts to the content displayed:\n" +
			"- None: The height defined content box height is used. " +
			"Content exceeding the GUI box will be cut off and displayed after preccing the accept key (or 'Ok' button).\n" +
			"- Auto: The height is automatically adjusted to the content.\n" +
			"- Scroll: A vertical scrollbar is used if the content exceeds the GUI box.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public BoxHeightAdjustment heightAdjustment = BoxHeightAdjustment.None;
		
		[ORKEditorHelp("Scroll Padding", "The padding between the text and the vertical scrollbar.", "")]
		[ORKEditorLayout("heightAdjustment", BoxHeightAdjustment.Scroll, endCheckGroup=true)]
		public float scrollPadding = 5;
		
		[ORKEditorHelp("Is One Line", "Only one line of text will be displayed.\n" +
			"This is only used in dialogues without choices.", "")]
		public bool oneline = false;
		
		// drag window
		[ORKEditorHelp("Dragable", "The GUI box can be dragged.", "")]
		[ORKEditorInfo(separator=true, labelText="Drag Settings")]
		public bool dragable = false;
		
		[ORKEditorHelp("Drag Bounds", "Set the position and size of the area that is used to drag the box.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of the box.", "")]
		[ORKEditorLayout("dragable", true, endCheckGroup=true)]
		public Rect dragBounds = new Rect(0, 0, 1920, 20);
		
		// inactive colors
		[ORKEditorHelp("Own Inactive Colors", "Overrides the default inactive color settings with the settings defined here.\n" +
			"If disabled, the default inactive color settings will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Inactive Colors")]
		public bool ownInactive = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownInactive", true, endCheckGroup=true, autoInit=true)]
		public InactiveColor inactive;
		
		
		// own skins
		[ORKEditorHelp("Own Skins", "This GUI box overrides the default GUISkins defined in the menu settings.\n" +
			"If disabled, the default skins will be used.", "")]
		[ORKEditorInfo("GUI Skins", "A GUI box can override the default skin settings.", "")]
		public bool ownSkins = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("ownSkins", true, endCheckGroup=true, autoInit=true)]
		public GUIBoxSkins skins;
		
		
		// own audio
		[ORKEditorHelp("Own Audio", "This GUI box overrides the default audio clips defined in the menu settings.\n" +
			"If disabled, the default clips will be used.", "")]
		[ORKEditorInfo("Audio Settings", "A GUI box can override the default audio settings.", "")]
		public bool ownAudio = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("ownAudio", true, endCheckGroup=true, autoInit=true)]
		public MenuAudioClips audio;
		
		
		// own buttons
		[ORKEditorHelp("Own Buttons", "This GUI box overrides the default 'Ok' and 'Cancel' buttons with the settings defined here.\n" +
			"If disabled, the default buttons will be used.", "")]
		[ORKEditorInfo("Ok/Cancel Buttons", "A GUI box can override the default 'Ok' and 'Cancel' buttons.", "")]
		public bool ownButtons = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("ownButtons", true, endCheckGroup=true, autoInit=true)]
		public GUIBoxButtons buttons;
		
		
		// own portrait position
		[ORKEditorHelp("Own Position", "This GUI box overrides the default portrait position settings.\n" +
			"If disabled, the default portrait position will be used.", "")]
		[ORKEditorInfo("Portrait Position", "A GUI box can override the default portrait position.\n" +
			"This setting can be overriden by combatant portraits and the portrait settings in dialogue event steps.", "")]
		public bool ownPortraitPosition = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("ownPortraitPosition", true, endCheckGroup=true, autoInit=true)]
		public PortraitPosition portraitPosition;
		
		
		// own choice icon
		[ORKEditorHelp("Own Choice Icon", "This GUI box overrides the default choice icon settings.\n" +
			"If disabled, the default choice icon settings will be used.", "")]
		[ORKEditorInfo("Choice Icon", "A GUI box can override the default choice icon settings.", "")]
		public bool ownChoiceIcon = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("ownChoiceIcon", true, endCheckGroup=true, autoInit=true)]
		public ChoiceIconSettings choiceIcon;
		
		
		// content box
		[ORKEditorHelp("At Cursor", "The box will be positioned using the cursor position, " +
			"i.e. X=0, Y=0 is at the position of the cursor.\n" +
			"If disabled, the box will be positioned using the upper left screen center.", "")]
		[ORKEditorInfo("Content Box Settings", "Position and size of the GUI box and padding to the content area.", "")]
		public bool atCursor = false;
		
		[ORKEditorHelp("Follow Cursor", "The box will follow the cursor.\n" +
			"If disabled, the box will be displayed at the position the cursor had when opened.", "")]
		[ORKEditorLayout("atCursor", true)]
		public bool followCursor = false;
		
		[ORKEditorHelp("Follow At Close", "Follow the cursor while the GUI box closes (e.g. fades out).\n" +
			"If disabled, the GUI box will stop following the cursor when the box closes.", "")]
		[ORKEditorLayout("followCursor", true, endCheckGroup=true, endGroups=2)]
		public bool followAtClose = false;
		
		[ORKEditorHelp("Bounds", "The bounds of the GUI box.\n" +
			"Position: X, Y\n" +
			"Size: Width, Height\n" +
			"When using the 'At Cursor' setting, the position X=0, Y=0 is at the current position of the cursor.", "")]
		public Rect boxBounds = new Rect(100, 100, 300, 200);
		
		[ORKEditorHelp("Anchor", "Select the anchor of the GUI box.", "")]
		public TextAnchor boxAnchor = TextAnchor.UpperLeft;
		
		[ORKEditorHelp("Padding", "The padding at the borders of the GUI box - left (x), top (y), right (z) and bottom (w).", "")]
		public Vector4 boxPadding = new Vector4(10, 10, 10, 10);
		
		[ORKEditorHelp("Line Spacing", "The space between text lines.", "")]
		public float lineSpacing = 10;
		
		[ORKEditorHelp("Show Box", "A box is shown around the GUI box.\n" +
			"The style of the box is determined by the selected GUISkin.\n" +
			"If the GUI box is a drag window, the window style will be used, otherwise the box style.", "")]
		public bool showBox = true;
		
		// default text color
		[ORKEditorInfo("Text Format", "Define the appearance of the text, e.g. color, shadow, font size.", "", endFoldout=true)]
		public TextFormat textFormat = TextFormat.Default;
		
		[ORKEditorHelp("Text Alignment", "Select how the text will be aligned horizontally.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public TextAlignment alignment = TextAlignment.Left;
		
		[ORKEditorHelp("Line Alignment", "Select how text lines will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment vAlignment = VerticalTextAlignment.Bottom;
		
		// text columns
		[ORKEditorHelp("Text Columns", "Defines the number of columns the text will be displayed in.", "")]
		[ORKEditorInfo(separator=true, labelText="Column Settings")]
		[ORKEditorLimit(1, false)]
		public int textColumns = 1;
		
		[ORKEditorHelp("Column Spacing", "The space between two text columns.", "")]
		public float textColumnSpacing = 10;
		
		// type text settings
		[ORKEditorHelp("Use Text Typing", "The content text will be displayed letter for letter.\n" +
			"If disabled, the whole text will be displayed immediately.", "")]
		[ORKEditorInfo(separator=true, labelText="Text Typing Settings")]
		public bool useTextTyping = false;
		
		[ORKEditorHelp("Index Increase", "The index of the currently displayed text increases by this number every X seconds.", "")]
		[ORKEditorLayout("useTextTyping", true)]
		[ORKEditorLimit(1, false)]
		public int typingIncrease = 1;
		
		[ORKEditorHelp("Interval (s)", "The interval in seconds between index increases.\n" +
			"Set to 0 to increase every Update call.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float typingInterval = 0;
		
		[ORKEditorHelp("Typing Clip", "The selected audio clip will be played while typing.", "")]
		[ORKEditorLayout(setDefault=true, defaultValue=null)]
		public AudioClip typingClip = null;
		
		[ORKEditorHelp("Audio Interval (s)", "The interval in seconds between playing the audio clip.", "")]
		[ORKEditorLayout("typingClip", null, elseCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float typingAudioInterval = 0.5f;
		
		[ORKEditorHelp("Typing Volume", "The volume (0-1) used to play the typing clip.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float typingVolume = 1;
		
		// input field settings
		[ORKEditorHelp("Input Field Spacing", "The space between an input field's title and the actual input field.", "")]
		[ORKEditorInfo(separator=true, labelText="Input Field Settings")]
		public float inputFieldSpacing = 10;
		
		[ORKEditorHelp("Align Input Fields", "All input fields in a dialogue will be aligned to the same width " +
			"(i.e. the width of the shortest field).", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool alignInputFields = true;
		
		
		// name box
		[ORKEditorHelp("Bounds", "The bounds of the name box.\n" +
			"Position: x, y\n" +
			"Size: width, height", "")]
		[ORKEditorInfo("Name Box Settings", "The name box is used to display a title or name (e.g. speaking actor in dialogues).", "")]
		public Rect nameBounds = new Rect(0, 0, 150, 50);
		
		[ORKEditorHelp("Anchor", "Select the anchor of the name box.", "")]
		public TextAnchor nameAnchor = TextAnchor.LowerLeft;
		
		[ORKEditorHelp("Relative Bounds", "The name box bounds will be relative to the content box, " +
			"i.e. X=0, Y=0 are at the upper left corner of the content box.\n" +
			"If disabled, the name bounds are absolute.", "")]
		public bool nameRelative = true;
		
		[ORKEditorHelp("Relative To", "Select the the corner of the GUI box the name box position will be relative to.", "")]
		[ORKEditorLayout("nameRelative", true, endCheckGroup=true)]
		public TextAnchor nameRelativeTo = TextAnchor.UpperLeft;
		
		[ORKEditorHelp("Padding", "The padding at the borders of the name box - left (x), top (y), right (z) and bottom (w).", "")]
		public Vector4 namePadding = new Vector4(5, 1, 5, 1);
		
		[ORKEditorHelp("Line Spacing", "The space between text lines.", "")]
		public float nameLineSpacing = 10;
		
		[ORKEditorHelp("Show Box", "A box is shown around the name, using the name bounds.\n" +
			"The style of the box is determined by the selected GUISkin.", "")]
		[ORKEditorInfo(separator=true)]
		public bool showNameBox = true;
		
		[ORKEditorHelp("Adjust Width", "Adjust the width of the name box to the width of the name.", "")]
		public bool nameAdjWidth = false;
		
		[ORKEditorHelp("Adjust Height", "Adjust the height of the name box to the height of the name.", "")]
		public bool nameAdjHeight = false;
		
		[ORKEditorInfo("Text Format", "Define the appearance of the text, e.g. color, shadow, font size.", "", endFoldout=true)]
		public TextFormat nameTextFormat = TextFormat.Default;
		
		[ORKEditorHelp("Text Alignment", "Select how the name will be aligned horizontally within it's bounds.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public TextAlignment alignmentName = TextAlignment.Left;
		
		[ORKEditorHelp("Line Alignment", "Select how text lines of the name will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(endFoldout=true, isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment vAlignmentName = VerticalTextAlignment.Bottom;
		
		
		// choice settings
		[ORKEditorInfo("Choice Settings", "This settings are used for choice dialogues and selection menus.", "")]
		public ButtonSettings buttonSettings = new ButtonSettings();
		
		[ORKEditorHelp("Inactive Alpha", "The alpha value (0-1) to use when displaying an " +
			"inactive choice (e.g. an ability that can't be used).", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float choiceInactiveAlpha = 0.5f;
		
		[ORKEditorHelp("Spacing", "The space between two choice buttons.\n" +
			"X = horizontal space (for columns)\n" +
			"Y = vertical space", "")]
		public Vector2 choiceSpacing = new Vector2(10, 10);
		
		// title settings
		[ORKEditorHelp("Title Padding", "The padding between the title and button (content) of a choice.\n" +
			"This is mainly used for equipment menus, displaying the equipment part as title and equipped weapon/armor as button.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public float choiceTitlePadding = 10;
		
		[ORKEditorHelp("Set Title Width", "Set the width of the choice button's title.\n" +
			"If disabled, the width of the longest title will be used.", "")]
		public bool choiceSetTitleWidth = false;
		
		[ORKEditorHelp("Title Width", "The width of the title.\n" +
			"The padding is added to the width.", "")]
		[ORKEditorLayout("choiceSetTitleWidth", true)]
		[ORKEditorLimit(0.0f, false)]
		public float choiceTitleWidth = 200;
		
		[ORKEditorHelp("Title Text Alignment", "Select how the title will be aligned horizontally within it's bounds.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue=TextAlignment.Left)]
		public TextAlignment alignmentTitle = TextAlignment.Left;
		
		[ORKEditorHelp("Title Line Alignment", "Select how text lines of the title will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment vAlignmentTitle = VerticalTextAlignment.Bottom;
		
		// choice selection
		[ORKEditorHelp("Loop Selection", "The choice selection will loop, e.g. " +
			"if you press up at the first choice, the last choice will be selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Choice Selection")]
		public bool loop = false;
		
		[ORKEditorHelp("Select First", "The choice has to be selected before it can be accepted by a mouse click.\n" +
			"Use this setting if you e.g. want to show the information of a shop item by clicking on it without initiating the buy right away.", "")]
		public bool selectFirst = false;
		
		[ORKEditorHelp("Select Unfocused", "The choices can also be selected when the GUI box is currently not focused.", "")]
		public bool unfocusedChoice = false;
		
		[ORKEditorHelp("Selected Choice Offset", "Offset added to the selected choice's X-position.", "")]
		public float selectedChoiceOffset = 0;
		
		// choice width
		[ORKEditorHelp("Define Width", "The width and x offset of a choice can be set.\n" +
			"If disabled, the width will be determined by the dialogue box.", "")]
		[ORKEditorInfo(separator=true, labelText="Choice Width/Height")]
		public bool choiceDefineWidth = false;
		
		[ORKEditorHelp("Choice Width", "The width of choice options.", "")]
		[ORKEditorLayout("choiceDefineWidth", true)]
		[ORKEditorLimit(1.0f, false)]
		public float choiceWidth = 300;
		
		[ORKEditorHelp("Choice Offset X", "The horizontal offset of a choice to the previous choice.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float choiceOffsetX = 0;
		
		[ORKEditorHelp("Adjust Height", "The height of all choice buttons will be adjusted to the biggest button.\n" +
			"If disabled, all choice buttons will keep their calculated height.", "")]
		public bool cAdjustHeight = false;
		
		// choice columns
		[ORKEditorHelp("Choice Columns", "Defines the number of columns the choices will be displayed in.", "")]
		[ORKEditorInfo(separator=true, labelText="Column Settings")]
		[ORKEditorLimit(1, false)]
		public int choiceColumns = 1;
		
		[ORKEditorHelp("Column Fill", "Defines how the choices will be filled into the columns.\n" +
			"Either 'Vertical' or 'Horizontal'.", "")]
		[ORKEditorInfo(isEnumToolbar=true, endFoldout=true)]
		[ORKEditorLayout("choiceColumns", 1, elseCheckGroup=true, endCheckGroup=true, 
			setDefault=true, defaultValue=ColumnFill.Vertical)]
		public ColumnFill columnFill = ColumnFill.Vertical;
		
		
		// tabs settings
		[ORKEditorHelp("Tabs Position", "Select where the tabs will be displayed:\n" +
			"- Top: At the top of the GUI box.\n" +
			"- Bottom: At the bottom of the GUI box.\n" +
			"In any case, the tabs will be displayed within the content padding.", "")]
		[ORKEditorInfo("Tabs Settings", "A GUI box can display a tab bar " +
			"(a list of buttons) to switch between different content.", "", 
			isEnumToolbar=true, toolbarWidth=75)]
		public TabsPosition tabsPosition = TabsPosition.Top;
		
		[ORKEditorHelp("Tab Padding", "The padding between the GUI box and the tab buttons - left (x), top (y), right (z) and bottom (w).", "")]
		public Vector4 tabsPadding = new Vector4(10, 10, 10, 10);
		
		[ORKEditorHelp("Tab Spacing", "The horizontal space between two tab buttons.", "")]
		public float tabsSpacing = 0;
		
		[ORKEditorInfo("Button Settings", "Define the settings for the tab buttons.", "", 
			endFoldout=true, separatorForce=true)]
		public ButtonSettings tabsButtonSettings = new ButtonSettings();
		
		[ORKEditorHelp("Inactive Alpha", "The alpha value (0-1) to use when displaying an " +
			"inactive tab.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float tabsInactiveAlpha = 0.5f;
		
		// tab width
		[ORKEditorHelp("Set Width", "Set the width of the tabs.", "")]
		[ORKEditorInfo(separator=true, labelText="Tab Width Settings")]
		public bool tabsSetWidth = false;
		
		[ORKEditorHelp("Tab Width", "The width of the tab buttons.", "")]
		[ORKEditorLayout("tabsSetWidth", true)]
		public float tabsWidth = 200;
		
		[ORKEditorHelp("Adjust Width", "The width of all tab buttons will be adjusted to the biggest button.\n" +
			"If disabled, the tab buttons will have different widths, depending on their content.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public bool tabsAdjustWidth = true;
		
		// tab arrow buttons
		[ORKEditorHelp("Button Position", "Select the position of the arrow buttons:\n" +
			"- Left: At the left side of the tabs.\n" +
			"- Left Right: The left arrow button will be at the left side, the right arrow button at the right side.\n" +
			"- Right: At the right side of the tabs.", "")]
		[ORKEditorInfo("Arrow Buttons", "A left and a right arrow button are displayed if the tabs exceed the width of the GUI box.", "", 
			separatorForce=true)]
		public ArrowButtonPosition tabsArrowPosition = ArrowButtonPosition.Left;
		
		[ORKEditorInfo("Left Arrow Button", "Define the button used for the left arrow button.", "", endFoldout=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] tabsLeftArrow = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"<"});
		
		[ORKEditorInfo("Right Arrow Button", "Define the button used for the right arrow button.", "", endFoldout=true, endFolds=3)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] tabsRightArrow = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {">"});
		
		
		// fade in
		[ORKEditorHelp("Fade In", "This GUI Box will fade in.", "")]
		[ORKEditorInfo("Fade In Settings", "A GUI box can fade when it is opened.", "")]
		public bool useFadeIn = false;
		
		[ORKEditorLayout("useFadeIn", true, autoInit=true, 
			constTypes=new System.Type[] {typeof(float), typeof(float), typeof(float)}, 
			constValues=new System.Object[] {0.3f, 0.0f, 1.0f})]
		public FadeColorSettings fadeIn;
		
		[ORKEditorHelp("Delay (s)", "The time in seconds before starting to fade in.", "")]
		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float fadeInDelay = 0;
		
		
		// fade out
		[ORKEditorHelp("Fade Out", "This GUI Box will fade out.", "")]
		[ORKEditorInfo("Fade Out Settings", "A GUI box can fade when it is closed.", "")]
		public bool useFadeOut = false;
		
		[ORKEditorLayout("useFadeOut", true, autoInit=true, 
			constTypes=new System.Type[] {typeof(float), typeof(float), typeof(float)}, 
			constValues=new System.Object[] {0.3f, 1.0f, 0.0f})]
		public FadeColorSettings fadeOut;
		
		[ORKEditorHelp("Delay (s)", "The time in seconds before starting to fade out.", "")]
		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float fadeOutDelay = 0;
		
		
		// move in
		[ORKEditorHelp("Move In", "The GUI box will move in from a start position when becoming visible.", "")]
		[ORKEditorInfo("Move In Settings", "The GUI box can move to it's defined position " +
			"from a start position when it is opened.", "")]
		public bool moveIn = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds used to move in.", "")]
		[ORKEditorLayout("moveIn", true)]
		[ORKEditorLimit(0.1f, false)]
		public float moveInTime = 0.3f;
		
		[ORKEditorHelp("Start Position", "The position from which the GUI box will start moving in.", "")]
		public Vector2 moveInStart = Vector2.zero;
		
		[ORKEditorHelp("Interpolation", "The interpolation used to move in.", "")]
		public EaseType moveInInterpolation = EaseType.Linear;
		
		// scale
		[ORKEditorHelp("Scale In", "Scale the GUI box when moving in.", "")]
		[ORKEditorInfo(separator=true, labelText="Scale Settings")]
		public bool moveInUseScale = false;
		
		[ORKEditorHelp("Start Scale", "Define the scale the GUI box will have when starting to move in.\n" +
			"The scale will be X=1, Y=1 at the end of the move.\n" +
			"Don't use values below 0!", "")]
		[ORKEditorLayout("moveInUseScale", true)]
		public Vector2 moveInScale = new Vector2(0.5f, 0.5f);
		
		[ORKEditorHelp("Scale Anchor", "Select the anchor for the scale movement.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public TextAnchor moveInScaleAnchor = TextAnchor.MiddleCenter;
		
		// delay
		[ORKEditorHelp("Delay (s)", "The time in seconds before starting to move in.", "")]
		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float moveInDelay = 0;
		
		
		// move out
		[ORKEditorHelp("Move Out", "The GUI box will move out to an end position when becoming invisible.", "")]
		[ORKEditorInfo("Move Out Settings", "The GUI box can move from it's defined position " +
			"to an end position when it is closed.", "")]
		public bool moveOut = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds used to move out.", "")]
		[ORKEditorLayout("moveOut", true)]
		[ORKEditorLimit(0.1f, false)]
		public float moveOutTime = 0.3f;
		
		[ORKEditorHelp("End Position", "The position to which the GUI box will move out to.", "")]
		public Vector2 moveOutEnd = Vector2.zero;
		
		[ORKEditorHelp("Interpolation", "The interpolation used to move out.", "")]
		public EaseType moveOutInterpolation = EaseType.Linear;
		
		// scale
		[ORKEditorHelp("Scale In", "Scale the GUI box when moving out.", "")]
		[ORKEditorInfo(separator=true, labelText="Scale Settings")]
		public bool moveOutUseScale = false;
		
		[ORKEditorHelp("End Scale", "Define the scale the GUI box will have at the end of the move.\n" +
			"The scale will be X=1, Y=1 at the start of the move.\n" +
			"Don't use values below 0!", "")]
		[ORKEditorLayout("moveOutUseScale", true)]
		public Vector2 moveOutScale = new Vector2(0.5f, 0.5f);
		
		[ORKEditorHelp("Scale Anchor", "Select the anchor for the scale movement.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public TextAnchor moveOutScaleAnchor = TextAnchor.MiddleCenter;
		
		// delay
		[ORKEditorHelp("Delay (s)", "The time in seconds before starting to move out.", "")]
		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float moveOutDelay = 0;
		
		public GUIBoxSetting()
		{
			
		}
		
		public GUIBoxSetting(string n)
		{
			this.name = n;
		}
	}
}
