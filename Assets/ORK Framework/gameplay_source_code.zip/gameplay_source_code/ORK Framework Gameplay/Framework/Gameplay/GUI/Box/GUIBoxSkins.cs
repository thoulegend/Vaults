
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GUIBoxSkins : BaseData
	{
		// legacy
		// skins
		[ORKEditorHelp("Base Skin", "The GUISkin used to display a GUI box.\n" +
			"Uses the box, label, button and scrollbar style of the skin.", "")]
		[ORKEditorLayout("gui:legacy")]
		public GUISkin skin;
		
		[ORKEditorHelp("Selected Choice", "The GUISkin used to display a selected choice.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin selectSkin;
		
		[ORKEditorHelp("Ok/Cancel Button", "The GUISkin used to display the 'Ok' and 'Cancel' buttons.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin okSkin;
		
		[ORKEditorHelp("Name Box", "The GUISkin used to display the name box.\n" +
			"Uses the label and box style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin nameSkin;
		
		[ORKEditorHelp("Tabs Choice", "The GUISkin used to display tab buttons.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin tabsSkin;
		
		[ORKEditorHelp("Tabs Selected Choice", "The GUISkin used to display selected tab buttons.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the selected skin or the base skin is used.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public GUISkin tabsSelectSkin;
		
		
		// new UI
		// TODO: name box, ok/cancel buttons > optionally use prefab, specify path to child object of content box otherwise
		// TODO: child object dropdown?
		// content box
		[ORKEditorHelp("Content Box Prefab", "Select the prefab that will be used to display the box of the GUI box.", "")]
		[ORKEditorInfo(labelText="Content Box Settings")]
		[ORKEditorLayout("gui:newui")]
		public GameObject contentBoxPrefab;
		
		[ORKEditorHelp("Content Box Child", "The defined child object of the content box that will be used to place content on.\n" +
			"If the child can't be found, the game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string contentBoxChild = "";
		
		[ORKEditorHelp("Content Mask", "Select the image that will be used as content mask.\n" +
			"If no image is selected, the whole content bounds are used as mask.", "")]
		public Texture2D contentMask;
		
		// name box
		[ORKEditorHelp("Name Box Prefab", "Select the prefab that will be used to display the box of the GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Name Box Settings")]
		public GameObject nameBoxPrefab;
		
		[ORKEditorHelp("Name Box Child", "The defined child object of the name box that will be used to place content on.\n" +
			"If the child can't be found, the game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string nameBoxChild = "";
		
		// buttons
		[ORKEditorHelp("Choice Prefab", "Select the prefab that will be used to display the choice buttons of the GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Button Settings")]
		public GameObject buttonPrefab;
		
		[ORKEditorHelp("Ok Button Prefab", "Select the prefab that will be used to display the ok button of the GUI box.", "")]
		public GameObject okPrefab;
		
		[ORKEditorHelp("Cancel Button Prefab", "Select the prefab that will be used to display the cancel button of the GUI box.", "")]
		public GameObject cancelPrefab;
		
		// tab
		[ORKEditorHelp("Tab Prefab", "Select the prefab that will be used to display the tab buttons of the GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Tab Settings")]
		public GameObject tabPrefab;
		
		[ORKEditorHelp("Tab Mask", "Select the image that will be used as tab mask.\n" +
			"If no image is selected, the whole tab bounds are used as mask.", "")]
		public Texture2D tabMask;
		
		// scrollbar
		[ORKEditorHelp("Scrollbar Prefab", "Select the prefab that will be used to display the vertical scrollbar of the GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Scrollbar Settings")]
		public GameObject scrollbarPrefab;
		
		// value inputs
		[ORKEditorHelp("Text Input Prefab", "Select the prefab that will be used to display a text field.", "")]
		[ORKEditorInfo(separator=true, labelText="Value Input Settings")]
		public GameObject textInputPrefab;
		
		[ORKEditorHelp("Toggle Input Prefab", "Select the prefab that will be used to display a toggle field.", "")]
		public GameObject toggleInputPrefab;
		
		[ORKEditorHelp("Slider Input Prefab", "Select the prefab that will be used to display a slider field (int and float values).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public GameObject sliderInputPrefab;
		
		public GUIBoxSkins()
		{
			
		}
	}
}
