
using System;

namespace ORKFramework
{
	public interface ITabChoice
	{
		void TabChanged(int index, GUIBox box);
	}
}

