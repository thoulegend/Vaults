
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ItemCollectionChoice : BaseData, IChoice
	{
		// animation
		[ORKEditorHelp("Use Animation", "The player will play an animation when collecting an item.", "")]
		public bool useAnimation = false;
		
		[ORKEditorHelp("Animation Type", "Select the animation type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		[ORKEditorLayout("useAnimation", true, endCheckGroup=true)]
		public int animationTypeID = 0;
		
		// audio
		[ORKEditorHelp("Play Sound", "A sound will be played when collecting an item.", "")]
		[ORKEditorInfo(separator=true)]
		public bool playSound = false;
		
		[ORKEditorHelp("Use Sound Type", "The player combatant's defined sound of a selected sound type will be used.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("playSound", true)]
		public bool useSoundType = false;
		
		[ORKEditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		[ORKEditorLayout("useSoundType", true)]
		public int soundTypeID = 0;
		
		[ORKEditorHelp("Audio Clip", "The selected audio clip will be played.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, setDefault=true, defaultValue=null)]
		public AudioClip audioClip;
		
		[ORKEditorHelp("Volume", "The volume used to play the sound.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float volume = 1;
		
		
		// dialogue
		[ORKEditorHelp("Show Dialogue", "A dialogue is shown to inform the player about the found item.\n" +
			"If disabled, the item is collected immediately.", "")]
		[ORKEditorInfo(separator=true)]
		public bool show = true;
		
		[ORKEditorHelp("GUI Box", "The GUI box used to display the item collection dialogue.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox, separator=true)]
		[ORKEditorLayout("show", true)]
		public int guiBoxID = 0;
		
		
		// auto close
		[ORKEditorHelp("Auto Close", "The item collection dialogue is closed automatically, " +
			"the item will be added to the inventory at the start of the dialogue.", "")]
		[ORKEditorInfo(separator=true, labelText="Auto Close Settings")]
		public bool autoClose = false;
		
		[ORKEditorHelp("Block Accept Button", "The accept button is blocked - " +
			"the dialogue will only close after it's time ran up.", "")]
		[ORKEditorLayout("autoClose", true)]
		public bool closeBlockAccept = false;
		
		[ORKEditorHelp("Close After (s)", "The time in seconds until the dialogue closes automatially.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float closeAfter = 3;
		
		
		// item title
		[ORKEditorHelp("Show Title (Item)", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useItemTitle = false;
		
		[ORKEditorHelp("Title (Item)", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = item name, %d = item description, %i = item icon, % = quantity"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useItemTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] itemTitle;
		
		
		// item message
		[ORKEditorHelp("Item Text", "The item text will be displayed when you collect an item or equipment " +
			"using an item collector.\n" +
			"Use %n to display the name of the item, % for quantity of the item.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Item Text", label=new string[] {
			"%n = item name, %d = item description, %i = item icon, % = quantity"
		})]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] message = ArrayHelper.CreateArray(ORK.Languages.Count, "You found %n (%).");
		
		
		// money title
		[ORKEditorHelp("Show Title (Money)", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useMoneyTitle = false;
		
		[ORKEditorHelp("Title (Money)", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = currency name, %d = currency description, %i = currency icon, % = money amount"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useMoneyTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] moneyTitle;
		
		
		// money message
		[ORKEditorHelp("Money Text", "The money text will be displayed when you collect money using an item collector.\n" +
			"Use % to display the amount of money.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Money Text", label=new string[] {
			"%n = currency name, %d = currency description, %i = currency icon, % = money amount"
		})]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] messageMoney = ArrayHelper.CreateArray(ORK.Languages.Count, "You found % %n.");
		
		
		// choice
		[ORKEditorHelp("Allow Choice", "The player can decide if the item will be collected or not " +
			"(i.e. the 'Cancel' button will be available, or a choice will be displayed).\n" +
			"If disabled, the player must take the item.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("autoClose", false, setDefault=true, defaultValue=false)]
		public bool showChoice = false;
		
		// question buttons
		[ORKEditorHelp("Use Choice", "Use a choice to accept or cancel the question, " +
			"the 'Yes' and 'No' options of the choice will be defined here.\n" +
			"If disabled, the 'Ok' and 'Cancel' buttons of the GUI box will be used.", "")]
		[ORKEditorLayout("showChoice", true, setDefault=true, defaultValue=false)]
		public bool useChoice = false;
		
		// yes button
		[ORKEditorInfo(separator=true, labelText="Yes Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout("useChoice", true, autoInit=true, autoLangSize=true)]
		public LanguageContent[] yesButton;
		
		// no button
		[ORKEditorInfo(separator=true, labelText="No Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=4, autoInit=true, autoLangSize=true)]
		public LanguageContent[] noButton;
		
		
		// ingame
		private GUIBox box;
		
		private string tmpTitle = "";
		
		private int current = -1;
		
		private ItemCollector itemCollector;
		
		private IShortcut item;
		
		private ChoiceContent[] choice;
		
		public ItemCollectionChoice()
		{
			
		}
		
		public string Message
		{
			get
			{
				if(this.item is MoneyShortcut)
				{
					this.tmpTitle = this.useMoneyTitle ? 
						this.moneyTitle[ORK.Game.Language].
							Replace("%n", this.item.GetName()).
							Replace("%d", this.item.GetDescription()).
							Replace("%i", this.item.GetIconTextCode()).
							Replace("%", this.item.GetInfo(null)) : "";
					return this.messageMoney[ORK.Game.Language].
							Replace("%n", this.item.GetName()).
							Replace("%d", this.item.GetDescription()).
							Replace("%i", this.item.GetIconTextCode()).
							Replace("%", this.item.GetInfo(null));
				}
				else if(this.item is ItemShortcut || item is EquipShortcut)
				{
					this.tmpTitle = this.useItemTitle ? 
						this.itemTitle[ORK.Game.Language].
							Replace("%n", this.item.GetName()).
							Replace("%d", this.item.GetDescription()).
							Replace("%i", this.item.GetIconTextCode()).
							Replace("%", this.item.GetInfo(null)) : "";
					return this.message[ORK.Game.Language].
							Replace("%n", this.item.GetName()).
							Replace("%d", this.item.GetDescription()).
							Replace("%i", this.item.GetIconTextCode()).
							Replace("%", this.item.GetInfo(null));
				}
				this.tmpTitle = "";
				return "";
			}
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return !this.autoClose || !this.closeBlockAccept;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return this.showChoice;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(ItemCollector collector, IShortcut item)
		{
			if(ORK.Game.ActiveGroup.Leader.Inventory.CanCollect(item))
			{
				if(this.show)
				{
					this.itemCollector = collector;
					this.item = item;
					this.Show();
				}
				else
				{
					collector.CollectionFinished(true);
				}
			}
			else
			{
				collector.CollectionFinished(false);
			}
		}
		
		public void Show()
		{
			this.current = -1;
			
			if(this.showChoice && this.useChoice)
			{
				this.choice = new ChoiceContent[2];
				this.choice[0] = this.yesButton[ORK.Game.Language].GetChoiceContent();
				this.choice[1] = this.noButton[ORK.Game.Language].GetChoiceContent();
			}
			else
			{
				this.choice = null;
			}
			
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			this.box.Content = new DialogueContent(this.Message, this.tmpTitle, this.choice, this);
			this.box.InitIn();
			if(this.autoClose)
			{
				this.box.CloseAfter(this.closeAfter, !this.closeBlockAccept);
				this.itemCollector.CollectionFinished(true);
			}
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			if(!this.autoClose)
			{
				this.itemCollector.CollectionFinished(!this.showChoice || this.current == 0);
			}
			this.itemCollector = null;
			this.box = null;
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			this.current = index;
			this.box.InitOut();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void Canceled(GUIBox origin)
		{
			if(this.showChoice)
			{
				origin.Audio.PlayCancel();
				this.ChoiceSelected(1, origin);
			}
		}
	}
}
