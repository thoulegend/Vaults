
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public delegate void QuestionClosed(bool accepted);
	
	public class QuestionChoice : BaseData, IChoice
	{
		[ORKEditorHelp("GUI Box", "The GUI box used to display the question.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"% = information"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// message
		[ORKEditorHelp("Question Text", "The text displayed in the question.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Question Text", 
			label=new string[] {
				"% = information"
		})]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] message = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// question buttons
		[ORKEditorHelp("Use Choice", "Use a choice to accept or cancel the question, " +
			"the 'Yes' and 'No' options of the choice will be defined here.\n" +
			"If disabled, the 'Ok' and 'Cancel' buttons of the GUI box will be used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useChoice = false;
		
		// yes button
		[ORKEditorInfo(separator=true, labelText="Yes Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout("useChoice", true, autoInit=true, autoLangSize=true, 
			constTypes=new System.Type[] {typeof(string)}, 
			constValues=new System.Object[] {"Yes"})]
		public LanguageContent[] yesButton;
		
		// no button
		[ORKEditorInfo(separator=true, labelText="No Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true, autoLangSize=true, 
			constTypes=new System.Type[] {typeof(string)}, 
			constValues=new System.Object[] {"No"})]
		public LanguageContent[] noButton;
		
		
		// ingame
		private GUIBox box;
		
		private int current = -1;
		
		private ChoiceContent[] choice;
		
		
		// content
		private string info;
		
		private QuestionClosed parent;
		
		
		// text
		private string tmpTitle = "";
		
		private string tmpText = "";
		
		public QuestionChoice()
		{
			
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return true;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return true;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		private void CreateTexts()
		{
			// title
			if(this.useTitle)
			{
				this.tmpTitle = this.title[ORK.Game.Language].Replace("%", this.info);
			}
			else
			{
				this.tmpTitle = "";
			}
			// message
			this.tmpText = this.message[ORK.Game.Language].Replace("%", this.info);
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(string info, QuestionClosed parent)
		{
			this.info = info;
			this.parent = parent;
			this.Show();
		}
		
		public void Show()
		{
			if(this.useChoice)
			{
				this.choice = new ChoiceContent[2];
				this.choice[0] = this.yesButton[ORK.Game.Language].GetChoiceContent();
				this.choice[1] = this.noButton[ORK.Game.Language].GetChoiceContent();
			}
			else
			{
				this.choice = null;
			}
			
			this.CreateTexts();
			
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			this.box.inPause = true;
			this.box.Content = new DialogueContent(this.tmpText, this.tmpTitle, this.choice, this);
			this.box.InitIn();
			ORK.GUI.FocusBlocked = true;
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			ORK.GUI.FocusBlocked = false;
			this.box = null;
			this.parent(this.current == 0);
			this.parent = null;
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			this.current = index;
			this.box.InitOut();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.current = -1;
			this.box.InitOut();
		}
	}
}
