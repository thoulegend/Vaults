
using UnityEngine;
using System.Collections.Generic;
using System.Text;

namespace ORKFramework
{
	public class TargetNamesDisplay : BaseData
	{
		[ORKEditorHelp("Only First Target", "Display only the first target's name.\n" +
			"If disabled, all target names will be displayed.", "")]
		public bool onlyFirst = false;
		
		[ORKEditorHelp("First Target Text", "The text used to display only the first target.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {"%n = first target name"})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("onlyFirst", true)]
		public string[] firstTargetText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n and friends");
		
		
		// all names
		[ORKEditorHelp("Line Separation", "Each target name will be in it's own line.\n" +
			"If disabled, a separation text will be used.", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool lineSeparation = false;
		
		[ORKEditorHelp("Separation", "The text used to separate target names.", "")]
		[ORKEditorLayout("lineSeparation", false, endCheckGroup=true, endGroups=2)]
		public string separation = ", ";
		
		public TargetNamesDisplay()
		{
			
		}
		
		public string GetNames(List<Combatant> targets)
		{
			if(targets == null || targets.Count == 0)
			{
				return "";
			}
			else if(targets.Count > 1)
			{
				if(this.onlyFirst)
				{
					return this.firstTargetText[ORK.Game.Language].Replace("%n", targets[0].GetName());
				}
				else
				{
					StringBuilder builder = new StringBuilder();
					bool first = true;
					for(int i=0; i<targets.Count; i++)
					{
						if(targets[i] != null)
						{
							if(first)
							{
								builder.Append(targets[i].GetName());
								first = false;
							}
							else
							{
								builder.Append(this.lineSeparation ? "\n" : this.separation).Append(targets[i].GetName());
							}
						}
					}
					return builder.ToString();
				}
			}
			else if(targets.Count > 0 && targets[0] != null)
			{
				return targets[0].GetName();
			}
			return "";
		}
	}
}
