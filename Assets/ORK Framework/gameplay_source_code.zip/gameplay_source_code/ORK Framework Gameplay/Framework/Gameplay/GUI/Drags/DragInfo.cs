
using System.Collections.Generic;
using UnityEngine;
using ORKFramework.Menu.Parts;

namespace ORKFramework
{
	public class DragInfo
	{
		private IDragOrigin origin;
		
		private GUIBox boxOrigin;
		
		private IShortcut shortcut;
		
		private Combatant user;
		
		private HUDLevelPoints[] levelPointsElement;
		
		private bool inPause = false;
		
		public DragInfo(IDragOrigin origin, IShortcut shortcut, Combatant user)
		{
			this.origin = origin;
			this.shortcut = shortcut;
			this.user = user;
			
			if(this.origin is BaseMenuPart)
			{
				this.inPause = ((BaseMenuPart)this.origin).Screen.pauseGame;
			}
		}
		
		public IDragOrigin Origin
		{
			get{ return this.origin;}
			set{ this.origin = value;}
		}
		
		public GUIBox BoxOrigin
		{
			get{ return this.boxOrigin;}
			set{ this.boxOrigin = value;}
		}
		
		public IShortcut Shortcut
		{
			get{ return this.shortcut;}
		}
		
		public Combatant User
		{
			get{ return this.user;}
		}
		
		public bool InPause
		{
			get{ return this.inPause;}
			set{ this.inPause = value;}
		}
		
		public bool UseOn(Combatant target, bool animate)
		{
			if(this.shortcut != null)
			{
				List<Combatant> tmp = new List<Combatant>();
				tmp.Add(target);
				return this.shortcut.Use(this.user, tmp, animate);
			}
			return false;
		}
		
		public HUDLevelPoints[] LevelPointsDisplay
		{
			get{ return this.levelPointsElement;}
			set{ this.levelPointsElement = value;}
		}
		
		public BaseAction GetAction()
		{
			if(this.shortcut is AbilityShortcut)
			{
				return new AbilityAction(user, this.shortcut as AbilityShortcut);
			}
			else if(this.shortcut is ItemShortcut)
			{
				return new ItemAction(user, this.shortcut as ItemShortcut);
			}
			return null;
		}
	}
}
