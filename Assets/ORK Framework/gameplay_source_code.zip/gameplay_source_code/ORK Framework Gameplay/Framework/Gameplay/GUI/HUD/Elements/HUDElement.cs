
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDElement : CoreHUDElement
	{
		[ORKEditorHelp("Show Box", "Shows a box around this element using the style of " +
			"the box defined by the GUISkin of the GUI box.\n" +
			"The position and size of the box is defined by the bounds.", "")]
		[ORKEditorInfo(separator=true, labelText="Element Position")]
		public bool box = false;
		
		[ORKEditorHelp("No Flash", "This element won't flash when the HUD flashes.", "")]
		public bool noFlash = false;
		
		[ORKEditorHelp("Force Size", "The size (width and height of the bounds) will always be used, " +
			"even if the content of the element doesn't need the whole bounds.\n" +
			"If disabled, only the size used by the content is used.\n" +
			"This setting is used for GUI boxes with 'Auto' and 'Scroll' height adjustment.", "")]
		public bool forceSize = false;
		
		[ORKEditorHelp("Outside Bounds", "The element's content can also be displayed outside of it's bounds.\n" +
			"If disabled, the content wont be displayed outside of the element's bounds - " +
			"if content exceeds the bounds, it will be cut off.", "")]
		[ORKEditorLayout("gui:legacy", endCheckGroup=true)]
		public bool outsideBounds = false;
		
		[ORKEditorHelp("Bounds", "The position and size of this element.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of the GUI box this HUD uses.", "")]
		public Rect bounds = new Rect(0, 0, 300, 100);
		
		
		// background image
		[ORKEditorHelp("Show Background", "Display a background image in this HUD element.", "")]
		[ORKEditorInfo(separator=true, labelText="Background Image")]
		public bool showBackground = false;
		
		[ORKEditorLayout("showBackground", true, autoInit=true)]
		public DisplayImage bg;
		
		[ORKEditorHelp("Expand Bounds", "The background image's bounds will " +
			"expand the element's bounds when exceeding them.", "")]
		[ORKEditorLayout("gui:legacy", endCheckGroup=true, endGroups=2)]
		public bool expandBoundsBG = false;
		
		public HUDElement()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public virtual void CreateLabels(out List<BaseLabel> label, Rect displayBounds, Combatant combatant)
		{
			label = null;
		}
		
		public virtual void CreateLabelsEditor(out List<BaseLabel> label, Rect displayBounds, Combatant combatant)
		{
			this.CreateLabels(out label, displayBounds, combatant);
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public virtual ChoiceContent GetDragOnPosition(Combatant owner, Vector2 position)
		{
			return null;
		}
		
		public virtual bool CheckDrop(Combatant owner, DragInfo drag, Vector2 position)
		{
			return false;
		}
		
		public virtual IContent GetTooltip(Combatant owner, Vector2 position)
		{
			return null;
		}
		
		public virtual bool CheckClick(Combatant owner, Vector2 position)
		{
			return false;
		}
	}
}
