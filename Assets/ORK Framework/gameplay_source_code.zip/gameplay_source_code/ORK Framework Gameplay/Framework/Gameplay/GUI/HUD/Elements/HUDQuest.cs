
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDQuest : HUDElement
	{
		// quest types
		[ORKEditorHelp("All Quest Types", "All quest types will be displayed.\n" +
			"If disabled, you have to select the quest types that will be displayed.", "")]
		[ORKEditorInfo("Quest Settings", "Define the displayed quest types and status " +
			"and how the quests will be displayed.", "", 
			labelText="Quest Type Settings")]
		public bool allTypes = true;
		
		public TypeSorter typeSorter = new TypeSorter();
		
		[ORKEditorHelp("Quest Type", "Select the quest type that will be displayed.", "")]
		[ORKEditorInfo(ORKDataType.QuestType, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Quest Type", "Adds a quest type that will be displayed.", "", 
			"Remove", "Removes this quest type.", "", noRemoveCount=1, isHorizontal=true)]
		[ORKEditorLayout("allTypes", false, endCheckGroup=true, autoInit=true, autoSize=1)]
		public int[] availableTypeID;
		
		// quest status
		[ORKEditorHelp("Add Inactive", "Inactive quests will be added to the list.", "")]
		[ORKEditorInfo(separator=true, labelText="Quest Status Settings")]
		public bool addInactive = false;
		
		[ORKEditorHelp("Add Active", "Active quests will be added to the list.", "")]
		public bool addActive = true;
		
		[ORKEditorHelp("Add Finished", "Finished quests will be added to the list.", "")]
		public bool addFinished = false;
		
		[ORKEditorHelp("Add Failed", "Failed quests will be added to the list.", "")]
		public bool addFailed = false;
		
		// quest content
		[ORKEditorHelp("Quest Display", "Select how the quests will be displayed.", "")]
		[ORKEditorInfo("Content Settings", "Define how the quests will be displayed.", "")]
		public HUDBarFilling questFilling = HUDBarFilling.TopToBottom;
		
		[ORKEditorHelp("Quest Spacing", "The space between two displayed quests.", "")]
		public float questSpacing = 10;
		
		[ORKEditorHelp("Click Type", "Define what happens when you click on a quest header:\n" +
			"- None: Nothing happens.\n" +
			"- Toggle Tasks: Toggles the quest's tasks between displaying and hiding.", "")]
		[ORKEditorInfo(separator=true)]
		public HUDQuestClickType questClickType = HUDQuestClickType.None;
		
		// content
		[ORKEditorHelp("Quest Text", "The text that will be displayed to represent a quest (title/header without tasks).", "")]
		[ORKEditorInfo(endFoldout=true, separator=true, isTextArea=true, labelText="Text", label=new string[] {
				"%n = quest name, %d = quest description, %i = quest icon, %t = quest text", 
				"%tn = type name, %td = type description, %ti = type icon"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] questText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n");
		
		// quest text format
		[ORKEditorHelp("Line Spacing", "The space between text lines.", "")]
		[ORKEditorInfo("Text Formatting", "Define the appearance of the text, " +
			"e.g. alignment, text/shadow color, font size/style.", "")]
		public float lineSpacing = 10;
		
		[ORKEditorHelp("Text Alignment", "Select how the text will be aligned horizontally.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TextAlignment alignment = TextAlignment.Left;
		
		[ORKEditorHelp("Line Alignment", "Select how text lines will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment vAlignment = VerticalTextAlignment.Bottom;
		
		[ORKEditorInfo(separator=true, endFoldout=true, endFolds=2)]
		public TextFormat textFormat = TextFormat.Default;
		
		
		// task content
		// task status
		[ORKEditorHelp("Add Inactive", "Inactive tasks will be added to the list.", "")]
		[ORKEditorInfo("Task Settings", "Define the displayed task status " +
			"and how the tasks will be displayed.", "", 
			labelText="Task Status Settings")]
		public bool taskAddInactive = false;
		
		[ORKEditorHelp("Add Active", "Active tasks will be added to the list.", "")]
		public bool taskAddActive = true;
		
		[ORKEditorHelp("Add Finished", "Finished tasks will be added to the list.", "")]
		public bool taskAddFinished = false;
		
		[ORKEditorHelp("Add Failed", "Failed tasks will be added to the list.", "")]
		public bool taskAddFailed = false;
		
		// task content
		[ORKEditorHelp("Task Display", "Select how the tasks will be displayed.", "")]
		[ORKEditorInfo("Content Settings", "Define how the tasks will be displayed.", "")]
		public HUDBarFilling taskFilling = HUDBarFilling.TopToBottom;
		
		[ORKEditorHelp("Task Spacing", "The space between two displayed tasks.", "")]
		public float taskSpacing = 10;
		
		[ORKEditorHelp("Click Type", "Define what happens when you click on a task:\n" +
			"- None: Nothing happens.\n" +
			"- Toggle Markers: Toggles the task's navigation markers between displaying and hiding.", "")]
		[ORKEditorInfo(separator=true)]
		public HUDQuestTaskClickType taskClickType = HUDQuestTaskClickType.None;
		
		[ORKEditorHelp("Task Text", "The text that will be used to display a task.\n" +
			"This text will be added for each task of a quest.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, labelText="Task Text", 
			label=new string[] {
				"%n = task name, %d = task description, %i = task icon", 
				"%rfi = finish requirements"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] taskText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n");
		
		// inactive task text
		[ORKEditorHelp("Use Inactive Text", "Use a different text to display inactive tasks.", "")]
		[ORKEditorInfo(separator=true, labelText="Inactive Task Text")]
		[ORKEditorLayout("taskAddInactive", true, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool taskUseInactive = false;
		
		[ORKEditorHelp("Inactive Task Text", "The text that will be used to display an inactive task.\n" +
			"This text will be added for each inactive task of a quest.", "")]
		[ORKEditorInfo(isTextArea=true, label=new string[] {
				"%n = task name, %d = task description, %i = task icon", 
				"%rfi = finish requirements"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("taskUseInactive", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] taskInactiveText;
		
		// finished task text
		[ORKEditorHelp("Use Finished Text", "Use a different text to display finished tasks.", "")]
		[ORKEditorInfo(separator=true, labelText="Finished Task Text")]
		[ORKEditorLayout("taskAddFinished", true, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool taskUseFinished = false;
		
		[ORKEditorHelp("Finished Task Text", "The text that will be used to display a finished task.\n" +
			"This text will be added for each finished task of a quest.", "")]
		[ORKEditorInfo(isTextArea=true, label=new string[] {
				"%n = task name, %d = task description, %i = task icon", 
				"%rfi = finish requirements"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("taskUseFinished", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] taskFinishedText;
		
		// failed task text
		[ORKEditorHelp("Use Failed Text", "Use a different text to display failed tasks.", "")]
		[ORKEditorInfo(separator=true, labelText="Failed Task Text")]
		[ORKEditorLayout("taskAddFailed", true, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool taskUseFailed = false;
		
		[ORKEditorHelp("Failed Task Text", "The text that will be used to display a failed task.\n" +
			"This text will be added for each failed task of a quest.", "")]
		[ORKEditorInfo(endFoldout=true, isTextArea=true, label=new string[] {
				"%n = task name, %d = task description, %i = task icon", 
				"%rfi = finish requirements"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("taskUseFailed", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] taskFailedText;
		
		// requirement settings
		[ORKEditorHelp("Line Separation", "Requirements will be in separate lines.\n" +
			"If disabled, you can define a separator.", "")]
		[ORKEditorInfo("Requirement Settings", "The text that will be used to display a task's finish requirements.\n" +
			"This text will be added for each finish requirement (items and enemy kills) of a task.", "")]
		public bool taskReqSepLine = true;
		
		[ORKEditorHelp("Separator", "Define the separator between two requirements.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("taskReqSepLine", false, endCheckGroup=true)]
		public string taskReqSeparator = ", ";
		
		// task text
		[ORKEditorHelp("Requirement Text", "The text that will be used to display a finish requirement.\n" +
			"This text will be added for each finish requirement (items and enemy kills) of a task.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, labelText="Requirement Text", 
			endFoldout=true, label=new string[] {
				"%n = name, %d = description, %i = icon", 
				"%m = needed quantity, % = quantity"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] taskReqText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n %/%m");
		
		// task text format
		[ORKEditorHelp("Line Spacing", "The space between text lines.", "")]
		[ORKEditorInfo("Text Formatting", "Define the appearance of the text, " +
			"e.g. alignment, text/shadow color, font size/style.", "")]
		public float taskLineSpacing = 10;
		
		[ORKEditorHelp("Text Alignment", "Select how the text will be aligned horizontally.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TextAlignment taskAlignment = TextAlignment.Left;
		
		[ORKEditorHelp("Line Alignment", "Select how text lines will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment taskVAlignment = VerticalTextAlignment.Bottom;
		
		[ORKEditorInfo(separator=true, endFoldout=true, endFolds=2)]
		public TextFormat taskTextFormat = TextFormat.Default;
		
		public HUDQuest()
		{
			
		}
		
		
		/*
		============================================================================
		Quest functions
		============================================================================
		*/
		private List<int> GetQuestTypeList()
		{
			List<int> list = null;
			
			if(this.allTypes)
			{
				list = ORK.Game.Quests.GetTypes(
						this.addInactive, this.addActive, this.addFinished, this.addFailed);
			}
			else
			{
				list = new List<int>();
				for(int i=0; i<this.availableTypeID.Length; i++)
				{
					if(ORK.Game.Quests.HasType(this.availableTypeID[i], 
						this.addInactive, this.addActive, this.addFinished, this.addFailed))
					{
						list.Add(this.availableTypeID[i]);
					}
				}
			}
			
			this.typeSorter.Sort(ref list, ORKDataType.QuestType);
			return list;
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public override void CreateLabels(out List<BaseLabel> label, Rect displayBounds, 
			Combatant combatant)
		{
			label = new List<BaseLabel>();
			
			List<int> types = this.GetQuestTypeList();
			for(int i=0; i<types.Count; i++)
			{
				List<Quest> quests = ORK.Game.Quests.GetQuestsByType(types[i], 
					this.addInactive, this.addActive, this.addFinished, this.addFailed);
				
				for(int j=0; j<quests.Count; j++)
				{
					QuestLabel qlabel = this.CreateQuestLabel(quests[j], displayBounds, combatant);
					if(qlabel != null)
					{
						label.Add(qlabel);
					}
				}
			}
		}
		
		public override void CreateLabelsEditor(out List<BaseLabel> label, Rect displayBounds, Combatant combatant)
		{
			label = new List<BaseLabel>();
			Quest quest = new Quest(0, false, true, false, false);
			
			QuestLabel qlabel = this.CreateQuestLabel(quest, displayBounds, combatant);
			if(qlabel != null)
			{
				label.Add(qlabel);
			}
		}
		
		
		/*
		============================================================================
		Quest label functions
		============================================================================
		*/
		private QuestLabel CreateQuestLabel(Quest quest, Rect displayBounds, Combatant combatant)
		{
			QuestType questType = ORK.QuestTypes.Get(quest.Setting.questTypeID);
			
			// tasks
			List<QuestTaskLabel> taskLabel = new List<QuestTaskLabel>();
			
			List<QuestTask> tasks = quest.GetTasks(this.taskAddInactive, this.taskAddActive, 
				this.taskAddFinished, this.taskAddFailed);
			for(int i=0; i<tasks.Count; i++)
			{
				taskLabel.Add(new QuestTaskLabel(tasks[i], new MultiContent(
					TextHelper.ReplaceSpecials(this.GetTaskText(tasks[i])), 
					null, null, displayBounds, this.taskLineSpacing, 
					this.taskAlignment, this.taskVAlignment, BoxHeightAdjustment.Auto, false, this.taskTextFormat).label));
			}
			
			if(HUDBarFilling.BottomToTop.Equals(this.taskFilling) || 
				HUDBarFilling.RightToLeft.Equals(this.taskFilling))
			{
				taskLabel.Reverse();
			}
			
			return new QuestLabel(this, new QuestHeaderLabel(quest, new MultiContent(
					TextHelper.ReplaceSpecials(
						this.questText[ORK.Game.Language].
							Replace("%n", quest.GetName()).
							Replace("%d", quest.GetDescription()).
							Replace("%tn", questType.GetName()).
							Replace("%td", questType.GetDescription()).
							Replace("%ti", questType.GetIconTextCode()).
							Replace("%t", quest.GetText()).
							Replace("%i", quest.GetIconTextCode())), 
					null, null, displayBounds, this.lineSpacing, 
					this.alignment, this.vAlignment, BoxHeightAdjustment.Auto, false, this.textFormat).label), 
				taskLabel);
		}
		
		private string GetTaskText(QuestTask task)
		{
			string tmpText = "";
			
			if(this.taskUseInactive && task.IsInactive())
			{
				tmpText += this.taskInactiveText[ORK.Game.Language].
					Replace("%n", task.GetName()).
					Replace("%d", task.GetDescription()).
					Replace("%i", task.GetIconTextCode());
			}
			else if(this.taskUseFinished && task.IsFinished())
			{
				tmpText += this.taskFinishedText[ORK.Game.Language].
					Replace("%n", task.GetName()).
					Replace("%d", task.GetDescription()).
					Replace("%i", task.GetIconTextCode());
			}
			else if(this.taskUseFailed && task.IsFailed())
			{
				tmpText += this.taskFailedText[ORK.Game.Language].
					Replace("%n", task.GetName()).
					Replace("%d", task.GetDescription()).
					Replace("%i", task.GetIconTextCode());
			}
			else
			{
				tmpText += this.taskText[ORK.Game.Language].
					Replace("%n", task.GetName()).
					Replace("%d", task.GetDescription()).
					Replace("%i", task.GetIconTextCode());
			}
			
			if(tmpText.Contains("%rfi"))
			{
				tmpText = tmpText.Replace("%rfi", this.GetRequirementListText(task));
			}
			
			return tmpText;
		}
		
		private string GetRequirementListText(QuestTask task)
		{
			string tmpText = "";
			
			// items
			for(int i=0; i<task.Setting.finishRequirements.item.Length; i++)
			{
				if(i > 0)
				{
					tmpText += this.taskReqSepLine ? "\n" : this.taskReqSeparator;
				}
				
				IShortcut shortcut = task.Setting.finishRequirements.item[i].CreateShortcut();
				tmpText += this.taskReqText[ORK.Game.Language].
					Replace("%n", shortcut.GetName()).
					Replace("%d", shortcut.GetDescription()).
					Replace("%i", shortcut.GetIconTextCode()).
					Replace("%m", shortcut.Quantity.ToString()).
					Replace("%", task.finishRequirements.item[i].ToString());
			}
			
			// enemy kills
			for(int i=0; i<task.Setting.finishRequirements.enemyKill.Length; i++)
			{
				if(i > 0 || tmpText != "")
				{
					tmpText += this.taskReqSepLine ? "\n" : this.taskReqSeparator;
				}
				
				CombatantSetting enemy = ORK.Combatants.Get(task.Setting.finishRequirements.enemyKill[i].combatantID);
				tmpText += this.taskReqText[ORK.Game.Language].
					Replace("%n", enemy.GetName()).
					Replace("%d", enemy.GetDescription()).
					Replace("%i", enemy.GetIconTextCode()).
					Replace("%m", task.Setting.finishRequirements.enemyKill[i].quantity.ToString()).
					Replace("%", task.finishRequirements.enemyKill[i].ToString());
			}
			
			return tmpText;
		}
	}
}
