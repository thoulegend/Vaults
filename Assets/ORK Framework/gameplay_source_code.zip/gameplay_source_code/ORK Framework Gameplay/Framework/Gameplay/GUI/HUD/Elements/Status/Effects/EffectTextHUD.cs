
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class EffectTextHUD : BaseData
	{
		[ORKEditorHelp("Only One", "Only one status effect will be displayed - " +
			"the displayed effect will be changed over time.\n" +
			"If disabled, all status effects (fitting into the available cells) will be displayed.", "")]
		public bool one = false;
		
		
		// cell settings
		[ORKEditorHelp("Rows", "The number of rows the bounds will be split into.", "")]
		[ORKEditorInfo(separator=true, labelText="Cell Settings")]
		[ORKEditorLayout("one", false)]
		[ORKEditorLimit(1, false)]
		public int rows = 1;
		
		[ORKEditorHelp("Columns", "The number of columns the bounds will be split into.", "")]
		[ORKEditorLimit(1, false)]
		public int columns = 5;
		
		[ORKEditorHelp("Column Fill", "Defines how the status effects will be filled into the columns.\n" +
			"Either 'Vertical' or 'Horizontal'.", "")]
		[ORKEditorInfo(isEnumToolbar=true)]
		public ColumnFill columnFill = ColumnFill.Vertical;
		
		[ORKEditorHelp("Spacing", "The space between the cells (X=horizontally, Y=vertically).", "")]
		public Vector2 spacing = new Vector2(5, 5);
		
		[ORKEditorHelp("Set Cell Size", "Set the size of the cells manually.\n" +
			"If disabled, the cell size will be calculated based on the " +
			"number of rows and columns, and the bounds.", "")]
		public bool setCellSize = false;
		
		[ORKEditorHelp("Cell Size", "The width (X) and height (Y) of each cell.", "")]
		[ORKEditorLayout("setCellSize", true, endCheckGroup=true, endGroups=2)]
		public Vector2 cellSize = new Vector2(100, 20);
		
		
		// content
		[ORKEditorArray(false, "Add Content Text", "Adds a content text.\n" +
			"Use multiple content texts to create more complex status effect informations.", "", 
			"Remove", "Removes this content text.", "", isMove=true, isCopy=true, foldout=true, 
			foldoutText=new string[] {"Content Text", "The content of the status effect cell (e.g. icon, name or remaining time/turns).\n" +
				"Use multiple content texts to create more complex status effect informations.", ""})]
		public EffectText[] content = new EffectText[0];
		
		public EffectTextHUD()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			if(data.Contains<DataObject>("text"))
			{
				DataObject tmp = null;
				data.Get("text", ref tmp);
				if(tmp != null)
				{
					EffectText tmpText = new EffectText();
					tmpText.text.SetData(tmp);
					ArrayHelper.Add(ref this.content, tmpText);
				}
			}
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			List<StatusEffect> effects = combatant.Status.GetHUDEffects();
			if(effects.Count > 0)
			{
				if(combatant.HUDEffectIndex >= effects.Count)
				{
					combatant.HUDEffectIndex = 0;
				}
				
				if(this.one)
				{
					this.CreateEffect(ref label, effects[combatant.HUDEffectIndex], bounds);
				}
				else
				{
					int maxView = this.rows * this.columns;
					
					Vector2 cell = new Vector2(bounds.width, bounds.height);
					if(this.setCellSize)
					{
						cell = this.cellSize;
					}
					else
					{
						cell.x -= this.spacing.x * (this.columns - 1);
						cell.y -= this.spacing.y * (this.rows - 1);
						cell.x /= this.columns;
						cell.y /= this.rows;
					}
					
					int currentColumn = 0;
					int currentRow = 0;
					
					int start = 0;
					if(effects.Count > maxView)
					{
						start = combatant.HUDEffectIndex;
						
					}
					
					for(int i = start; i<effects.Count; i++)
					{
						if(i - start >= maxView)
						{
							break;
						}
						else
						{
							this.CreateEffect(ref label, effects[i], 
								new Rect(cell.x * currentColumn + this.spacing.x * currentColumn, 
									cell.y * currentRow + this.spacing.y * currentRow, 
									cell.x, cell.y));
							
							if(ColumnFill.Vertical.Equals(this.columnFill))
							{
								currentColumn++;
								if(currentColumn >= this.columns)
								{
									currentColumn = 0;
									currentRow++;
								}
							}
							else
							{
								currentRow++;
								if(currentRow >= this.rows)
								{
									currentRow = 0;
									currentColumn++;
								}
							}
						}
					}
				}
			}
		}
		
		private List<BaseLabel> CreateEffect(ref List<BaseLabel> label, StatusEffect effect, Rect bounds)
		{
			// content
			for(int i=0; i<this.content.Length; i++)
			{
				if(this.content[i].text.text[ORK.Game.Language] != "")
				{
					this.content[i].Create(ref label, effect, bounds);
				}
			}
			return label;
		}
		
		public IContent GetTooltip(Combatant combatant, Vector2 position, Rect bounds)
		{
			if(bounds.Contains(position))
			{
				List<StatusEffect> effects = combatant.Status.GetHUDEffects();
				if(effects.Count > 0)
				{
					if(combatant.HUDEffectIndex >= effects.Count)
					{
						combatant.HUDEffectIndex = 0;
					}
					
					if(this.one)
					{
						return effects[combatant.HUDEffectIndex];
					}
					else
					{
						int maxView = this.rows * this.columns;
						
						Vector2 cell = new Vector2(bounds.width, bounds.height);
						if(this.setCellSize)
						{
							cell = this.cellSize;
						}
						else
						{
							cell.x -= this.spacing.x * (this.columns - 1);
							cell.y -= this.spacing.y * (this.rows - 1);
							cell.x /= this.columns;
							cell.y /= this.rows;
						}
						
						int currentColumn = 0;
						int currentRow = 0;
						
						int start = 0;
						if(effects.Count > maxView)
						{
							start = combatant.HUDEffectIndex;
							
						}
						
						for(int i = start; i<effects.Count; i++)
						{
							if(i - start >= maxView)
							{
								break;
							}
							else
							{
								if(new Rect(bounds.x + cell.x * currentColumn + this.spacing.x * currentColumn, 
										bounds.y + cell.y * currentRow + this.spacing.y * currentRow, 
										cell.x, cell.y).Contains(position))
								{
									return effects[i];
								}
								
								if(ColumnFill.Vertical.Equals(this.columnFill))
								{
									currentColumn++;
									if(currentColumn >= this.columns)
									{
										currentColumn = 0;
										currentRow++;
									}
								}
								else
								{
									currentRow++;
									if(currentRow >= this.rows)
									{
										currentRow = 0;
										currentColumn++;
									}
								}
							}
						}
					}
				}
			}
			
			return null;
		}
	}
}
