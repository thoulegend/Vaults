
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ShortcutHUD : BaseData, IDragOrigin
	{
		[ORKEditorHelp("Slot Start Index", "The index of the first slot that will be displayed.\n" +
			"The rows and columns define how many slots will be displayed.", "")]
		[ORKEditorLimit(0, false)]
		public int startIndex = 0;
		
		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a shortcut.", "")]
		public bool enableTooltip = false;
		
		[ORKEditorHelp("Enable Dragging", "Assigned shortcuts can be dragged.\n" +
			"Dragging a shortcut onto something (e.g. a combatant) will use it on the target.", "")]
		public bool enableDrag = false;
		
		[ORKEditorHelp("Enable Double Click", "Items can be double clicked.\n" +
			"Double clicking on a shortcut and clicking on something (e.g. a combatant) will use it on the target.", "")]
		public bool enableDoubleClick = false;
		
		[ORKEditorHelp("Use Group Target", "The shortcut will be used on a group target (if possible).", "")]
		[ORKEditorLayout("enableDoubleClick", true, setDefault=true, defaultValue=false)]
		public bool useGroupTarget = false;
		
		[ORKEditorHelp("Use Individual Target", "The shortcut will be used on an individual target (if possible).", "")]
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool useIndividualTarget = false;
		
		
		// inactive shortcut color
		[ORKEditorHelp("Inactive Color", "The color used to display inactive shortcuts (e.g. an ability that can't be used).", "")]
		[ORKEditorInfo(separator=true)]
		public Color inactiveColor = new Color(1, 1, 1, 0.5f);
		
		
		// cell settings
		[ORKEditorHelp("Rows", "The number of rows the bounds will be split into.", "")]
		[ORKEditorInfo(separator=true, labelText="Cell Settings")]
		[ORKEditorLimit(1, false)]
		public int rows = 1;
		
		[ORKEditorHelp("Columns", "The number of columns the bounds will be split into.", "")]
		[ORKEditorLimit(1, false)]
		public int columns = 5;
		
		[ORKEditorHelp("Column Fill", "Defines how the shortcuts will be filled into the columns.\n" +
			"Either 'Vertical' or 'Horizontal'.", "")]
		[ORKEditorInfo(isEnumToolbar=true)]
		public ColumnFill columnFill = ColumnFill.Vertical;
		
		[ORKEditorHelp("Spacing", "The space between the cells (X=horizontally, Y=vertically).", "")]
		public Vector2 spacing = new Vector2(5, 5);
		
		[ORKEditorHelp("Set Cell Size", "Set the size of the cells manually.\n" +
			"If disabled, the cell size will be calculated based on the " +
			"number of rows and columns, and the bounds.", "")]
		public bool setCellSize = false;
		
		[ORKEditorHelp("Cell Size", "The width (X) and height (Y) of each cell.", "")]
		[ORKEditorLayout("setCellSize", true, endCheckGroup=true)]
		public Vector2 cellSize = new Vector2(100, 20);
		
		
		// empty slot
		[ORKEditorInfo("Empty Slot Display", "Define how empty slots will be displayed.", "", 
			endFoldout=true, separatorForce=true)]
		public ShortcutSlotDisplay emptySlot = new ShortcutSlotDisplay();
		
		
		// assigned slot
		[ORKEditorInfo("Assigned Slot Display", "Define how assigned slots will be displayed.", "", 
			endFoldout=true, separatorForce=true)]
		public ShortcutSlotDisplay assignedSlot = new ShortcutSlotDisplay();
		
		public ShortcutHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			int maxView = this.rows * this.columns;
			
			Vector2 cell = new Vector2(bounds.width, bounds.height);
			if(this.setCellSize)
			{
				cell = this.cellSize;
			}
			else
			{
				cell.x -= this.spacing.x * (this.columns - 1);
				cell.y -= this.spacing.y * (this.rows - 1);
				cell.x /= this.columns;
				cell.y /= this.rows;
			}
			
			// create backgrounds
			int currentColumn = 0;
			int currentRow = 0;
			
			for(int i=0; i<maxView; i++)
			{
				if(combatant.Shortcuts.HasShortcut(this.startIndex + i))
				{
					IShortcut shortcut = combatant.Shortcuts[this.startIndex + i];
					label.Add(new ShortcutLabel(combatant, shortcut, 
						this.assignedSlot.Create(combatant, shortcut, 
							new Rect(cell.x * currentColumn + this.spacing.x * currentColumn, 
								cell.y * currentRow + this.spacing.y * currentRow, 
								cell.x, cell.y), this.startIndex + i), this.inactiveColor));
				}
				else
				{
					label.AddRange(this.emptySlot.Create(combatant, null, 
							new Rect(cell.x * currentColumn + this.spacing.x * currentColumn, 
								cell.y * currentRow + this.spacing.y * currentRow, 
								cell.x, cell.y), this.startIndex + i));
				}
				
				if(ColumnFill.Vertical.Equals(this.columnFill))
				{
					currentColumn++;
					if(currentColumn >= this.columns)
					{
						currentColumn = 0;
						currentRow++;
					}
				}
				else
				{
					currentRow++;
					if(currentRow >= this.rows)
					{
						currentRow = 0;
						currentColumn++;
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public ChoiceContent GetDragOnPosition(Combatant owner, Vector2 position, Rect bounds)
		{
			int maxView = this.rows * this.columns;
			
			Vector2 cell = new Vector2(bounds.width, bounds.height);
			if(this.setCellSize)
			{
				cell = this.cellSize;
			}
			else
			{
				cell.x -= this.spacing.x * (this.columns - 1);
				cell.y -= this.spacing.y * (this.rows - 1);
				cell.x /= this.columns;
				cell.y /= this.rows;
			}
			
			// create backgrounds
			int currentColumn = 0;
			int currentRow = 0;
			
			for(int i=0; i<maxView; i++)
			{
				if(new Rect(bounds.x + cell.x * currentColumn + this.spacing.x * currentColumn, 
							bounds.y + cell.y * currentRow + this.spacing.y * currentRow, 
							cell.x, cell.y).Contains(position))
				{
					if(owner.Shortcuts.HasShortcut(this.startIndex + i))
					{
						IShortcut shortcut = owner.Shortcuts[this.startIndex + i];
						ChoiceContent cc = new ChoiceContent(shortcut.GetContent());
						
						cc.isDragable = this.enableDrag;
						cc.isDoubleClick = this.enableDoubleClick;
						cc.isTooltip = this.enableTooltip;
						if(this.enableDoubleClick)
						{
							cc.useOnGroupTarget = this.useGroupTarget;
							cc.useOnIndividualTarget = this.useIndividualTarget;
						}
						if(cc.isDragable || cc.isDoubleClick || 
							cc.useOnGroupTarget || cc.useOnIndividualTarget)
						{
							cc.drag = shortcut.GetDrag(this, owner);
						}
						
						return cc;
					}
					else
					{
						return null;
					}
				}
				
				if(ColumnFill.Vertical.Equals(this.columnFill))
				{
					currentColumn++;
					if(currentColumn >= this.columns)
					{
						currentColumn = 0;
						currentRow++;
					}
				}
				else
				{
					currentRow++;
					if(currentRow >= this.rows)
					{
						currentRow = 0;
						currentColumn++;
					}
				}
			}
			
			return null;
		}
		
		public bool CheckDrop(Combatant owner, DragInfo drag, Vector2 position, Rect bounds)
		{
			if(owner == drag.User && drag.Shortcut != null)
			{
				int maxView = this.rows * this.columns;
				
				Vector2 cell = new Vector2(bounds.width, bounds.height);
				if(this.setCellSize)
				{
					cell = this.cellSize;
				}
				else
				{
					cell.x -= this.spacing.x * (this.columns - 1);
					cell.y -= this.spacing.y * (this.rows - 1);
					cell.x /= this.columns;
					cell.y /= this.rows;
				}
				
				// create backgrounds
				int currentColumn = 0;
				int currentRow = 0;
				
				for(int i=0; i<maxView; i++)
				{
					if(new Rect(bounds.x + cell.x * currentColumn + this.spacing.x * currentColumn, 
								bounds.y + cell.y * currentRow + this.spacing.y * currentRow, 
								cell.x, cell.y).Contains(position))
					{
						owner.Shortcuts[this.startIndex + i] = drag.Shortcut;
						return true;
					}
					
					if(ColumnFill.Vertical.Equals(this.columnFill))
					{
						currentColumn++;
						if(currentColumn >= this.columns)
						{
							currentColumn = 0;
							currentRow++;
						}
					}
					else
					{
						currentRow++;
						if(currentRow >= this.rows)
						{
							currentRow = 0;
							currentColumn++;
						}
					}
				}
			}
			
			return false;
		}

		public void Dropped(DragInfo drag)
		{
			
		}

		public bool DroppedOnCombatant(Combatant c, DragInfo drag)
		{
			if(c != null)
			{
				return drag.UseOn(c, true);
			}
			return false;
		}

		public bool DroppedToWorld(Vector3 position, DragInfo drag)
		{
			return false;
		}
		
		public IContent GetTooltip(Combatant owner, Vector2 position, Rect bounds)
		{
			int maxView = this.rows * this.columns;
			
			Vector2 cell = new Vector2(bounds.width, bounds.height);
			if(this.setCellSize)
			{
				cell = this.cellSize;
			}
			else
			{
				cell.x -= this.spacing.x * (this.columns - 1);
				cell.y -= this.spacing.y * (this.rows - 1);
				cell.x /= this.columns;
				cell.y /= this.rows;
			}
			
			// create backgrounds
			int currentColumn = 0;
			int currentRow = 0;
			
			for(int i=0; i<maxView; i++)
			{
				if(new Rect(bounds.x + cell.x * currentColumn + this.spacing.x * currentColumn, 
							bounds.y + cell.y * currentRow + this.spacing.y * currentRow, 
							cell.x, cell.y).Contains(position))
				{
					return owner.Shortcuts[this.startIndex + i];
				}
				
				if(ColumnFill.Vertical.Equals(this.columnFill))
				{
					currentColumn++;
					if(currentColumn >= this.columns)
					{
						currentColumn = 0;
						currentRow++;
					}
				}
				else
				{
					currentRow++;
					if(currentRow >= this.rows)
					{
						currentRow = 0;
						currentColumn++;
					}
				}
			}
			return null;
		}
	}
}
