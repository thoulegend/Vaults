
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Display
{
	public class ShortcutSlotDisplay : BaseData
	{
		// background image
		[ORKEditorHelp("Use Background", "Display a background image in the slot's bounds.", "")]
		[ORKEditorInfo(labelText="Slot Background Image")]
		public bool useImage = false;
		
		[ORKEditorLayout("useImage", true, endCheckGroup=true, autoInit=true)]
		public BaseImage image;
		
		
		// content
		[ORKEditorArray(false, "Add Content Text", "Adds a content text.\n" +
			"Use multiple content texts to create more complex shortcut informations.", "", 
			"Remove", "Removes this content text.", "", isMove=true, isCopy=true, foldout=true, 
			foldoutText=new string[] {"Content Text", "The content of the shortcut slot (e.g. icon, name or use costs).\n" +
				"Use multiple content texts to create more complex shortcut informations.", ""})]
		public ShortcutSlotText[] content = new ShortcutSlotText[0];
		
		public ShortcutSlotDisplay()
		{
			
		}
		
		public List<BaseLabel> Create(Combatant combatant, IShortcut shortcut, Rect bounds, int index)
		{
			List<BaseLabel> label = new List<BaseLabel>();
			// background image
			if(this.useImage)
			{
				ImageLabel imgLabel = this.image.Create(bounds);
				if(imgLabel != null)
				{
					label.Add(imgLabel);
				}
			}
			
			// content
			for(int i=0; i<this.content.Length; i++)
			{
				if(this.content[i].text.text[ORK.Game.Language] != "")
				{
					this.content[i].Create(ref label, combatant, shortcut, bounds, index);
				}
			}
			return label;
		}
	}
}
