
using UnityEngine;

namespace ORKFramework
{
	public class StatusTextHUD : BaseData
	{
		[ORKEditorHelp("Text", "The text that will be displayed.", "")]
		[ORKEditorInfo(isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// text format
		[ORKEditorHelp("Line Spacing", "The space between text lines.", "")]
		[ORKEditorInfo("Text Formatting", "Define the appearance of the text, e.g. alignment, text/shadow color, font size/style.", "", 
			separatorForce=true)]
		public float lineSpacing = 10;
		
		[ORKEditorHelp("Text Alignment", "Select how the text will be aligned horizontally.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TextAlignment alignment = TextAlignment.Left;
		
		[ORKEditorHelp("Line Alignment", "Select how text lines will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment vAlignment = VerticalTextAlignment.Bottom;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		public TextFormat textFormat = TextFormat.Default;
		
		public StatusTextHUD()
		{
			
		}
	}
}
