
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class StatusValueHUD : BaseData
	{
		// data origin
		[ORKEditorHelp("Value Origin", "Select where the displayed value will come from:\n" +
			"- Current: The current value of the status value.\n" +
			"- Preview: The preview value of the status value. If no preview is available, the current value is used instead.\n" +
			"- Preview Hide: The preview value of the status value. Hidden if no preview is available.\n" +
			"- Preview Hide No Change: The preview value of the status value. Only hides values if there is no change to the current value." +
			"A preview value displays how the status will change if a selected equipment would be equipped. " +
			"Preview values are only available for player group members.", "")]
		public HUDStatusOrigin origin = HUDStatusOrigin.Current;
		
		[ORKEditorInfo("Positive Change Text Format", "Define the appearance of the text for a positive change, " +
			"e.g. color, shadow, font size.", "", endFoldout=true)]
		[ORKEditorLayout(new string[] {"origin", "useBar"}, 
			new System.Object[] {HUDStatusOrigin.Current, true}, needed=Needed.One, elseCheckGroup=true)]
		public TextFormat previewPositiveFormat = TextFormat.Default;
		
		[ORKEditorInfo("Negative Change Text Format", "Define the appearance of the text for a negative change, " +
			"e.g. color, shadow, font size.", "", endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public TextFormat previewNegativeFormat = TextFormat.Default;
		
		
		
		// list
		[ORKEditorHelp("List", "Multiple status values will be displayed.\n" +
			"If disabled, only the selected status value will be displayed.", "")]
		[ORKEditorInfo(separator=true)]
		public bool list = false;
		
		[ORKEditorHelp("List All", "All status values will be displayed.\n" +
			"If disabled, only the status values of the selected type will be displayed.", "")]
		[ORKEditorLayout("list", true)]
		public bool listAll = false;
		
		[ORKEditorHelp("Status Value Type", "Select the status value type that will be listed.", "")]
		[ORKEditorLayout("listAll", false, endCheckGroup=true)]
		public StatusValueType listType = StatusValueType.Consumable;
		
		[ORKEditorHelp("Offset", "The offset of each listed status value.", "")]
		public Vector2 off = new Vector2(0, 30);
		
		[ORKEditorHelp("Set Size", "Set the size of the individual status values manually.\n" +
			"If disabled, the size defined by the bounds is used.", "")]
		public bool setSize = false;
		
		[ORKEditorHelp("Size", "The width (X) and height (Y) of each status value.", "")]
		[ORKEditorLayout("setSize", true, endCheckGroup=true)]
		public Vector2 size = new Vector2(100, 20);
		
		// value
		[ORKEditorHelp("Status Value", "Select the status value that will be displayed in this element.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int statusID = 0;
		
		
		// value bar
		[ORKEditorHelp("Use Bar", "The status value will be displayed as a bar instead of text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useBar = false;
		
		[ORKEditorHelp("Bar Bounds", "The position and size of the bar.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of this element's bounds.", "")]
		[ORKEditorLayout("useBar", true)]
		public Rect barBounds = new Rect(0, 0, 100, 10);
		
		[ORKEditorHelp("Override Bar", "Override the default value bar setting.\n" +
			"If disabled, the default value bar setting of the status value will be used to display the bar.", "")]
		public bool overrideBar = false;
		
		[ORKEditorLayout("overrideBar", true, endCheckGroup=true, autoInit=true)]
		public ValueBar bar;
		
		
		// text
		[ORKEditorInfo(separator=true, label=new string[] {
			"%n = name, %d = desciption, %i = icon", 
			"% = current value, %m = maximum value, %b = base value", 
			"%c = change between current and preview value"
		})]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public StatusTextHUD text;
		
		public StatusValueHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, bool isBestiary, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			if(this.list)
			{
				int tmp = 0;
				for(int i=0; i<ORK.StatusValues.Count; i++)
				{
					StatusValue sv = combatant.Status[i];
					if(!sv.Setting.hidden && (this.listAll || this.listType.Equals(sv.Setting.type)))
					{
						this.CreateStatusValue(ref label, sv, 
							isBestiary ? combatant.Bestiary : null, 
							new Rect(this.off.x * tmp, this.off.y * tmp, 
								this.setSize ? this.size.x : bounds.width, 
								this.setSize ? this.size.y : bounds.height), 
							combatant.Status.PreviewAvailable);
						tmp++;
					}
				}
			}
			else
			{
				this.CreateStatusValue(ref label, combatant.Status[this.statusID], 
					isBestiary ? combatant.Bestiary : null, 
					bounds, combatant.Status.PreviewAvailable);
			}
		}
		
		private void CreateStatusValue(ref List<BaseLabel> label, StatusValue sv, BestiaryEntry bestiary, 
			Rect bounds, bool previewAvailable)
		{
			int change = 0;
			int value = 0;
			int maxValue = 0;
			if(HUDStatusOrigin.Current.Equals(this.origin))
			{
				value = sv.GetDisplayValue();
				maxValue = sv.GetMaxValue();
			}
			else if(HUDStatusOrigin.Preview.Equals(this.origin))
			{
				if(previewAvailable)
				{
					value = sv.GetPreviewValue(true);
					maxValue = sv.GetPreviewMaxValue();
					change = sv.GetPreviewValue(false).CompareTo(sv.GetValue());
				}
				else
				{
					value = sv.GetDisplayValue();
					maxValue = sv.GetMaxValue();
				}
			}
			else if(HUDStatusOrigin.PreviewHide.Equals(this.origin))
			{
				if(previewAvailable)
				{
					value = sv.GetPreviewValue(true);
					maxValue = sv.GetPreviewMaxValue();
					change = sv.GetPreviewValue(false).CompareTo(sv.GetValue());
				}
				else
				{
					return;
				}
			}
			else if(HUDStatusOrigin.PreviewHideNoChange.Equals(this.origin))
			{
				if(previewAvailable)
				{
					value = sv.GetPreviewValue(true);
					maxValue = sv.GetPreviewMaxValue();
					
					if(sv.GetPreviewValue(false) == sv.GetValue())
					{
						return;
					}
					
					change = sv.GetPreviewValue(false).CompareTo(sv.GetValue());
				}
				else
				{
					return;
				}
			}
			
			if(this.useBar)
			{
				if(bestiary == null || bestiary.IsComplete || 
					bestiary.status.statusValues || 
					!ORK.GameSettings.bestiary.noStatusValueBars)
				{
					int subVal = sv.IsExperience() ? sv.GetMinValue() : 0;
					
					if(this.overrideBar)
					{
						this.bar.Create(ref label, 
							new Rect(this.barBounds.x + bounds.x, this.barBounds.y + bounds.y, this.barBounds.width, this.barBounds.height), 
							value - subVal, sv.GetMinValue(), maxValue);
					}
					else
					{
						sv.Setting.bar.Create(ref label, 
							new Rect(this.barBounds.x + bounds.x, this.barBounds.y + bounds.y, this.barBounds.width, this.barBounds.height), 
							value - subVal, sv.GetMinValue(), maxValue);
					}
				}
			}
			else
			{
				int previewChange = sv.GetPreviewValue(false) - sv.GetValue();
				string tmpText = "";
				
				if(bestiary == null || bestiary.IsComplete || 
					bestiary.status.statusValues)
				{
					tmpText = TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%n", sv.Setting.GetName()).
						Replace("%d", sv.Setting.GetDescription()).
						Replace("%i", sv.Setting.GetIconTextCode()).
						Replace("%m", maxValue.ToString()).
						Replace("%b", sv.GetBaseValue().ToString()).
						Replace("%c", previewChange.ToString()).
						Replace("%", value.ToString()));
				}
				else
				{
					change = 0;
					tmpText = TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%n", sv.Setting.GetName()).
						Replace("%d", sv.Setting.GetDescription()).
						Replace("%i", sv.Setting.GetIconTextCode()).
						Replace("%m", ORK.GameSettings.bestiary.statusValueText[ORK.Game.Language]).
						Replace("%b", ORK.GameSettings.bestiary.statusValueText[ORK.Game.Language]).
						Replace("%c", previewChange.ToString()).
						Replace("%", ORK.GameSettings.bestiary.statusValueText[ORK.Game.Language]));
				}
				
				label.AddRange(new MultiContent(tmpText, null, null, bounds, 
					this.text.lineSpacing, this.text.alignment, 
					this.text.vAlignment, BoxHeightAdjustment.Auto, false, 
					change > 0 ? 
					this.previewPositiveFormat : 
						(change < 0 ? 
							this.previewNegativeFormat : 
							this.text.textFormat)).label);
			}
		}
	}
}
