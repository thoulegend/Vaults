
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ValueBar : BaseData
	{
		[ORKEditorHelp("Bar Filling", "Select how the bar will be filled, i.e. the orientation of the bar.", "")]
		public HUDBarFilling filling = HUDBarFilling.LeftToRight;
		
		// iconize
		[ORKEditorHelp("Use Icons", "The bar is displayed as icons, e.g. 10 HP could be displayed as 10 heart icons.", "")]
		public bool useIcons = false;
		
		[ORKEditorHelp("Icon Size", "The size of the icons, X=width, Y=height.\n" +
			"The full/empty icon images are defined by the bar/empty bar images.", "")]
		[ORKEditorLayout("useIcons", true)]
		public Vector2 icSize = new Vector2(30, 30);
		
		[ORKEditorHelp("Icon Offset", "The offset between two icons.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float icOff = 0;
		
		
		// images
		[ORKEditorArray(false, "Add Images", "Add images to this element.\n" +
			"The bar can display different images depending on the filled percent of the bar.", "", 
			"Remove", "Remove images from this element.", "", noRemoveCount=1, isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Value Bar", "Set the percent and colors/images of the bar.", ""
		})]
		public ValueBarImage[] image = new ValueBarImage[] {new ValueBarImage()};
		
		public ValueBar()
		{
			
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public void CheckImages()
		{
			for(int i=0; i<this.image.Length; i++)
			{
				// make sure of percent sort
				if(i == 0)
				{
					this.image[i].percent = 100;
				}
				else if(this.image[i].percent > this.image[i-1].percent)
				{
					this.image[i].percent = this.image[i-1].percent;
				}
			}
		}
		
		
		/*
		============================================================================
		GUI functions
		============================================================================
		*/
		public void Create(ref List<BaseLabel> label, Rect bounds, float value, float minValue, float maxValue)
		{
			ImageLabel imageLabel = null;
			
			float p = value / (maxValue - minValue);
			if(p < 0)
			{
				p = 0;
			}
			else if(p > 1)
			{
				p = 1;
			}
			
			int index = 0;
			for(int i=this.image.Length-1; i>=0; i--)
			{
				if(p * 100 <= this.image[i].percent)
				{
					index = i;
					break;
				}
			}
			
			if(this.useIcons)
			{
				int j = 0;
				if(HUDBarFilling.LeftToRight.Equals(this.filling))
				{
					for(int i=(int)minValue; i<maxValue; i++)
					{
						if(i < value)
						{
							imageLabel = this.image[index].image.Create(
								new Rect((this.icSize.x + this.icOff) * j, 0, this.icSize.x, this.icSize.y));
						}
						else if(this.image[index].useEmpty)
						{
							imageLabel = this.image[index].emptyImage.Create(
								new Rect((this.icSize.x + this.icOff) * j, 0, this.icSize.x, this.icSize.y));
						}
						else
						{
							imageLabel = null;
						}
						if(imageLabel != null)
						{
							label.Add(imageLabel);
						}
						j++;
					}
				}
				else if(HUDBarFilling.RightToLeft.Equals(this.filling))
				{
					for(int i=(int)maxValue-1; i>=minValue; i--)
					{
						if(i < value)
						{
							imageLabel = this.image[index].image.Create(
								new Rect((this.icSize.x + this.icOff) * j, 0, this.icSize.x, this.icSize.y));
						}
						else if(this.image[index].useEmpty)
						{
							imageLabel = this.image[index].emptyImage.Create(
								new Rect((this.icSize.x + this.icOff) * j, 0, this.icSize.x, this.icSize.y));
						}
						else
						{
							imageLabel = null;
						}
						if(imageLabel != null)
						{
							label.Add(imageLabel);
						}
						j++;
					}
				}
				else if(HUDBarFilling.TopToBottom.Equals(this.filling))
				{
					for(int i=(int)minValue; i<maxValue; i++)
					{
						if(i < value)
						{
							imageLabel = this.image[index].image.Create(
								new Rect(0, (this.icSize.y + this.icOff) * j, this.icSize.x, this.icSize.y));
						}
						else if(this.image[index].useEmpty)
						{
							imageLabel = this.image[index].emptyImage.Create(
								new Rect(0, (this.icSize.y + this.icOff) * j, this.icSize.x, this.icSize.y));
						}
						else
						{
							imageLabel = null;
						}
						if(imageLabel != null)
						{
							label.Add(imageLabel);
						}
						j++;
					}
				}
				else if(HUDBarFilling.BottomToTop.Equals(this.filling))
				{
					for(int i=(int)maxValue-1; i>=minValue; i--)
					{
						if(i < value)
						{
							imageLabel = this.image[index].image.Create(
								new Rect(0, (this.icSize.y + this.icOff) * j, this.icSize.x, this.icSize.y));
						}
						else if(this.image[index].useEmpty)
						{
							imageLabel = this.image[index].emptyImage.Create(
								new Rect(0, (this.icSize.x + this.icOff) * j, this.icSize.x, this.icSize.y));
						}
						else
						{
							imageLabel = null;
						}
						if(imageLabel != null)
						{
							label.Add(imageLabel);
						}
						j++;
					}
				}
			}
			else
			{
				if(this.image[index].useEmpty)
				{
					imageLabel = this.image[index].emptyImage.Create(bounds, this.filling, p, true);
					if(imageLabel != null)
					{
						label.Add(imageLabel);
					}
				}
				imageLabel = this.image[index].image.Create(bounds, this.filling, p, false);
				if(imageLabel != null)
				{
					label.Add(imageLabel);
				}
			}
		}
	}
}
