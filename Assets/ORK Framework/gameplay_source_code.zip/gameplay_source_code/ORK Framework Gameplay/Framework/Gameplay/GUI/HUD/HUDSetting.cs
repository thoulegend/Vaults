
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDSetting : BaseIndexData
	{
		// base settings
		[ORKEditorHelp("Name", "The name of the HUD.", "")]
		[ORKEditorInfo("HUD Settings", "Set the name and base settings of the HUD.", "", 
			expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("GUI Box", "Select the GUI box that will be used to display this HUD.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox, separator=true)]
		public int guiBoxID = 0;
		
		[ORKEditorHelp("HUD Type", "Select the type of this HUD:\n" +
			"- Information: Displays information, e.g. game time, variables, etc.\n" +
			"- Interaction: Display available interactions " +
			"(i.e. an interactable object is inside the trigger of the interaction controller of the player).\n" +
			"- Combatant: Displays information about combatants.\n" +
			"- Control: Displays control elements for click and touch input.\n" +
			"- Navigation: Displays a navigation elements, e.g. cardinal directions, nearby interactions, etc.\n" +
			"- Tooltip: Displays information when the mouse position is above a menu item (e.g. abilities, items, etc.).\n" +
			"- Console: Displays the console. Please note that console HUDs don't have any HUD elements.\n" +
			"- Turn Order: Displays the turn order of 'Turn Based' battles (i.e. the order in which combatants perform their actions). " +
			"The HUD will only be displayed in running 'Turn Based' battles.\n" +
			"- Quest: Displays a list of quests and their tasks.", "")]
		[ORKEditorInfo(separator=true)]
		public HUDType type = HUDType.Information;
		
		[ORKEditorHelp("Display Empty Elements", "Empty HUD elements will be displayed.\n" +
			"If disabled, empty HUD elements will be hidden.", "")]
		public bool emptyElements = false;
		
		[ORKEditorHelp("Hide Empty HUD", "Hide this HUD if it doesn't have anything to display.", "")]
		[ORKEditorLayout(new string[] {"type", "type", "type"}, 
			new System.Object[] {HUDType.Control, HUDType.Navigation, HUDType.Console}, 
			needed=Needed.One, elseCheckGroup=true, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool hideEmptyHUD = false;
		
		
		
		// information settings
		[ORKEditorHelp("Auto Update", "The HUD will automatically be updated (i.e. recalculated) periodically.\n" +
			"Use this if you use information text codes that need regular updates (e.g. #time).", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", HUDType.Information, setDefault=true, defaultValue=false)]
		public bool autoUpdate = false;
		
		[ORKEditorHelp("Update Interval (s)", "The time in seconds between HUD updates.", "")]
		[ORKEditorLayout("autoUpdate", true, endCheckGroup=true, endGroups=2)]
		public float updateInterval = 1;
		
		
		
		// combatant/turn order settings
		[ORKEditorHelp("Enable Drop", "This HUD will receive drag and drop actions.\n" +
			"Dropping a drag (e.g. an ability or item) will use the action on the combatant the HUD belongs to.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {HUDType.Combatant, HUDType.TurnOrder}, 
			needed=Needed.One)]
		public bool enableDrop = false;
		
		[ORKEditorHelp("Combatant Type", "Select which combatant(s) will be displayed:\n" +
			"- Group: A combatant group will be displayed.\n" +
			"- Individual: Displays information of a combatant at the location of the combatant on screen.", "")]
		[ORKEditorInfo(isEnumToolbar=true)]
		[ORKEditorLayout("type", HUDType.Combatant, endCheckGroup=true, setDefault=true, defaultValue=CombatantScope.Group)]
		public CombatantScope comScope = CombatantScope.Group;
		
		// group
		[ORKEditorHelp("Invert Order", "Invert the order when displaying the combatants.\n" +
			"The last combatant will be displayed first, the first will be displayed last.\n" +
			"If disabled, the combatants will be displayed in normal order.", "")]
		[ORKEditorLayout("comScope", CombatantScope.Group)]
		public bool invertGroup = false;
		
		[ORKEditorHelp("Only Leaders", "Only the leaders of the groups will be displayed.", "")]
		[ORKEditorLayout("type", HUDType.Combatant, setDefault=true, defaultValue=false)]
		public bool onlyLeader = false;
		
		// group display settings
		[ORKEditorHelp("Start Index Offset", "Define which combatant will be the first in the list.\n" +
			"You can use this settings to skip a defind quantity of combatants at the start of the list.", "")]
		[ORKEditorLimit(0, false)]
		public int groupStartOffset = 0;
		
		[ORKEditorHelp("Limit List Length", "Limit the quantity of displayed combatants in the combatant list.\n" +
			"If disabled, all combatants will be displayed.", "")]
		public bool groupLimitDisplay = false;
		
		[ORKEditorHelp("Maximum Length", "The maximum displayed combatants in the combatant list.", "")]
		[ORKEditorLayout("groupLimitDisplay", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(1, false)]
		public int groupMaximumLength = 3;
		
		[ORKEditorHelp("Combatant Offset", "The offset added to the HUDs position per combatant.", "")]
		public Vector2 comOff = new Vector2(0, 50);
		
		// individual
		[ORKEditorHelp("Cursor Over", "The HUD is only displayed when the cursor is over the combatant.", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool curOver = false;
		
		[ORKEditorHelp("Path to Child", "The HUD is positioned at a child object of the combatant.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string childName = "";
		
		[ORKEditorHelp("Offset", "Offset added to the HUD position.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector2 comPosOff = Vector2.zero;
		
		// select groups
		[ORKEditorHelp("Player", "Members of the active player group will be displayed.", "")]
		[ORKEditorInfo(separator=true, labelText="Displayed Groups")]
		[ORKEditorLayout("type", HUDType.Combatant)]
		public bool player = false;
		
		[ORKEditorHelp("Ally", "Members of ally groups will be displayed.", "")]
		public bool ally = false;
		
		[ORKEditorHelp("Enemy", "Members of enemy groups will be displayed.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool enemy = false;
		
		[ORKEditorHelp("Ignore Flash", "This HUD wont be flashed by status value changes.\n" +
			"If disabled, the HUD will flash according to the status value refresh/damage notifications.", "")]
		[ORKEditorInfo(separator=true)]
		public bool noFlash = false;
		
		// limit turn order list
		[ORKEditorHelp("Limit List Length", "Limit the quantity of displayed combatants in the turn order list.\n" +
			"If disabled, all combatants in the turn order will be displayed.\n" +
			"When using 'Multi-Turns', the unlimited list will be as long as needed to display each combatant at least once.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", HUDType.TurnOrder)]
		public bool limitTurnOrder = false;
		
		[ORKEditorHelp("Maximum Length", "The maximum displayed combatants in the turn order.\n" +
			"When using 'Multi-Turns', the list will be filled up to this quantity.", "")]
		[ORKEditorLayout("limitTurnOrder", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(1, false)]
		public int turnOrderLimit = 10;
		
		// portrait
		[ORKEditorHelp("Show Portrait", "Show a portrait of the combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Settings")]
		public bool showPortrait = false;
		
		[ORKEditorHelp("Portrait Type", "Select the portrait type that will be dispalyed.\n" +
			"The combatant needs to have a portrait with this type.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showPortrait", true)]
		public int portraitTypeID = 0;
		
		// own portrait position
		[ORKEditorHelp("Own Position", "Overrides the default, GUI box and combatant portrait position settings.", "")]
		public bool ownPortraitPosition = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("ownPortraitPosition", true, endCheckGroup=true, autoInit=true, endGroups=3)]
		public PortraitPosition portraitPosition;
		
		
		
		// navigation settings
		[ORKEditorHelp("Display Range", "The range in degree the navigation bar will display (0-360).\n" +
			"E.g. 180 will display navigation information of 90° to the left and 90° to the right.", "")]
		[ORKEditorInfo(separator=true, labelText="Navigation Settings")]
		[ORKEditorLayout("type", HUDType.Navigation)]
		[ORKEditorLimit(0.0f, 360.0f)]
		public float navDisplayRange = 90;
		
		[ORKEditorHelp("North Offset", "The offset in degree added to the cardinal direction 'North'.\n" +
			"North is located at rotation Y=0.", "")]
		[ORKEditorLimit(-180.0f, 180.0f)]
		public float navNorthOffset = 0;
		
		[ORKEditorHelp("Forward Offset", "The offset in degree added to the forward angle.", "")]
		[ORKEditorLimit(-180.0f, 180.0f)]
		public float navForwardOffset = 0;
		
		[ORKEditorHelp("From Player", "The navigation uses the player's looking direction to display information.\n" +
			"If disabled, the camera's looking direction is used.", "")]
		public bool navFromPlayer = false;
		
		[ORKEditorHelp("Line Y Position", "The Y position of the navigation bar's display line.\n" +
			"Elements like 'North' will use this line as position for Y=0 to place them on the navigation bar.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float navLineY = 0;
		
		
		
		// tooltip settings
		[ORKEditorHelp("Items", "Display this tooltip HUD for items.\n" +
			"The HUD will be displayed if the mouse curser is positioned over a menu item or shortcut that represents an item.", "")]
		[ORKEditorInfo(separator=true, labelText="Tooltip Settings")]
		[ORKEditorLayout("type", HUDType.Tooltip)]
		public bool tooltipItem = true;
		
		[ORKEditorHelp("Weapons", "Display this tooltip HUD for weapons.\n" +
			"The HUD will be displayed if the mouse curser is positioned over a menu item or shortcut that represents a weapon.", "")]
		public bool tooltipWeapon = true;
		
		[ORKEditorHelp("Armors", "Display this tooltip HUD for armors.\n" +
			"The HUD will be displayed if the mouse curser is positioned over a menu item or shortcut that represents an armor.", "")]
		public bool tooltipArmor = true;
		
		[ORKEditorHelp("Money", "Display this tooltip HUD for money.\n" +
			"The HUD will be displayed if the mouse curser is positioned over a menu item or shortcut that represents money.", "")]
		public bool tooltipMoney = true;
		
		[ORKEditorHelp("Abilities", "Display this tooltip HUD for abilities.\n" +
			"The HUD will be displayed if the mouse curser is positioned over a menu item or shortcut that represents an ability.", "")]
		public bool tooltipAbility = true;
		
		[ORKEditorHelp("Combatants", "Display this tooltip HUD for combatants.\n" +
			"The HUD will be displayed if the mouse curser is positioned over a game object with a combatant component.", "")]
		public bool tooltipCombatant = false;
		
		[ORKEditorHelp("Scene Object", "Display this tooltip HUD for scene objects.\n" +
			"The HUD will be displayed if the mouse curser is positioned over a game object with a scene object component.", "")]
		public bool tooltipSceneObject = false;
		
		[ORKEditorHelp("Status Effect", "Display this tooltip HUD for status effects (from HUDs).\n" +
			"The HUD will be displayed if the mouse curser is positioned over a status effect in a HUD.", "")]
		public bool tooltipStatusEffects = false;
		
		[ORKEditorHelp("Quest", "Display this tooltip HUD for quests.\n" +
			"The HUD will be displayed if the mouse curser is positioned over a quest in a 'Quest' HUD.", "")]
		public bool tooltipQuest = false;
		
		[ORKEditorHelp("Quest Task", "Display this tooltip HUD for quest tasks.\n" +
			"The HUD will be displayed if the mouse curser is positioned over a quest task in a 'Quest' HUD.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool tooltipQuestTask = false;
		
		
		
		// console settings
		[ORKEditorHelp("Invert Console", "The displayed console lines will be inverted, i.e. the newest line is the first line.\n" +
			"If disabled, the newest line is the last line.", "")]
		[ORKEditorInfo(separator=true, labelText="Console Settings")]
		[ORKEditorLayout("type", HUDType.Console)]
		public bool consoleInvert = false;
		
		[ORKEditorHelp("All Console Types", "Display the text of all console types.\n" +
			"If disabled, you can select the console types that will be displayed.", "")]
		[ORKEditorInfo(separator=true)]
		public bool allConsoleTypes = true;
		
		[ORKEditorHelp("Console Type", "Select the console type that will be displayed in this HUD.", "")]
		[ORKEditorInfo(ORKDataType.ConsoleType, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Console Type", "Adds a console type that will be displayed in this HUD.", "", 
			"Remove", "Removes this console type.", "", noRemoveCount=1, isHorizontal=true)]
		[ORKEditorLayout("allConsoleTypes", false, autoInit=true, autoSize=1)]
		public int[] consoleTypeID;
		
		[ORKEditorHelp("Show Tabs", "Show the different console types in the tabs of the GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool consoleTabs = false;
		
		[ORKEditorInfo("Tab Content Layout", "Define the layout of the tab buttons.", "", 
			endFoldout=true)]
		[ORKEditorLayout("consoleTabs", true)]
		public ContentLayout consoleContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		[ORKEditorHelp("Add All Tab", "Add a combined tab for all selected console types.\n" +
			"If disabled, only the single console types are available.", "")]
		public bool consoleAllTab = false;
		
		[ORKEditorHelp("All Tab First", "The 'All Tab' will be displayed as the first tab.\n" +
			"If disabled, the 'All Tab' will be the last tab.", "")]
		[ORKEditorLayout("consoleAllTab", true)]
		public bool consoleAllTabFirst = true;
		
		[ORKEditorInfo("All Tab Button", "Define the tab button used for 'All Tab'.", "", endFoldout=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=4, autoInit=true, autoLangSize=true)]
		public LanguageInfo[] consoleAllButton;
		
		
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Use Name", "Use the name of the combatant as title.", "")]
		[ORKEditorLayout(new string[] {"type", "useTitle"}, 
			new System.Object[] {HUDType.Combatant, true}, 
			endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool titleName = false;
		
		[ORKEditorHelp("Title", "The title of the HUD.", "")]
		[ORKEditorInfo(expandWidth=true, endFoldout=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout(new string[] {"useTitle", "titleName"}, 
			new System.Object[] {true, false}, endCheckGroup=true, 
			autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		
		// display conditions
		[ORKEditorHelp("No Display", "This HUD wont be displayed in the game.\n" +
			"Use this option for HUDs used as templates (e.g. for combatant pages in menu screens).\n" +
			"If disabled, the HUD will be displayed according to it's display conditions.", "")]
		[ORKEditorInfo("Display Conditions", "Set when this HUD will be displayed.", "")]
		public bool noDisplay = false;
		
		// toggle key
		[ORKEditorHelp("Start Toggle State", "If enabled, the HUD will be toggled on when starting the game.\n" +
			"If disabled, the HUD will be toggled off when starting the game.\n" +
			"When using 'Only While Key', the toggle state will be inversed, " +
			"i.e. it will be displayd when the input key is not valid.", "")]
		[ORKEditorInfo(separator=true, labelText="Toggle Key")]
		[ORKEditorLayout("noDisplay", false)]
		public bool toggleStartState = true;
		
		[ORKEditorHelp("Use Toggle Key", "The HUD can be switched on and off using a key.", "")]
		public bool useKey = false;
		
		[ORKEditorHelp("Toggle Key", "Select the key used to toggle this HUD on/off.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useKey", true)]
		public int keyID = 0;
		
		[ORKEditorHelp("Only While Key", "The HUD will only be displayed while the selected toggle key " +
			"is valid (i.e. use a 'Hold' input key, the HUD will be displayed while the key is pressed).\n" +
			"When disabling 'Start Toggle State', the HUD will only be displayed while the selected toggle key is invalid.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool onlyWhileKey = false;
		
		
		// interactions
		[ORKEditorInfo(separator=true, labelText="Interactions")]
		[ORKEditorLayout("type", HUDType.Interaction, autoInit=true)]
		public InteractionCheck interaction;
		
		// interact on click
		[ORKEditorHelp("Interact on Click", "A click on the HUD will start the first available interaction of the selected types.\n" +
			"If disabled, interaction's can't be started through the HUD.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool interactClick = false;
		
		
		// game state
		[ORKEditorInfo(separator=true, labelText="Required Game State")]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {HUDType.Interaction, HUDType.TurnOrder}, 
			needed=Needed.One, elseCheckGroup=true, endCheckGroup=true)]
		public GameState gameState = new GameState(Consider.No);
		
		
		// combatant status requirement
		[ORKEditorHelp("Needed", "Either all or only one status requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		[ORKEditorLayout("type", HUDType.Combatant)]
		public Needed needed = Needed.All;
		
		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.\n" +
			"The HUD will only be displayed for combatants that meet the requirements.", "", 
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		[ORKEditorLayout(endCheckGroup=true)]
		public StatusRequirement[] statusRequirement = new StatusRequirement[0];
		
		
		// variable conditions
		[ORKEditorInfo(separator=true, labelText="Variable Conditions", endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public VariableCondition variableCondition = new VariableCondition();
		
		
		// images
		// background
		[ORKEditorHelp("Show Background", "Display a background image.\n" +
			"The background image will be displayed behind all elements and the GUI box.", "")]
		[ORKEditorInfo("Image Settings", "A HUD can display a background and a foreground image.\n" +
			"The background image will be displayed behind all elements and the GUI box.\n" +
			"The foreground image will be displayed in front of all element and the GUI box.", "", 
			labelText="Background Image Settings")]
		public bool showBackground = false;
		
		[ORKEditorHelp("Relative Position", "The image will be placed relative to the GUI box position.\n" +
			"X=0, Y=0 will be at the upper left corner of the GUI box.", "")]
		[ORKEditorLayout("showBackground", true)]
		public bool bgRelative = true;
		
		[ORKEditorHelp("Relative To", "Select the the corner of the GUI box the image's position will be relative to.", "")]
		[ORKEditorLayout("bgRelative", true, endCheckGroup=true)]
		public TextAnchor bgRelativeTo = TextAnchor.UpperLeft;
		
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public DisplayImage bgImage;
		
		// foreground
		[ORKEditorHelp("Show Foreground", "Display a foreground image.\n" +
			"The foreground image will be displayed in front of all element and the GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Foreground Image Settings")]
		public bool showForeground = false;
		
		[ORKEditorHelp("Relative Position", "The image will be placed relative to the GUI box position.\n" +
			"X=0, Y=0 will be at the upper left corner of the GUI box.", "")]
		[ORKEditorLayout("showForeground", true)]
		public bool fgRelative = true;
		
		[ORKEditorHelp("Relative To", "Select the the corner of the GUI box the image's position will be relative to.", "")]
		[ORKEditorLayout("fgRelative", true, endCheckGroup=true)]
		public TextAnchor fgRelativeTo = TextAnchor.UpperLeft;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public DisplayImage fgImage;
		
		
		
		// hud elements
		// information
		[ORKEditorArray(false, "Add Information Element", "Adds an information element to this HUD.", "", 
			"Remove", "Removes this information element.", "", foldout=true, isMove=true, isCopy=true,  
			foldoutText=new string[] {"Information Element", "Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the GUI box this HUD uses.", ""})]
		[ORKEditorLayout("type", HUDType.Information, endCheckGroup=true, autoInit=true)]
		public HUDText[] infoElement;
		
		// interaction
		[ORKEditorArray(false, "Add Interaction Element", "Adds an interaction element to this HUD.", "", 
			"Remove", "Removes this interaction element.", "", foldout=true, isMove=true, isCopy=true, 
			foldoutText=new string[] {"Interaction Element", "Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the GUI box this HUD uses.", ""})]
		[ORKEditorLayout("type", HUDType.Interaction, endCheckGroup=true, autoInit=true)]
		public HUDInteraction[] interactionElement;
		
		// combatant, turn order
		[ORKEditorArray(false, "Add Status Element", "Adds a status element to this HUD.", "", 
			"Remove", "Removes this status element.", "", foldout=true, isMove=true, isCopy=true, 
			foldoutText=new string[] {"Status Element", "Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the GUI box this HUD uses.", ""})]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {HUDType.Combatant, HUDType.TurnOrder}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public HUDStatus[] combatantElement;
		
		// control
		[ORKEditorArray(false, "Add Control Element", "Adds a control element to this HUD.", "", 
			"Remove", "Removes this control element.", "", foldout=true, isMove=true, isCopy=true, 
			foldoutText=new string[] {"Control Element", "Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the GUI box this HUD uses.", ""})]
		[ORKEditorLayout("type", HUDType.Control, endCheckGroup=true, autoInit=true)]
		public HUDControl[] controlElement;
		
		// navigation
		[ORKEditorArray(false, "Add Navigation Element", "Adds a navigation element to this HUD.", "", 
			"Remove", "Removes this navigation element.", "", foldout=true, isMove=true, isCopy=true, 
			foldoutText=new string[] {"Navigation Element", "Set the position, size, content and background image of this element.\n" +
				"In navigation elements, the coordinates X=0, Y=0 are located at the position of the selected information in the navigation bar.", ""})]
		[ORKEditorLayout("type", HUDType.Navigation, endCheckGroup=true, autoInit=true)]
		public HUDNavigation[] navigationElement;
		
		// tooltip
		[ORKEditorArray(false, "Add Tooltip Element", "Adds a tooltip element to this HUD.", "", 
			"Remove", "Removes this tooltip element.", "", foldout=true, isMove=true, isCopy=true, 
			foldoutText=new string[] {"Tooltip Element", "Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the GUI box this HUD uses.", ""})]
		[ORKEditorLayout("type", HUDType.Tooltip, endCheckGroup=true, autoInit=true)]
		public HUDTooltip[] tooltipElement;
		
		// quest
		[ORKEditorArray(false, "Add Quest Element", "Adds a quest element to this HUD.", "", 
			"Remove", "Removes this quest element.", "", foldout=true, isMove=true, isCopy=true, 
			foldoutText=new string[] {"Quest Element", "Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the GUI box this HUD uses.", ""})]
		[ORKEditorLayout("type", HUDType.Quest, endCheckGroup=true, autoInit=true)]
		public HUDQuest[] questElement;
		
		
		// ingame
		private bool blocked = false;
		
		public HUDSetting()
		{
			
		}
		
		public HUDSetting(string n)
		{
			this.name = n;
			this.infoElement = new HUDText[0];
		}
		
		public GUIBoxContent Create()
		{
			if(HUDType.Control.Equals(this.type))
			{
				return new ControlHUDContent(this);
			}
			else if(HUDType.Navigation.Equals(this.type))
			{
				return new NavigationHUDContent(this);
			}
			else if(HUDType.Console.Equals(this.type))
			{
				List<int> tabTypes = new List<int>();
				
				if(this.allConsoleTypes)
				{
					for(int i=0; i<ORK.ConsoleTypes.Count; i++)
					{
						tabTypes.Add(i);
					}
				}
				else
				{
					tabTypes.AddRange(this.consoleTypeID);
				}
				
				if(this.consoleTabs && this.consoleAllTab)
				{
					if(this.consoleAllTabFirst)
					{
						tabTypes.Insert(0, -1);
					}
					else
					{
						tabTypes.Add(-1);
					}
				}
				
				ConsoleHUDContent content = new ConsoleHUDContent(this, tabTypes);
				
				if(this.consoleTabs)
				{
					ChoiceContent[] cc = new ChoiceContent[tabTypes.Count];
					for(int i=0; i<cc.Length; i++)
					{
						if(tabTypes[i] == -1)
						{
							cc[i] = this.consoleContentLayout.GetChoiceContent(this.consoleAllButton);
						}
						else
						{
							cc[i] = this.consoleContentLayout.GetChoiceContent(ORK.ConsoleTypes.Get(tabTypes[i]));
						}
					}
					content.SetTabs(cc);
				}
				
				return content;
			}
			else if(HUDType.Quest.Equals(this.type))
			{
				return new QuestHUDContent(this);
			}
			else
			{
				return new PrecalcHUDContent(this);
			}
		}
		
		public bool Blocked
		{
			get{ return this.blocked;}
			set{ this.blocked = value;}
		}
		
		
		/*
		============================================================================
		Visibility functions
		============================================================================
		*/
		public bool IsVisible()
		{
			if(!this.blocked && 
			// interaction
				((HUDType.Interaction.Equals(this.type) && 
					!ORK.Control.Blocked && this.interaction.Check()) || 
			// turn order
				(HUDType.TurnOrder.Equals(this.type) && 
					ORK.Battle.IsTurnBased() && ORK.Battle.IsBattleRunning()) || 
			// game state
				(!HUDType.Interaction.Equals(this.type) && 
					!HUDType.TurnOrder.Equals(this.type) && 
					this.gameState.Check())) && 
			// tooltip
				(!HUDType.Tooltip.Equals(this.type) || this.CheckTooltip(ORK.GUI.TooltipContent)) && 
			// variables
				this.variableCondition.CheckVariables())
			{
				return true;
			}
			return false;
		}
		
		public bool CheckFaction(int factionID)
		{
			if((factionID == ORK.GameSettings.playerFactionID && this.player) || 
				(factionID != ORK.GameSettings.playerFactionID && 
				((ORK.Game.Faction.IsEnemy(factionID, ORK.Game.ActiveGroup.FactionID) && this.enemy) || 
				(!ORK.Game.Faction.IsEnemy(factionID, ORK.Game.ActiveGroup.FactionID) && this.ally))))
			{
				return true;
			}
			return false;
		}
		
		public bool CheckTooltip(IContent content)
		{
			if(content is ShopWrapperShortcut)
			{
				content = ((ShopWrapperShortcut)content).Shortcut;
			}
			return content != null && 
				((this.tooltipItem && content is ItemShortcut) || 
				(this.tooltipWeapon && content is EquipShortcut && ((EquipShortcut)content).IsType(EquipSet.Weapon)) || 
				(this.tooltipArmor && content is EquipShortcut && ((EquipShortcut)content).IsType(EquipSet.Armor)) || 
				(this.tooltipMoney && content is MoneyShortcut) || 
				(this.tooltipAbility && content is AbilityShortcut) || 
				(this.tooltipCombatant && content is Combatant) || 
				(this.tooltipSceneObject && content is SceneObject) || 
				(this.tooltipStatusEffects && content is StatusEffect) || 
				(this.tooltipQuest && content is Quest) || 
				(this.tooltipQuestTask && content is QuestTask));
		}
	}
}
