
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Ability", "Displays abilities of a combatant.\n" +
			"The abilities can be separated by ability type.", "")]
	public class AbilityMenuPart : BaseMenuPart, IChoice, ITabChoice, IDragOrigin
	{
		[ORKEditorHelp("Close After Use", "Close this menu screen after using an ability.", "")]
		public bool closeAfter = false;
		
		[ORKEditorHelp("Don't Return", "Don't return to previously opened menu screens when " +
			"closing the screen after using an ability.", "")]
		[ORKEditorLayout("closeAfter", true, endCheckGroup=true)]
		public bool closeAfterNoReturn = false;
		
		[ORKEditorHelp("Use Screen Combatant", "Automatically use abilities on the current menu user.", "")]
		public bool useScreenCom = false;
		
		[ORKEditorHelp("Animate Use", "Using an ability will be animated, " +
			"i.e. it's animation battle events will be performed if set up for the current game mode.", "")]
		public bool animateUse = true;
		
		[ORKEditorHelp("Default Action", "Select the default action when an ability is selected:\n" +
			"- Use: Uses the ability.\n" +
			"- Give: Does nothing.\n" +
			"- Remove: Does nothing.\n" +
			"- Drop: Does nothing.\n" +
			"- Back: Closes the sub menu without doing anything.\n" +
			"- Cancel: Closes the sub menu without doing anything.\n" +
			"- Level Up: Increases the level of the ability with level up type 'Spend' (if enough experience is available).\n" +
			"- Assign Shortcut: Shows a menu to assign an ability to a shortcut slot of the menu user.", "")]
		public SubMenuAction defaultAction = SubMenuAction.Use;
		
		// shortcut menu
		[ORKEditorInfo("Shortcut Menu", "Define the shortcut slots that will be available.", "", endFoldout=true)]
		[ORKEditorLayout("defaultAction", SubMenuAction.AssignShortcut, endCheckGroup=true, autoInit=true)]
		public AssignShortcutMenu shortcutMenu;
		
		
		// type settings
		// available types
		[ORKEditorHelp("All Ability Types", "All ability types will be available.\n" +
			"If disabled, you have to select the ability types that will be available.", "")]
		[ORKEditorInfo("Available Ability Types", "Define what ability types will be displayed in this menu screen.", "")]
		public bool allTypes = true;
		
		public TypeSorter typeSorter = new TypeSorter();
		
		[ORKEditorHelp("Ability Type", "Select the ability type that will be available.", "")]
		[ORKEditorInfo(ORKDataType.AbilityType, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Ability Type", "Adds an ability type that will be available.", "", 
			"Remove", "Removes this ability type.", "", noRemoveCount=1, isHorizontal=true)]
		[ORKEditorLayout("allTypes", false, endCheckGroup=true, autoInit=true, autoSize=1)]
		public int[] availableTypeID;
		
		
		
		// type box settings
		[ORKEditorHelp("Show Type Box", "A type selection box is displayed.\n" +
			"If disabled, no type selection box is displayed, " +
			"but you can change the type using the change type keys.", "")]
		[ORKEditorInfo("Type Box Settings", "Define the content and layout of the ability type box.", "")]
		public bool showTypeBox = true;
		
		[ORKEditorHelp("Show Empty Types", "Empty ability types (without any abilities the combatant knows) " +
			"will be displayed (with inactive buttons).\n" +
			"If disabled, only the ability types available to the combatant will be displayed.", "")]
		public bool showEmptyTypes = false;
		
		[ORKEditorHelp("Merge Types", "Merge all ability types into a single display.\n" +
			"If disabled, only a single ability type will be displayed at a time - " +
			"you can use the type change keys to circle through available types.", "")]
		[ORKEditorLayout("showTypeBox", false, setDefault=true, defaultValue=false)]
		public bool mergeTypes = false;
		
		[ORKEditorHelp("Type Tabs", "Show the ability types as tabs in the ability box.", "")]
		[ORKEditorLayout("mergeTypes", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool typeTabs = false;
		
		[ORKEditorHelp("Display Type>Abilities", "Select the box display mode:\n" +
			"- Same: Types and abilities use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Types and abilities use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Types and abilities use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the abilities will only be displayed when a type was selected.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(elseCheckGroup=true, setDefault=true, defaultValue=MenuBoxDisplay.Multi)]
		public MenuBoxDisplay display = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Type Box", "Select the GUI box used to display the ability types.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("display", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID = 0;
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the ability type list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBackType = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the ability type list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBackType", true, endCheckGroup=true)]
		public bool backFirstType = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used type GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool useTypeTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTypeTitle", true, endCheckGroup=true, endGroups=2, autoInit=true, autoLangSize=true)]
		public string[] typeTitle;
		
		// layout
		[ORKEditorInfo("Type Content Layout", "Define the layout of the ability type buttons.", "", 
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(new string[] {"showTypeBox", "typeTabs"}, new System.Object[] {true, true}, 
			needed=Needed.One, endCheckGroup=true)]
		public ContentLayout typeContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		
		// ability box settings
		[ORKEditorHelp("Ability Box", "Select the GUI box used to display the abilities.\n" +
			"If 'Same' box display is selected, this box will also display the ability types.", "")]
		[ORKEditorInfo("Ability Box Settings", "Define the content and layout of the ability box.", "", 
			isPopup=true, popupType=ORKDataType.GUIBox)]
		public int guiBoxID2 = 0;
		
		[ORKEditorHelp("Show Portraits", "Display the portrait of a selected ability (if available).", "")]
		public bool showAbilityPortraits = false;
		
		[ORKEditorInfo(separator=true)]
		public ContentSorter contentSorter = new ContentSorter();
		
		// display
		[ORKEditorHelp("Add Attacks", "The combatant's base attacks will be added to the list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addAttacks = false;
		
		[ORKEditorHelp("Add Counter", "The combatant's counter attack will be added to the list.", "")]
		public bool addCounter = false;
		
		[ORKEditorHelp("Add Class Ability", "The combatant's class ability will be added to the list.", "")]
		public bool addClass = false;
		
		[ORKEditorHelp("Add Active Abilities", "The combatant's active abilities will be added to the list.", "")]
		public bool addActive = true;
		
		[ORKEditorHelp("Add Passive Abilities", "The combatant's passive abilities will be added to the list.", "")]
		public bool addPassive = true;
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the ability list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBack = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the ability list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBack", true, endCheckGroup=true)]
		public bool backFirst = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used ability GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the ability box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = type name (only if 'Merge Types' isn't selected)"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		// drag+drop
		[ORKEditorHelp("Enable Dragging", "Abilities can be dragged - " +
			"dragging an ability on a combatant will use the ability on the combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Drag and Drop")]
		public bool enableDrag = false;
		
		[ORKEditorHelp("Enable Double Click", "Abilities can be double clicked - " +
			"double clicking on an ability and clicking on a combatant will use the ability on the combatant.", "")]
		public bool enableDoubleClick = false;
		
		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a menu item.", "")]
		public bool enableTooltip = false;
		
		[ORKEditorHelp("Drag Inactive", "Inactive choices (i.e. abilities that can't be used) can be dragged/double clicked.\n" +
			"If disabled, inactive choices can't be dragged or double clicked.", "")]
		[ORKEditorLayout(new string[] {"enableDrag", "enableDoubleClick"}, 
			new System.Object[] {true, true}, needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool dragInactive = false;
		
		// layout
		[ORKEditorInfo("Ability Content Layout", "Define the layout of the ability buttons.", "", 
			endFoldout=true, endFolds=2)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.Info);
		
		
		// ability level changes
		[ORKEditorHelp("Allow Level Change", "Enable changing the use level of abilities.", "")]
		[ORKEditorInfo("Ability Level Keys", "The use level of an ability can be changed by input keys", "")]
		public bool allowLvlChange = false;
		
		[ORKEditorHelp("Increase Level Key", "Select the key used to increase the level of a currently selected ability.\n" +
			"The ability level keys are used to circle through already learned ability levels.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("allowLvlChange", true)]
		public int increaseKey = 0;
		
		[ORKEditorHelp("Decrease Level Key", "Sekect the key used to decrease the level of a currently selected ability.\n" +
			"The ability level keys are used to circle through already learned ability levels.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int decreaseKey = 0;
		
		[ORKEditorHelp("Loop Levels", "The ability level changes will loop, " +
			"i.e. decreasing from level 1 will select the highest learned level, " +
			"increasing at the highest level will select level 1.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool loopLevels = false;
		
		
		// switch type keys
		[ORKEditorHelp("Use Change Keys", "The ability type can be changed by input keys.", "")]
		[ORKEditorInfo("Type Change Keys", "The ability type can be changed by input keys.", "")]
		[ORKEditorLayout("mergeTypes", false, setDefault=true, defaultValue=false)]
		public bool useTypeKeys = false;
		
		[ORKEditorHelp("Next Type", "Select the key used to select the next ability type.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useTypeKeys", true)]
		public int nextTypeKey = 0;
		
		[ORKEditorHelp("Previous Type", "Select the key used to select the previous ability type.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public int prevTypeKey = 0;
		
		
		// sub menu
		[ORKEditorHelp("Use Sub Menu", "A sub menu can be displayed for a selected ability, " +
			"the sub menu can display different choices (e.g. use, level up, etc.).\n" +
			"The sub menu is called by using an input key, if you use the same key as you've used for the 'Accept' key, " +
			"the sub menu will be dispalyed instead of using the selected ability.", "")]
		[ORKEditorInfo("Sub Menu Settings", "A sub menu can be displayed for a selected ability, " +
			"the sub menu can display different choices (e.g. use, level up, etc.).\n" +
			"The sub menu is called by using an input key, if you use the same key as you've used for the 'Accept' key, " +
			"the sub menu will be dispalyed instead of using the selected ability.", "")]
		public bool useSubMenu = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useSubMenu", true, endCheckGroup=true, autoInit=true)]
		public SubMenu subMenu;
		
		
		// level points display
		[ORKEditorHelp("Display Level Points", "Display an ability's level points (if it can be leveld up).", "")]
		[ORKEditorInfo("Level Points Display", "Abilities that can be leveled up can display their " +
			"current level points as text and bar in their menu item.\n" +
			"Level points will only be displayed for abilities that can level up and haven't reached their maximum level yet.", "")]
		public bool displayLevelPoints = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Level Points Element", "Adds a level points element.", "", 
			"Remove", "Removes this level points element.", "", foldout=true, isMove=true, isCopy=true,  
			foldoutText=new string[] {"Level Points Element", "Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the button displaying the ability.", ""})]
		[ORKEditorLayout("displayLevelPoints", true, endCheckGroup=true, autoInit=true)]
		public HUDLevelPoints[] levelPointsElement;
		
		
		// ingame
		private GUIBox box;
		
		private GUIBox box2;
		
		private int tmpTypeID = 0;
		
		private int current = 0;
		
		private int current2 = 0;
		
		private bool exitFlag = false;
		
		private SubMenuItem menuAction;
		
		private bool inActionRefresh = false;
		
		
		// ability types
		private ChoiceContent[] typeChoice;
		
		private int[] typeAction;
		
		private List<int> abilityTypes;
		
		
		// abilities
		private ChoiceContent[] abilityChoice;
		
		private List<AbilityShortcut> abilities;
		
		public AbilityMenuPart()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public override bool Controlable
		{
			get{ return this.IsOpened;}
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool OnScreenCombatant
		{
			get{ return this.useScreenCom;}
		}
		
		public override bool IsOpened
		{
			get
			{
				return (this.box == null || this.box.FadedIn) && 
					(this.box2 == null || this.box2.FadedIn);
			}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null && this.box2 == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			// refresh list when out of action
			if(this.screen.Combatant.Actions.InAction)
			{
				if(!this.inActionRefresh)
				{
					this.inActionRefresh = true;
					this.Refresh();
				}
			}
			else if(this.inActionRefresh)
			{
				this.inActionRefresh = false;
				this.Refresh();
			}
			
			if(this.box2 == origin)
			{
				// ability level change
				if(this.allowLvlChange && this.abilityChoice != null)
				{
					if(ORK.InputKeys.Get(this.increaseKey).GetButton())
					{
						if(this.current2 >= 0 && this.current2 < this.abilityChoice.Length && 
							this.abilities[this.current2] != null && 
							this.abilities[this.current2].ChangeUseLevel(1, this.loopLevels))
						{
							this.box2.Audio.PlayAbilityLevel();
							this.ShowAbilities();
							return true;
						}
					}
					else if(ORK.InputKeys.Get(this.decreaseKey).GetButton())
					{
						if(this.current2 >= 0 && this.current2 < this.abilityChoice.Length && 
							this.abilities[this.current2] != null && 
							this.abilities[this.current2].ChangeUseLevel(-1, this.loopLevels))
						{
							this.box2.Audio.PlayAbilityLevel();
							this.ShowAbilities();
							return true;
						}
					}
				}
				// sub menu call
				if(this.useSubMenu && 
					this.current2 >= 0 && this.current2 < this.abilityChoice.Length && 
					//this.abilityChoice[this.current2].Active && 
					this.abilities[this.current2] != null)
				{
					if(ORK.InputKeys.Get(this.subMenu.keyID).GetButton())
					{
						if(this.subMenu.Show(this.abilities[this.current2], this, this.animateUse))
						{
							origin.Audio.PlayAccept();
						}
						else
						{
							origin.Audio.PlayFail();
						}
						return true;
					}
					else
					{
						for(int i=0; i<this.subMenu.item.Length; i++)
						{
							if(this.subMenu.item[i].useKey && 
								ORK.InputKeys.Get(this.subMenu.item[i].keyID).GetButton())
							{
								if(this.subMenu.item[i].Use(this.abilities[this.current2], this, null, this.animateUse))
								{
									origin.Audio.PlayAccept();
									if(this.closeAfter)
									{
										if(this.closeAfterNoReturn)
										{
											this.screen.Clear();
										}
										this.screen.Close();
									}
								}
								else
								{
									origin.Audio.PlayFail();
								}
								return true;
							}
						}
					}
				}
			}
			if(this.useTypeKeys)
			{
				if(ORK.InputKeys.Get(this.nextTypeKey).GetButton())
				{
					this.ChangeTypeKey(1, origin);
					return true;
				}
				else if(ORK.InputKeys.Get(this.prevTypeKey).GetButton())
				{
					this.ChangeTypeKey(-1, origin);
					return true;
				}
				
			}
			return false;
		}
		
		private void ChangeTypeKey(int change, GUIBox origin)
		{
			origin.Audio.PlayCursorMove();
			if(this.showTypeBox)
			{
				int index = this.current + change;
				if(index < 0)
				{
					index = this.typeChoice.Length - 1;
				}
				else if(index >= this.typeChoice.Length)
				{
					index = 0;
				}
				
				if(this.box != null)
				{
					this.box.Content.Selection = index;
				}
				if(this.box2 == origin)
				{
					this.ShowAbilities();
				}
			}
			else if(this.box2 == origin)
			{
				this.CreateTypeList();
				
				int index = 0;
				for(int i=0; i<this.abilityTypes.Count; i++)
				{
					if(this.abilityTypes[i] == this.tmpTypeID)
					{
						index = i;
						break;
					}
				}
				index += change;
				if(index < 0)
				{
					index = this.abilityTypes.Count - 1;
				}
				else if(index >= this.abilityTypes.Count)
				{
					index = 0;
				}
				this.tmpTypeID = this.abilityTypes[index];
				this.ShowAbilities();
			}
		}
		
		
		/*
		============================================================================
		Choice creation functions
		============================================================================
		*/
		private void CreateTypeList()
		{
			if(this.allTypes)
			{
				if(this.showEmptyTypes)
				{
					this.abilityTypes = new List<int>();
					for(int i=0; i<ORK.AbilityTypes.Count; i++)
					{
						this.abilityTypes.Add(i);
					}
				}
				else
				{
					this.abilityTypes = this.screen.Combatant.Abilities.GetTypes();
				}
			}
			else
			{
				if(this.showEmptyTypes)
				{
					this.abilityTypes = new List<int>(this.availableTypeID);
				}
				else
				{
					this.abilityTypes = new List<int>();
					for(int i=0; i<this.availableTypeID.Length; i++)
					{
						if(this.screen.Combatant.Abilities.HasType(this.availableTypeID[i]))
						{
							this.abilityTypes.Add(this.availableTypeID[i]);
						}
					}
				}
			}
			this.typeSorter.Sort(ref this.abilityTypes, ORKDataType.AbilityType);
		}
		
		private void CreateTypeChoices()
		{
			this.typeChoice = null;
			this.typeAction = null;
			
			if(this.screen.Combatant != null)
			{
				this.CreateTypeList();
				
				List<ChoiceContent> cc = new List<ChoiceContent>();
				List<int> ca = new List<int>();
				
				// back first
				if(this.addBackType && this.backFirstType)
				{
					cc.Add(this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					ca.Add(-1);
				}
				
				// types
				for(int i=0; i<this.abilityTypes.Count; i++)
				{
					ChoiceContent content = this.typeContentLayout.GetChoiceContent(ORK.AbilityTypes.Get(this.abilityTypes[i]));
					if(this.showEmptyTypes)
					{
						content.Active = this.screen.Combatant.Abilities.HasType(this.abilityTypes[i]);
					}
					cc.Add(content);
					ca.Add(this.abilityTypes[i]);
				}
				
				// back last
				if(this.addBackType && !this.backFirstType)
				{
					cc.Add(this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					ca.Add(-1);
				}
				
				this.typeChoice = cc.ToArray();
				this.typeAction = ca.ToArray();
			}
		}
		
		private void CreateAbilityChoices()
		{
			this.abilities = null;
			this.abilityChoice = null;
			
			if(this.menuAction == null)
			{
				this.menuAction = SubMenuItem.Create(this.defaultAction);
				if(SubMenuAction.AssignShortcut.Equals(this.defaultAction))
				{
					this.menuAction.shortcutMenu = this.shortcutMenu;
				}
			}
			
			if(this.screen.Combatant != null)
			{
				if(!this.showTypeBox && !this.mergeTypes && this.typeTabs)
				{
					this.CreateTypeChoices();
				}
				
				// abilities
				if((this.showTypeBox || (!this.mergeTypes && this.typeTabs)) && 
					this.current >= 0 && this.current < this.typeAction.Length && 
					this.typeAction[this.current] != -1)
				{
					this.abilities = this.screen.Combatant.Abilities.GetByType(this.typeAction[this.current], 
						this.addAttacks, this.addCounter, this.addClass, this.addActive, this.addPassive);
				}
				else if(!this.showTypeBox && this.mergeTypes)
				{
					this.abilities = this.screen.Combatant.Abilities.GetByType(-1, 
						this.addAttacks, this.addCounter, this.addClass, this.addActive, this.addPassive);
				}
				else
				{
					this.abilities = this.screen.Combatant.Abilities.GetByType(this.tmpTypeID, 
						this.addAttacks, this.addCounter, this.addClass, this.addActive, this.addPassive);
				}
				
				if(this.abilities != null)
				{
					this.contentSorter.Sort(ref this.abilities);
					
					List<ChoiceContent> cc = new List<ChoiceContent>();
					
					// back first
					if(this.addBack && this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.abilities.Insert(0, null);
					}
					
					// abilities
					for(int i=0; i<this.abilities.Count; i++)
					{
						if(this.abilities[i] != null)
						{
							if(this.abilities[i].Setting.hidden)
							{
								this.abilities.RemoveAt(i--);
							}
							else
							{
								ChoiceContent content = this.contentLayout.GetChoiceContent(this.abilities[i], this.screen.Combatant);
								content.Active = (!SubMenuAction.Use.Equals(this.defaultAction) || 
									(this.abilities[i].IsUseable(UseableIn.Field) && 
										!this.abilities[i].TargetEnemy() && 
										!this.screen.Combatant.Actions.InAction)) && 
									this.menuAction.CanUse(this.abilities[i], this);
								
								if(this.showAbilityPortraits && this.abilities[i].HasPortrait())
								{
									content.portrait = this.abilities[i].GetPortrait();
								}
								
								// drag and drop, tooltip, level points display
								content.isDragable = this.enableDrag;
								content.isDoubleClick = this.enableDoubleClick;
								content.isTooltip = this.enableTooltip;
								content.dragInactive = this.dragInactive;
								if(content.isDragable || content.isDoubleClick || content.isTooltip || 
									(this.displayLevelPoints && this.abilities[i].CanLevelUp()))
								{
									content.drag = this.abilities[i].GetDrag(this, this.screen.Combatant);
									if(content.drag != null && this.displayLevelPoints && 
										this.abilities[i].CanLevelUp())
									{
										content.drag.LevelPointsDisplay = this.levelPointsElement;
									}
								}
								cc.Add(content);
							}
						}
					}
					
					// back last
					if(this.addBack && !this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.abilities.Add(null);
					}
					
					this.abilityChoice = cc.ToArray();
				}
			}
		}
		
		
		/*
		============================================================================
		Screen functions
		============================================================================
		*/
		public override bool ShowFirstDescription()
		{
			if(this.box != null && this.typeChoice != null && 
				this.current >= 0 && this.current < this.typeChoice.Length)
			{
				this.screen.ShowDescription(
					this.typeChoice[this.current].description, 
					this.typeChoice[this.current].Content.text, 
					this.typeAction[this.current] != -1 ? 
						ORK.AbilityTypes.Get(this.typeAction[this.current]) : null);
				return true;
			}
			if(this.box2 != null && this.abilityChoice != null && 
				this.current2 >= 0 && this.current2 < this.abilityChoice.Length)
			{
				this.screen.ShowDescription(
					this.abilityChoice[this.current2].description, 
					this.abilityChoice[this.current2].Content.text, 
					this.abilities[this.current2]);
				return true;
			}
			return false;
		}
		
		public override bool FocusFirst()
		{
			if(this.box != null)
			{
				this.box.SetFocus();
				return true;
			}
			else if(this.box2 != null)
			{
				this.box2.SetFocus();
				return true;
			}
			return false;
		}
		
		public override bool IsFocused()
		{
			return (this.box != null && this.box.Focused) || 
				(this.box2 != null && this.box2.Focused);
		}
		
		public override void Refresh()
		{
			if(this.box != null)
			{
				this.ShowTypes();
			}
			if(this.box2 != null)
			{
				this.ShowAbilities();
			}
		}
		
		public override void Show(MenuScreen s)
		{
			this.screen = s;
			this.CreateTypeList();
			this.tmpTypeID = this.abilityTypes.Count > 0 ? this.abilityTypes[0] : 0;
			
			if(this.showTypeBox && 
				MenuBoxDisplay.Same.Equals(this.display))
			{
				this.guiBoxID = this.guiBoxID2;
			}
			
			this.screen.Combatant.Changed += this.CombatantChanged;
			
			this.Show();
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			old.Changed -= this.CombatantChanged;
			this.screen.Combatant.Changed += this.CombatantChanged;
			this.Refresh();
		}
		
		public override void CloseImmediate()
		{
			this.screen.Combatant.Changed -= this.CombatantChanged;
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
			if(this.box2 != null)
			{
				this.box2.SetOutDone();
				this.box2 = null;
			}
		}
		
		public override void Close()
		{
			this.screen.Combatant.Changed -= this.CombatantChanged;
			this.exitFlag = true;
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
			if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
			{
				this.box2.InitOut();
			}
		}
		
		public void CombatantChanged(Combatant c)
		{
			this.Refresh();
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			if(!this.screen.RememberSelection)
			{
				this.current = 0;
				this.current2 = 0;
			}
			
			// type choice and abilities
			if(this.showTypeBox)
			{
				this.ShowTypes();
				
				if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowAbilities();
				}
				
				this.box.SetFocus();
				this.SelectionChanged(this.current, this.box);
			}
			// only abilities
			else
			{
				this.ShowAbilities();
			}
		}
		
		public void FocusGained(GUIBox origin)
		{
			if(this.box == origin && !this.box.FadingOut && !this.box.FadedOut && 
				this.typeChoice != null && 
				this.current >= 0 && this.current < this.typeChoice.Length)
			{
				this.screen.ShowDescription(
					this.typeChoice[this.current].description, 
					this.typeChoice[this.current].Content.text, 
					this.typeAction[this.current] != -1 ? 
						ORK.AbilityTypes.Get(this.typeAction[this.current]) : null);
			}
			else if(this.box2 == origin && !this.box2.FadingOut && !this.box2.FadedOut && 
				this.abilityChoice != null && 
				this.current2 >= 0 && this.current2 < this.abilityChoice.Length)
			{
				this.screen.ShowDescription(
					this.abilityChoice[this.current2].description, 
					this.abilityChoice[this.current2].Content.text, 
					this.abilities[this.current2]);
			}
		}
		
		public void FocusLost(GUIBox origin)
		{
			if(this.box2 == origin && !this.box2.FadingOut && 
				this.showTypeBox && 
				MenuBoxDisplay.Sequence.Equals(this.display))
			{
				this.box2.InitOut();
			}
		}
		
		private void ShowTypes()
		{
			this.CreateTypeChoices();
			
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.inPause = this.screen.pauseGame;
				this.box.InitIn();
			}
			
			ValueHelper.Limit(ref this.current, 0, this.typeChoice.Length - 1);
			
			if(this.box.Content == null)
			{
				this.box.Content = new DialogueContent("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this, this.current);
			}
			else
			{
				((DialogueContent)this.box.Content).Update("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this.current, null, null);
			}
			if(this.box.Focused)
			{
				this.SelectionChanged(this.current, this.box);
			}
		}
		
		private void ShowAbilities()
		{
			this.CreateAbilityChoices();
			
			if(this.box2 == null || this.box2.FadingOut || this.box2.FadedOut)
			{
				this.box2 = ORK.GUIBoxes.Create(this.guiBoxID2);
				this.box2.inPause = this.screen.pauseGame;
				this.box2.InitIn();
			}
			
			if(this.abilityChoice == null)
			{
				this.current2 = 0;
			}
			else
			{
				ValueHelper.Limit(ref this.current2, 0, this.abilityChoice.Length - 1);
			}
			
			if(this.box2.Content == null)
			{
				this.box2.Content = new DialogueContent("", this.GetTitle(), 
					this.abilityChoice, this, this.current2);
			}
			else
			{
				((DialogueContent)this.box2.Content).Update("", this.GetTitle(), 
					this.abilityChoice, this.current2, null, null);
			}
			
			if(!this.showTypeBox && !this.mergeTypes && this.typeTabs)
			{
				this.box2.Content.SetTabs(this.typeChoice);
			}
			if(this.box2.Focused)
			{
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		private string GetTitle()
		{
			if(this.useTitle)
			{
				if(this.showTypeBox && this.typeChoice != null && 
					this.current >= 0 && this.current < this.typeChoice.Length && 
					this.typeAction[this.current] != -1)
				{
					return this.title[ORK.Game.Language].Replace("%n", this.typeChoice[this.current].Content.text);
				}
				else if(!this.showTypeBox && !this.mergeTypes)
				{
					return this.title[ORK.Game.Language].Replace("%n", ORK.AbilityTypes.GetName(this.tmpTypeID));
				}
				else
				{
					return this.title[ORK.Game.Language].Replace("%n", "");
				}
			}
			return "";
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.exitFlag)
			{
				if(this.box == origin)
				{
					this.box = null;
				}
				else if(this.box2 == origin)
				{
					this.box2 = null;
				}
				if(this.box == null && this.box2 == null)
				{
					this.exitFlag = false;
				}
			}
			else
			{
				// type switch to ability
				if(this.box == origin)
				{
					this.box = null;
					if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowAbilities();
					}
				}
				// ability
				else if(this.box2 == origin)
				{
					this.box2 = null;
					if(this.showTypeBox && 
						MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowTypes();
					}
				}
			}
		}
		
		public override void CombatantChoiceClosed(bool canceled)
		{
			this.Refresh();
			if(!canceled && this.closeAfter)
			{
				if(this.closeAfterNoReturn)
				{
					this.screen.Clear();
				}
				this.screen.Close();
			}
			else if(this.box2 != null)
			{
				this.box2.SetFocus();
			}
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			// type
			if(this.box == origin && this.typeChoice != null && 
				index >= 0 && index < this.typeChoice.Length)
			{
				if(this.current != index)
				{
					this.SelectionChanged(index, origin);
				}
				
				this.current = index;
				
				if(this.typeAction[this.current] == -1)
				{
					this.Cancel(this.box);
				}
				else
				{
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box2 = this.box;
						this.box = null;
						this.ShowAbilities();
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box2.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.ShowAbilities();
					}
				}
			}
			// ability
			else if(this.box2 == origin && this.abilityChoice != null && 
				index >= 0 && index < this.abilityChoice.Length)
			{
				this.current2 = index;
				if(this.abilities[this.current2] == null)
				{
					this.Cancel(this.box2);
				}
				else if(this.menuAction.Use(this.abilities[index], this, null, this.animateUse))
				{
					if(this.closeAfter)
					{
						if(this.closeAfterNoReturn)
						{
							this.screen.Clear();
						}
						this.screen.Close();
					}
					else
					{
						this.Refresh();
					}
				}
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				if(this.typeChoice != null && 
					index >= 0 && index < this.typeChoice.Length)
				{
					this.screen.ShowDescription(
						this.typeChoice[index].description, 
						this.typeChoice[index].Content.text, 
						this.typeAction[index] != -1 ? 
							ORK.AbilityTypes.Get(this.typeAction[index]) : null);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				
				this.current = index;
				if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowAbilities();
				}
			}
			// ability
			else if(this.box2 == origin)
			{
				if(this.abilityChoice != null && 
					index >= 0 && index < this.abilityChoice.Length)
				{
					this.screen.ShowDescription(
						this.abilityChoice[index].description, 
						this.abilityChoice[index].Content.text, 
						this.abilities[index]);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				this.current2 = index;
			}
		}
		
		public void TabChanged(int index, GUIBox box)
		{
			if(this.box2 == box)
			{
				this.current = index;
				this.ShowAbilities();
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.Cancel(origin);
		}
		
		private void Cancel(GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				this.screen.Close();
			}
			// ability
			else if(this.box2 == origin)
			{
				if(this.showTypeBox)
				{
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box = this.box2;
						this.box2 = null;
						this.ShowTypes();
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box2.InitOut();
						
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.box2.InitOut();
						this.box.SetFocus();
					}
				}
				else
				{
					this.screen.Close();
				}
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public void Dropped(DragInfo drag)
		{
			this.Refresh();
		}
		
		public bool DroppedOnCombatant(Combatant c, DragInfo drag)
		{
			if(drag.UseOn(c, this.animateUse))
			{
				this.Refresh();
				if(this.closeAfter)
				{
					if(this.closeAfterNoReturn)
					{
						this.screen.Clear();
					}
					this.screen.Close();
				}
				return true;
			}
			return false;
		}
		
		public bool DroppedToWorld(Vector3 position, DragInfo drag)
		{
			return false;
		}
	}
}
