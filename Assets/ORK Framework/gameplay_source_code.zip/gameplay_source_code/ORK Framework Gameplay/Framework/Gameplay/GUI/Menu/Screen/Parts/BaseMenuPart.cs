
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	public static class MenuPartHelper
	{
		public static Dictionary<System.Type, string[]> GetSteps()
		{
			Dictionary<System.Type, string[]> list = new Dictionary<System.Type, string[]>();
			System.Type[] types = System.Reflection.Assembly.GetExecutingAssembly().GetTypes();
			foreach(System.Type type in types)
			{
				if(type.Namespace == "ORKFramework.Menu.Parts")
				{
					System.Object[] attr = type.GetCustomAttributes(typeof(ORKEditorHelpAttribute), true);
					if(attr.Length > 0)
					{
						list.Add(type, ((ORKEditorHelpAttribute)attr[0]).text);
					}
				}
			}
			return list;
		}
	}
	
	public abstract class BaseMenuPart : CoreMenuPart
	{
		protected MenuScreen screen;
		
		public MenuScreen Screen
		{
			get{ return this.screen;}
			set{ this.screen = value;}
		}
		
		public virtual bool OnScreenCombatant
		{
			get{ return false;}
		}
		
		public virtual bool ShowFirstDescription()
		{
			return false;
		}
		
		public virtual bool FocusFirst()
		{
			return false;
		}
		
		public abstract bool IsFocused();
		
		public abstract void Refresh();
		
		public abstract void Show(MenuScreen s);
		
		public abstract void ChangeCombatant(Combatant old);
		
		public abstract void CloseImmediate();
		
		public abstract void Close();
		
		public abstract bool IsOpened
		{
			get;
		}
		
		public abstract bool IsClosed
		{
			get;
		}
		
		public virtual bool Controlable
		{
			get{ return false;}
		}
		
		public virtual void CombatantChoiceClosed(bool canceled)
		{
			
		}
		
		public virtual void SubMenuClosed(bool canceled)
		{
			
		}
	}
}
