
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Button List", "Displays list of menu items which can call other menu screens, the save/load menu or exit to the main menu.", "")]
	public class ButtonListMenuPart : BaseMenuPart, IChoice
	{
		[ORKEditorHelp("Close On Select", "The menu screen is closed when selecting a menu item.\n" +
			"If disabled, the menu screen will stay opened if no 'single screen' type is called.", "")]
		public bool close = false;
		
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the button list.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox, separator=true)]
		public int guiBoxID = 0;
		
		[ORKEditorInfo("Button Content Layout", "Define the layout of the buttons.", "", 
			endFoldout=true, separatorForce=true)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the button list.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the menu item list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBack = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBack", true, endCheckGroup=true)]
		public bool backFirst = false;
		
		
		// items
		[ORKEditorArray(false, "Add Menu Item", "Adds a menu item.", "", 
			"Remove", "Removes this menu item.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Menu Item", "Define the content and action of this menu item.", ""})]
		public MenuScreenItem[] item = new MenuScreenItem[0];
		
		
		// ingame
		private GUIBox box;
		
		private int current = 0;
		
		private ChoiceContent[] choice;
		
		private int[] choiceAction;
		
		private bool[] lastCheck;
		
		private float lastTime = 0;
		
		private bool canceled = false;
		
		public ButtonListMenuPart()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public override bool Controlable
		{
			get{ return this.IsOpened;}
		}
		
		
		/*
		============================================================================
		Menu button functions
		============================================================================
		*/
		public override bool IsOpened
		{
			get{ return this.box == null || this.box.FadedIn;}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			if((Time.realtimeSinceStartup - this.lastTime) > 10)
			{
				for(int i=0; i<this.item.Length; i++)
				{
					bool check = !this.item[i].useReq || ORK.Requirements.Get(this.item[i].reqID).Check();
					if(this.lastCheck[i] != check)
					{
						this.Show(this.screen);
						break;
					}
				}
				this.lastTime = Time.realtimeSinceStartup;
			}
			return false;
		}
		
		public override bool ShowFirstDescription()
		{
			if(this.box != null && this.choice != null && 
				this.current >= 0 && this.current < this.choice.Length)
			{
				this.screen.ShowDescription(
					this.choice[this.current].description, 
					this.choice[this.current].Content.text, null);
				return true;
			}
			return false;
		}
		
		public override bool FocusFirst()
		{
			if(this.box != null)
			{
				this.box.SetFocus();
				return true;
			}
			return false;
		}
		
		public override bool IsFocused()
		{
			return this.box != null && this.box.Focused;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void Refresh()
		{
			this.Show();
		}
		
		public override void Show(MenuScreen s)
		{
			this.screen = s;
			if(!this.screen.RememberSelection)
			{
				this.current = 0;
			}
			this.canceled = false;
			this.Show();
		}
		
		public void Show()
		{
			this.choice = null;
			this.choiceAction = null;
			
			// create choices
			List<ChoiceContent> cc = new List<ChoiceContent>();
			List<int> ca = new List<int>();
			this.lastCheck = new bool[this.item.Length];
			
			// back first
			if(this.addBack && this.backFirst)
			{
				cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
				ca.Add(-1);
			}
			
			for(int i=0; i<this.item.Length; i++)
			{
				ChoiceContent content = this.contentLayout.GetChoiceContent(this.item[i].button);
				content.Active = !this.item[i].useReq || ORK.Requirements.Get(this.item[i].reqID).Check();
				this.lastCheck[i] = content.Active;
				
				if(content.Active || !this.item[i].reqHide)
				{
					cc.Add(content);
					ca.Add(i);
				}
			}
					
			// back last
			if(this.addBack && !this.backFirst)
			{
				cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
				ca.Add(-1);
			}
			
			this.choice = cc.ToArray();
			this.choiceAction = ca.ToArray();
			this.lastTime = Time.realtimeSinceStartup;
			
			// init box
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.inPause = this.screen.pauseGame;
				this.box.InitIn();
			}
			
			// init content
			this.box.Content = new DialogueContent("", 
				this.useTitle ? this.title[ORK.Game.Language] : "", 
				this.choice, this, this.current);
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			
		}
		
		public override void CloseImmediate()
		{
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
		}
		
		public override void Close()
		{
			this.canceled = true;
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
		}

		public void Closed(GUIBox origin)
		{
			if(!this.canceled && this.close)
			{
				this.item[this.choiceAction[this.current]].Selected(this.screen);
			}
			this.canceled = false;
			this.box = null;
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			if(index >= 0 && index < this.choice.Length)
			{
				this.current = index;
				if(this.choiceAction[this.current] == -1)
				{
					this.screen.Close();
				}
				else if(this.item[this.choiceAction[this.current]].selectCom)
				{
					this.item[this.choiceAction[this.current]].CallCombatantSelection(this);
				}
				else if(this.close || this.item[this.choiceAction[this.current]].IsCallSingleScreen())
				{
					this.screen.Close(this.item[this.choiceAction[this.current]]);
				}
				else
				{
					this.item[this.choiceAction[this.current]].Selected(this.screen);
				}
			}
		}
		
		public override void CombatantChoiceClosed(bool canceled)
		{
			if(canceled)
			{
				this.box.SetFocus();
			}
			else
			{
				if(this.close || this.item[this.choiceAction[this.current]].IsCallSingleScreen())
				{
					this.screen.Close(this.item[this.choiceAction[this.current]]);
				}
				else
				{
					this.item[this.choiceAction[this.current]].Selected(this.screen);
				}
			}
		}

		public void SelectionChanged(int index, GUIBox origin)
		{
			if(index >= 0 && index < this.choice.Length)
			{
				this.current = index;
				if(this.choiceAction[this.current] == -1)
				{
					this.screen.ShowDescription("", "", null);
				}
				else
				{
					this.screen.ShowDescription(this.choice[index].description, this.choice[index].Content.text, null);
				}
			}
		}

		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.screen.Close();
		}
		
		
		/*
		============================================================================
		Unused choice interface functions
		============================================================================
		*/
		public void FocusGained(GUIBox origin)
		{
			
		}

		public void FocusLost(GUIBox origin)
		{
			
		}
	}
}
