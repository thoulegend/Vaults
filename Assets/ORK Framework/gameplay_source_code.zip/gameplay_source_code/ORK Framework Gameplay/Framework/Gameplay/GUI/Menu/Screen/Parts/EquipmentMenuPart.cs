
using UnityEngine;
using ORKFramework;
using ORKFramework.Menu;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Equipment", "Displays the equipment of a combatant.\n" +
			"The equipment parts a combatant can access are displayed, weapons and armors can be equipped at each equipment part.", "")]
	public class EquipmentMenuPart : BaseMenuPart, IChoiceDrop, IDragOrigin, IQuantityCallback
	{
		// type settings
		// available types
		[ORKEditorHelp("All Equipment Parts", "All equipment parts will be displayed.\n" +
			"If disabled, you have to select the equipment parts that will be displayed.", "")]
		[ORKEditorInfo("Available Equipment Parts", "Define what equipment parts will be displayed in this menu screen.", "")]
		public bool allTypes = true;
		
		public TypeSorter typeSorter = new TypeSorter();
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be available.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Equipment Part", "Adds an equipment part that will be available.", "", 
			"Remove", "Removes this equipment part.", "", noRemoveCount=1, isHorizontal=true)]
		[ORKEditorLayout("allTypes", false, endCheckGroup=true, autoInit=true, autoSize=1)]
		public int[] availableTypeID;
		
		
		
		// type box settings
		[ORKEditorHelp("Equipment Part Box", "Select the GUI box used to display the equipment parts.", "")]
		[ORKEditorInfo("Part Box Settings", "Define the content and layout of the equipment part box.", "", 
			isPopup=true, popupType=ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		[ORKEditorHelp("Show All Parts", "Equipment parts not available to the combatant will be displayed (with inactive buttons).\n" +
			"If disabled, only the equipment parts available to the combatant will be displayed.", "")]
		[ORKEditorLayout(elseCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool showEmptyTypes = false;
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the equipment part list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBackType = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the equipment part list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBackType", true, endCheckGroup=true)]
		public bool backFirstType = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used equipment part GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTypeTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTypeTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] typeTitle;
		
		// layout
		[ORKEditorInfo("Part Content Layout", "Define the layout of the equipment part buttons.", "", 
			endFoldout=true)]
		public TitleContentLayout typeContentLayout = new TitleContentLayout(
			ContentLayoutType.Both, ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		// empty button
		[ORKEditorInfo("Empty Button", "The empty button is displayed when an equipment part has nothing equipped.", "", 
			endFoldout=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageInfo[] emptyButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Empty"});
		
		// drag/drop equipment parts
		[ORKEditorHelp("Enable Dragging", "Equipment parts can be dragged.\n" +
			"Dragging an equipment from an equipment part will unequip it.", "")]
		[ORKEditorInfo("Drag and Drop", "Equipment parts can be unequipped by dragging or double clicking.", "")]
		public bool enableDrag = false;
		
		[ORKEditorHelp("Enable Double Click", "Equipment parts can be double clicked.\n" +
			"Double clicking on an equipment part and clicking somewhere else (e.g. inventory) will unequip it.", "")]
		public bool enableDoubleClick = false;
		
		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a menu item.", "")]
		public bool enableTooltip = false;
		
		// drop give
		[ORKEditorHelp("Give On Drop", "When dropping or clicking on a combatant, " +
			"weapons/armors are given to the combatant instead of equipping them on the combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Drop Give")]
		[ORKEditorLayout(new string[] {"enableDrag", "enableDoubleClick"}, 
			new System.Object[] {true, true}, needed=Needed.One)]
		public bool dropGive = false;
		
		[ORKEditorLayout("dropGive", true, endCheckGroup=true, autoInit=true)]
		public QuantityCall giveQuantity;
		
		// world drop
		[ORKEditorHelp("Drop To World", "Weapons/armors will be dropped into the game world if they aren't " +
			"dropped on an inventory, combatant or interaction.", "")]
		[ORKEditorInfo(separator=true, labelText="World Drop")]
		public bool dropToWorld = false;
		
		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		[ORKEditorLayout("dropToWorld", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public QuantityCall dropQuantity;
		
		
		
		// weapon/armor box settings
		[ORKEditorHelp("Show Equip Box", "A weapon/armor selection box is displayed.\n" +
			"If disabled, no weapon/armor selection box is displayed, " +
			"but you can change the equipment by using an inventory menu part and enabling drag/drop.", "")]
		[ORKEditorInfo("Equipment Box Settings", "Define the content and layout of the equipment box.", "")]
		public bool showEquipBox = true;
		
		[ORKEditorHelp("Display Part>Equipment", "Select the box display mode:\n" +
			"- Same: Equipment parts and weapons/armors use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Equipment parts and weapons/armors use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Equipment parts and weapons/armors use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the weapons/armors will only be displayed when a type was selected.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("showEquipBox", true, setDefault=true, defaultValue=MenuBoxDisplay.Multi)]
		public MenuBoxDisplay display = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Weapon/Armor Box", "Select the GUI box used to display the weapons and armors.\n" +
			"If 'Same' box display is selected, this box will also display the equipment parts.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("display", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID2 = 0;
		
		[ORKEditorHelp("Show Portraits", "Display the portrait of a selected equipment (if available).", "")]
		public bool showEquipPortraits = false;
		
		[ORKEditorHelp("All Weapons/Armors", "All weapons/armors in the combatant's inventory will be displayed.\n" +
			"Unequipable weapons/armors will be inactive.\n" +
			"If disabled, only equipment that can be equipped by the combatant will be displayed.", "")]
		public bool allEquipment = false;
		
		[ORKEditorInfo(separator=true)]
		public ContentSorter contentSorter = new ContentSorter();
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the weapon/armor list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBack = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the weapon/armor list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBack", true, endCheckGroup=true)]
		public bool backFirst = false;
		
		// unequip button
		[ORKEditorHelp("Add Unequip", "An unequip button will be added to the weapon/armor list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addUnequip = false;
		
		[ORKEditorHelp("First Element", "The unequip button will be the first element in the weapon/armor list.\n" +
			"If disabled, the unequip button will be the last element.", "")]
		[ORKEditorLayout("addUnequip", true, endCheckGroup=true)]
		public bool unequipFirst = false;
		
		[ORKEditorHelp("Unequip First", "If both 'Back' and 'Unequip' are displayed first or last in the list, " +
			"the 'Unequip' button will be added before the 'Back' button.\n" +
			"If disabled, the 'Back' button will be before the 'Unequip' button.", "")]
		[ORKEditorLayout(new string[] {"addBack", "addUnequip"}, 
			new System.Object[] {true, true}, needed=Needed.All, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool unequipBeforeBack = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used weapon/armor GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the weapon/armor box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = type name (only if 'Merge Types' isn't selected)"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		// layout
		[ORKEditorInfo("Equipment Content Layout", "Define the layout of the equipment buttons.", "", 
			endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.Info);
		
		// drag/drop weapons/armors
		[ORKEditorHelp("Enable Dragging", "Weapons/armors can be dragged.\n" +
			"Dragging an equipment on a equipment part slot will equip it on the part.\n" +
			"Dragging an equipment on a combatant will equip it on the combatant or give it to the combatant.", "")]
		[ORKEditorInfo("Drag and Drop", "Weapons and armors can be dropped or equipped using dragging or double clicking.", "")]
		[ORKEditorLayout("showEquipBox", true)]
		public bool equipEnableDrag = false;
		
		[ORKEditorHelp("Enable Double Click", "Weapons/armors can be double clicked.\n" +
			"Double clicking on an equipment and clicking on a equipment part slot will equip it on the part.\n" +
			"Double clicking on an equipment and clicking on a combatant will equip it on the combatant or give it to the combatant.", "")]
		public bool equipEnableDoubleClick = false;
		
		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a menu item.", "")]
		public bool equipEnableTooltip = false;
		
		// drop give
		[ORKEditorHelp("Give On Drop", "Weapons/armors are given to a combatant, instead of equipping them on the combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Drop Give")]
		[ORKEditorLayout(new string[] {"equipEnableDrag", "equipEnableDoubleClick"}, 
			new System.Object[] {true, true}, needed=Needed.One)]
		public bool equipDropGive = false;
		
		[ORKEditorLayout("equipDropGive", true, endCheckGroup=true, autoInit=true)]
		public QuantityCall equipGiveQuantity;
		
		// world drop
		[ORKEditorHelp("Drop To World", "Weapons/armors will be dropped into the game world if they aren't " +
			"dropped on a equipment part slot, combatant or interaction.", "")]
		[ORKEditorInfo(separator=true, labelText="World Drop")]
		public bool equipDropToWorld = false;
		
		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		[ORKEditorLayout("equipDropToWorld", true, endCheckGroup=true, endGroups=3, autoInit=true)]
		public QuantityCall equipDropQuantity;
		
		
		// sub menu
		[ORKEditorHelp("Use Sub Menu", "A sub menu can be displayed for a selected weapon/armor, " +
			"the sub menu can display different choices (e.g. equip, remove, etc.).\n" +
			"The sub menu is called by using an input key, if you use the same key as you've used for the 'Accept' key, " +
			"the sub menu will be dispalyed instead of equipping the selected weapon/armor.", "")]
		[ORKEditorInfo("Sub Menu Settings", "A sub menu can be displayed for a selected weapon/armor, " +
			"the sub menu can display different choices (e.g. equip, remove, etc.).\n" +
			"The sub menu is called by using an input key, if you use the same key as you've used for the 'Accept' key, " +
			"the sub menu will be dispalyed instead of equipping the selected weapon/armor.", "")]
		[ORKEditorLayout("showEquipBox", true, setDefault=true, defaultValue=false)]
		public bool useSubMenu = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useSubMenu", true, endCheckGroup=true, autoInit=true, endGroups=2)]
		public SubMenu subMenu;
		
		
		// level points display parts
		[ORKEditorHelp("Display Level Points", "Display an equipment's level points (if it can be leveld up).", "")]
		[ORKEditorInfo("Level Points Display (Parts)", "Equipment that can be leveled up can display their " +
			"current level points as text and bar in their menu item.\n" +
			"Level points will only be displayed for equipment that can level up and haven't reached their maximum level yet.\n" +
			"Will be displayed in the equipment parts box.", "", separatorForce=true)]
		public bool displayLevelPoints = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Level Points Element", "Adds a level points element.", "", 
			"Remove", "Removes this level points element.", "", foldout=true, isMove=true, isCopy=true,  
			foldoutText=new string[] {"Level Points Element", "Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the button displaying the ability.", ""})]
		[ORKEditorLayout("displayLevelPoints", true, endCheckGroup=true, autoInit=true)]
		public HUDLevelPoints[] levelPointsElement;
		
		
		// level points display list
		[ORKEditorHelp("Display Level Points", "Display an equipment's level points (if it can be leveld up).", "")]
		[ORKEditorInfo("Level Points Display (List)", "Equipment that can be leveled up can display their " +
			"current level points as text and bar in their menu item.\n" +
			"Level points will only be displayed for equipment that can level up and haven't reached their maximum level yet.\n" +
			"Will be displayed in the weapons/armors list.", "", separatorForce=true)]
		public bool displayLevelPointsList = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Level Points Element", "Adds a level points element.", "", 
			"Remove", "Removes this level points element.", "", foldout=true, isMove=true, isCopy=true,  
			foldoutText=new string[] {"Level Points Element", "Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the button displaying the ability.", ""})]
		[ORKEditorLayout("displayLevelPointsList", true, endCheckGroup=true, autoInit=true)]
		public HUDLevelPoints[] levelPointsElementList;
		
		
		// ingame
		private GUIBox box;
		
		private GUIBox box2;
		
		private int tmpTypeID = 0;
		
		private int current = 0;
		
		private int current2 = 0;
		
		private bool exitFlag = false;
		
		
		// equipment parts
		private ChoiceContent[] typeChoice;
		
		private int[] typeAction;
		
		private List<int> equipmentParts;
		
		
		// items/equipments
		private ChoiceContent[] equipChoice;
		
		private List<EquipShortcut> equips;
		
		public EquipmentMenuPart()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public override bool Controlable
		{
			get{ return this.IsOpened;}
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsOpened
		{
			get
			{
				return (this.box == null || this.box.FadedIn) && 
					(this.box2 == null || this.box2.FadedIn);
			}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null && this.box2 == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			// sub menu call
			if(this.useSubMenu && origin == this.box2 && 
				this.current2 >= 0 && this.current2 < this.equipChoice.Length && 
				this.equips[this.current2] != null)
			{
				if(ORK.InputKeys.Get(this.subMenu.keyID).GetButton())
				{
					if(this.subMenu.Show(this.equips[this.current2], this, true))
					{
						origin.Audio.PlayAccept();
					}
					else
					{
						origin.Audio.PlayFail();
					}
					return true;
				}
				else
				{
					for(int i=0; i<this.subMenu.item.Length; i++)
					{
						if(this.subMenu.item[i].useKey && 
							ORK.InputKeys.Get(this.subMenu.item[i].keyID).GetButton())
						{
							if(this.subMenu.item[i].Use(this.equips[this.current2], this, null, true))
							{
								origin.Audio.PlayAccept();
							}
							else
							{
								origin.Audio.PlayFail();
							}
							return true;
						}
					}
				}
			}
			return false;
		}
		
		public override bool OnScreenCombatant
		{
			get{ return true;}
		}
		
		
		/*
		============================================================================
		Choice creation functions
		============================================================================
		*/
		private void CreateTypeList()
		{
			if(this.allTypes)
			{
				if(this.showEmptyTypes)
				{
					this.equipmentParts = new List<int>();
					for(int i=0; i<ORK.EquipmentParts.Count; i++)
					{
						this.equipmentParts.Add(i);
					}
				}
				else
				{
					this.equipmentParts = this.screen.Combatant.Equipment.GetAvailableParts();
				}
			}
			else
			{
				if(this.showEmptyTypes)
				{
					this.equipmentParts = new List<int>(this.availableTypeID);
				}
				else
				{
					this.equipmentParts = new List<int>();
					for(int i=0; i<this.availableTypeID.Length; i++)
					{
						if(this.screen.Combatant.Equipment[this.availableTypeID[i]].Available)
						{
							this.equipmentParts.Add(this.availableTypeID[i]);
						}
					}
				}
			}
			this.typeSorter.Sort(ref this.equipmentParts, ORKDataType.EquipmentPart);
		}
		
		private void CreateTypeChoices()
		{
			this.typeChoice = null;
			this.typeAction = null;
			
			if(this.screen.Combatant != null)
			{
				this.CreateTypeList();
				
				List<ChoiceContent> cc = new List<ChoiceContent>();
				List<int> ca = new List<int>();
				
				// back first
				if(this.addBackType && this.backFirstType)
				{
					ChoiceContent content = this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton);
					//content.Title = new GUIContent(" ");
					cc.Add(content);
					ca.Add(-1);
				}
				
				// types
				for(int i=0; i<this.equipmentParts.Count; i++)
				{
					if(!ORK.EquipmentParts.Get(this.equipmentParts[i]).hidden)
					{
						int partID = this.equipmentParts[i];
						this.screen.Combatant.Equipment[partID].GetRealPartID(ref partID);
						
						ChoiceContent content = this.screen.Combatant.Equipment[partID].Equipped ? 
							this.typeContentLayout.GetChoiceContent(this.screen.Combatant.Equipment[partID].Equipment, this.screen.Combatant) : 
							this.typeContentLayout.GetChoiceContent(this.emptyButton);
						content.Title = this.typeContentLayout.GetTitleContent(ORK.EquipmentParts.Get(this.equipmentParts[i]));
						
						content.Active = this.screen.Combatant.Equipment[this.equipmentParts[i]].Available && 
							!this.screen.Combatant.Equipment[this.equipmentParts[i]].Locked && 
							!this.screen.Combatant.Status.BlockEquipmentChange;
						
						// drag and drop
						if(this.screen.Combatant.Equipment[partID].Equipped)
						{
							content.isDragable = this.enableDrag;
							content.isDoubleClick = this.enableDoubleClick;
							content.isTooltip = this.enableTooltip;
							if(content.isDragable || content.isDoubleClick || content.isTooltip || 
								(this.displayLevelPoints && this.screen.Combatant.Equipment[partID].Equipment.CanLevelUp()))
							{
								content.drag = this.screen.Combatant.Equipment[partID].Equipment.GetDrag(this, this.screen.Combatant);
								if(content.drag != null && this.displayLevelPoints && 
									this.screen.Combatant.Equipment[partID].Equipment.CanLevelUp())
								{
									content.drag.LevelPointsDisplay = this.levelPointsElement;
								}
							}
						}
						
						cc.Add(content);
						ca.Add(this.equipmentParts[i]);
					}
				}
				
				// back last
				if(this.addBackType && !this.backFirstType)
				{
					ChoiceContent content = this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton);
					//content.Title = new GUIContent(" ");
					cc.Add(content);
					ca.Add(-1);
				}
				
				this.typeChoice = cc.ToArray();
				this.typeAction = ca.ToArray();
			}
		}
		
		private void CreateEquipChoices()
		{
			this.equips = null;
			this.equipChoice = null;
			
			if(this.screen.Combatant != null)
			{
				// weapons/armors
				if(this.current >= 0 && this.current < this.typeAction.Length && 
					this.typeAction[this.current] != -1)
				{
					this.equips = this.screen.Combatant.Inventory.GetEquipmentByPart(this.typeAction[this.current]);
				}
				else if(this.addBack || this.addUnequip)
				{
					this.equips = new List<EquipShortcut>();
				}
				
				if(this.equips != null)
				{
					this.contentSorter.Sort(ref this.equips);
					
					List<ChoiceContent> cc = new List<ChoiceContent>();
					bool unequipAdded = false;
					
					for(int i=0; i<this.equips.Count; i++)
					{
						if(this.equips[i] != null && 
							(this.allEquipment || this.equips[i].CanUse(this.screen.Combatant, false)))
						{
							ChoiceContent content = this.contentLayout.GetChoiceContent(this.equips[i], this.screen.Combatant);
							
							if(this.allEquipment)
							{
								content.Active = this.equips[i].CanUse(this.screen.Combatant, false) && 
									!this.screen.Combatant.Status.BlockEquipmentChange;
							}
							else
							{
								content.Active = !this.screen.Combatant.Status.BlockEquipmentChange;
							}
							
							if(this.showEquipPortraits && this.equips[i].HasPortrait())
							{
								content.portrait = this.equips[i].GetPortrait();
							}
							
							// drag and drop
							content.isDragable = this.equipEnableDrag;
							content.isDoubleClick = this.equipEnableDoubleClick;
							content.isTooltip = this.equipEnableTooltip;
							if(content.isDragable || content.isDoubleClick || content.isTooltip || 
								(this.displayLevelPointsList && this.equips[i].CanLevelUp()))
							{
								content.drag = this.equips[i].GetDrag(this, this.screen.Combatant);
								if(content.drag != null && this.displayLevelPointsList && 
									this.equips[i].CanLevelUp())
								{
									content.drag.LevelPointsDisplay = this.levelPointsElementList;
								}
							}
							cc.Add(content);
						}
						else
						{
							this.equips.RemoveAt(i--);
						}
					}
					
					// back first
					if(this.addBack && this.addUnequip && this.backFirst && this.unequipFirst && 
						this.unequipBeforeBack)
					{
						ChoiceContent content = this.contentLayout.GetChoiceContent(ORK.MenuSettings.unequipButton);
						content.Active = this.current >= 0 && this.current < this.typeAction.Length && 
							this.typeAction[this.current] != -1 && 
							!this.screen.Combatant.Status.BlockEquipmentChange && 
							this.screen.Combatant.Equipment[this.typeAction[this.current]].Available && 
							!this.screen.Combatant.Equipment[this.typeAction[this.current]].Locked && 
							(this.screen.Combatant.Equipment[this.typeAction[this.current]].Equipped || 
								this.screen.Combatant.Equipment[this.typeAction[this.current]].Linked);
						cc.Insert(0, content);
						this.equips.Insert(0, new EquipShortcut(EquipSet.None, 0, 0, 0));
						unequipAdded = true;
					}
					if(this.addBack && this.backFirst)
					{
						cc.Insert(0, this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.equips.Insert(0, null);
					}
					if(this.addUnequip && this.unequipFirst && !unequipAdded)
					{
						ChoiceContent content = this.contentLayout.GetChoiceContent(ORK.MenuSettings.unequipButton);
						content.Active = this.current >= 0 && this.current < this.typeAction.Length && 
							this.typeAction[this.current] != -1 && 
							!this.screen.Combatant.Status.BlockEquipmentChange && 
							this.screen.Combatant.Equipment[this.typeAction[this.current]].Available && 
							!this.screen.Combatant.Equipment[this.typeAction[this.current]].Locked && 
							(this.screen.Combatant.Equipment[this.typeAction[this.current]].Equipped || 
								this.screen.Combatant.Equipment[this.typeAction[this.current]].Linked);
						cc.Insert(0, content);
						this.equips.Insert(0, new EquipShortcut(EquipSet.None, 0, 0, 0));
						unequipAdded = true;
					}
					
					// back last
					if(this.addBack && this.addUnequip && !this.backFirst && !this.unequipFirst && 
						this.unequipBeforeBack)
					{
						ChoiceContent content = this.contentLayout.GetChoiceContent(ORK.MenuSettings.unequipButton);
						content.Active = this.current >= 0 && this.current < this.typeAction.Length && 
							this.typeAction[this.current] != -1 && 
							!this.screen.Combatant.Status.BlockEquipmentChange && 
							this.screen.Combatant.Equipment[this.typeAction[this.current]].Available && 
							!this.screen.Combatant.Equipment[this.typeAction[this.current]].Locked && 
							(this.screen.Combatant.Equipment[this.typeAction[this.current]].Equipped || 
								this.screen.Combatant.Equipment[this.typeAction[this.current]].Linked);
						cc.Add(content);
						this.equips.Add(new EquipShortcut(EquipSet.None, 0, 0, 0));
						unequipAdded = true;
					}
					if(this.addBack && !this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.equips.Add(null);
					}
					if(this.addUnequip && !this.unequipFirst && !unequipAdded)
					{
						ChoiceContent content = this.contentLayout.GetChoiceContent(ORK.MenuSettings.unequipButton);
						content.Active = this.current >= 0 && this.current < this.typeAction.Length && 
							this.typeAction[this.current] != -1 && 
							!this.screen.Combatant.Status.BlockEquipmentChange && 
							this.screen.Combatant.Equipment[this.typeAction[this.current]].Available && 
							!this.screen.Combatant.Equipment[this.typeAction[this.current]].Locked && 
							(this.screen.Combatant.Equipment[this.typeAction[this.current]].Equipped || 
								this.screen.Combatant.Equipment[this.typeAction[this.current]].Linked);
						cc.Add(content);
						this.equips.Add(new EquipShortcut(EquipSet.None, 0, 0, 0));
						unequipAdded = true;
					}
					
					this.equipChoice = cc.ToArray();
				}
			}
		}
		
		
		/*
		============================================================================
		Screen functions
		============================================================================
		*/
		private IContentSimple GetPartContent(int index)
		{
			index = this.typeAction[index];
			if(index >= 0 && index < ORK.EquipmentParts.Count)
			{
				this.screen.Combatant.Equipment[index].GetRealPartID(ref index);
				
				if(this.screen.Combatant.Equipment[index].Equipped)
				{
					return this.screen.Combatant.Equipment[index].Equipment;
				}
				else
				{
					return ORK.EquipmentParts.Get(index);
				}
			}
			return null;
		}
		
		public override bool ShowFirstDescription()
		{
			if(this.box != null && this.typeChoice != null && 
				this.current >= 0 && this.current < this.typeChoice.Length)
			{
				this.screen.ShowDescription(
					this.typeChoice[this.current].description, 
					this.typeChoice[this.current].Content.text, 
					this.GetPartContent(this.current));
				return true;
			}
			if(this.box2 != null && this.equipChoice != null && 
				this.current2 >= 0 && this.current2 < this.equipChoice.Length)
			{
				this.screen.ShowDescription(
					this.equipChoice[this.current2].description, 
					this.equipChoice[this.current2].Content.text, 
					this.equips[this.current2]);
				return true;
			}
			return false;
		}
		
		public override bool FocusFirst()
		{
			if(this.box != null)
			{
				this.box.SetFocus();
				return true;
			}
			else if(this.box2 != null)
			{
				this.box2.SetFocus();
				return true;
			}
			return false;
		}
		
		public override bool IsFocused()
		{
			return (this.box != null && this.box.Focused) || 
				(this.box2 != null && this.box2.Focused);
		}
		
		public override void Refresh()
		{
			if(this.box != null)
			{
				this.ShowTypes();
			}
			if(this.box2 != null)
			{
				this.ShowEquips();
			}
		}
		
		public override void Show(MenuScreen s)
		{
			this.screen = s;
			this.CreateTypeList();
			this.tmpTypeID = this.equipmentParts.Count > 0 ? this.equipmentParts[0] : 0;
			
			if(MenuBoxDisplay.Same.Equals(this.display))
			{
				this.guiBoxID2 = this.guiBoxID;
			}
			
			this.screen.Combatant.Inventory.Changed += this.InventoryChanged;
			this.screen.Combatant.Changed += this.EquipmentChanged;
			
			this.Show();
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			old.Inventory.Changed -= this.InventoryChanged;
			old.Changed -= this.EquipmentChanged;
			
			this.screen.Combatant.Inventory.Changed += this.InventoryChanged;
			this.screen.Combatant.Changed += this.EquipmentChanged;
			
			this.Refresh();
		}
		
		public override void CloseImmediate()
		{
			this.screen.Combatant.Inventory.Changed -= this.InventoryChanged;
			this.screen.Combatant.Changed -= this.EquipmentChanged;
			
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
			if(this.box2 != null)
			{
				this.box2.SetOutDone();
				this.box2 = null;
			}
		}
		
		public override void Close()
		{
			this.screen.Combatant.Inventory.Changed -= this.InventoryChanged;
			this.screen.Combatant.Equipment.Changed -= this.EquipmentChanged;
			this.screen.Combatant.Changed -= this.EquipmentChanged;
			this.exitFlag = true;
			if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
			{
				this.box2.InitOut();
			}
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
		}
		
		public void InventoryChanged(Inventory inventory, 
			ItemDropType type, int id, int level, int quantity)
		{
			this.Refresh();
		}
		
		public void EquipmentChanged(Combatant combatant)
		{
			this.Refresh();
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			if(!this.screen.RememberSelection)
			{
				this.current = 0;
				this.current2 = 0;
			}
			
			this.ShowTypes();
			
			if(this.showEquipBox && 
				MenuBoxDisplay.Multi.Equals(this.display))
			{
				this.ShowEquips();
			}
			
			this.box.SetFocus();
			this.SelectionChanged(this.current, this.box);
		}
		
		public void FocusGained(GUIBox origin)
		{
			if(this.box == origin && !this.box.FadingOut && !this.box.FadedOut && 
				this.typeChoice != null && 
				this.current >= 0 && this.current < this.typeChoice.Length)
			{
				this.screen.ShowDescription(
					this.typeChoice[this.current].description, 
					this.typeChoice[this.current].Content.text, 
					this.GetPartContent(this.current));
				
				if(this.box2 != null && !this.box2.FadingOut && 
					MenuBoxDisplay.Sequence.Equals(this.display))
				{
					this.box2.InitOut();
				}
			}
			else if(this.box2 == origin && !this.box2.FadingOut && !this.box2.FadedOut && 
				this.equipChoice != null && 
				this.current2 >= 0 && this.current2 < this.equipChoice.Length)
			{
				this.screen.ShowDescription(
					this.equipChoice[this.current2].description, 
					this.equipChoice[this.current2].Content.text, 
					this.equips[this.current2]);
				
				if(this.current >= 0 && this.current < this.typeChoice.Length)
				{
					ORK.GUI.SelectedShortcut = new EquipPartWrapperShortcut(
						this.typeAction[this.current], this.equips[this.current2]);
				}
				else
				{
					ORK.GUI.SelectedShortcut = this.equips[this.current2];
				}
			}
		}
		
		public void FocusLost(GUIBox origin)
		{
			if(this.box2 == origin)
			{
				ORK.GUI.SelectedShortcut = null;
				if(!this.box2.FadingOut && 
					MenuBoxDisplay.Sequence.Equals(this.display))
				{
					this.box2.InitOut();
				}
			}
		}
		
		private void ShowTypes()
		{
			this.CreateTypeChoices();
			
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.inPause = this.screen.pauseGame;
				this.box.InitIn();
			}
			
			ValueHelper.Limit(ref this.current, 0, this.typeChoice.Length - 1);
			
			if(this.box.Content == null)
			{
				this.box.Content = new DialogueContent("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this, this.current);
			}
			else
			{
				((DialogueContent)this.box.Content).Update("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this.current, null, null);
			}
			if(this.box.Focused)
			{
				this.SelectionChanged(this.current, this.box);
			}
		}
		
		private void ShowEquips()
		{
			this.CreateEquipChoices();
			
			if(this.box2 == null || this.box2.FadingOut || this.box2.FadedOut)
			{
				this.box2 = ORK.GUIBoxes.Create(this.guiBoxID2);
				this.box2.inPause = this.screen.pauseGame;
				this.box2.InitIn();
			}
			
			if(this.equipChoice == null)
			{
				this.current2 = 0;
			}
			else
			{
				ValueHelper.Limit(ref this.current2, 0, this.equipChoice.Length - 1);
			}
			
			if(this.box2.Content == null)
			{
				this.box2.Content = new DialogueContent("", this.GetTitle(), 
					this.equipChoice, this, this.current2);
			}
			else
			{
				((DialogueContent)this.box2.Content).Update("", this.GetTitle(), 
					this.equipChoice, this.current2, null, null);
			}
			if(this.box2.Focused)
			{
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		private string GetTitle()
		{
			if(this.useTitle)
			{
				if(this.typeChoice != null && this.current >= 0 && 
					this.current < this.typeChoice.Length && 
					this.typeAction[this.current] != -1)
				{
					return this.title[ORK.Game.Language].Replace("%n", this.typeChoice[this.current].Content.text);
				}
				else
				{
					return this.title[ORK.Game.Language].Replace("%n", "");
				}
			}
			return "";
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.exitFlag)
			{
				if(this.box == origin)
				{
					this.box = null;
				}
				else if(this.box2 == origin)
				{
					this.box2 = null;
				}
				if(this.box == null && this.box2 == null)
				{
					this.exitFlag = false;
				}
			}
			else
			{
				// type switch to equips
				if(this.box == origin)
				{
					this.box = null;
					if(this.showEquipBox && 
						MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowEquips();
					}
				}
				// equips
				else if(this.box2 == origin)
				{
					this.box2 = null;
					if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowTypes();
					}
				}
			}
		}
		
		public override void CombatantChoiceClosed(bool canceled)
		{
			this.Refresh();
			if(this.box2 != null)
			{
				this.box2.SetFocus();
			}
		}
		
		public override void SubMenuClosed(bool canceled)
		{
			this.Refresh();
			if(this.box2 != null)
			{
				this.box2.SetFocus();
			}
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			// type
			if(this.box == origin && this.typeChoice != null && 
				index >= 0 && index < this.typeChoice.Length)
			{
				if(this.current != index)
				{
					this.SelectionChanged(index, origin);
				}
				
				this.current = index;
				
				if(this.typeAction[this.current] == -1)
				{
					this.Cancel(this.box);
				}
				else if(this.showEquipBox)
				{
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box2 = this.box;
						this.box = null;
						this.ShowEquips();
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box2.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.ShowEquips();
					}
				}
			}
			// equips
			else if(this.box2 == origin && this.equipChoice != null && 
				index >= 0 && index < this.equipChoice.Length)
			{
				this.current2 = index;
				// back or unequip
				if(this.equips[this.current2] == null || 
					EquipSet.None.Equals(this.equips[this.current2].Type))
				{
					// unequip 1st top
					if((this.current2 == 0 && 
						this.addUnequip && this.unequipFirst && 
						(!this.addBack || this.unequipBeforeBack)) || 
					// unequip 2nd top
						(this.current2 == 1 && 
						this.addBack && this.backFirst && 
						this.addUnequip && this.unequipFirst && !this.unequipBeforeBack) ||
					// unequip 2nd last
						(this.current2 == this.equipChoice.Length - 2 && 
						this.addBack && !this.backFirst && 
						this.addUnequip && !this.unequipFirst && this.unequipBeforeBack) || 
					// unequip 1st last
						(this.current2 == this.equipChoice.Length - 1 && 
						this.addUnequip && !this.unequipFirst && 
						(!this.addBack || this.backFirst || !this.unequipBeforeBack)))
					{
						this.screen.Combatant.Equipment.Unequip(this.typeAction[this.current], 
							this.screen.Combatant.Inventory, true);
					}
					this.Cancel(origin);
				}
				// equip
				else
				{
					this.screen.Combatant.Equipment.Equip(this.typeAction[this.current], 
						this.equips[this.current2], this.screen.Combatant.Inventory, true);
					this.Cancel(origin);
				}
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				if(this.typeChoice != null && 
					index >= 0 && index < this.typeChoice.Length)
				{
					this.screen.ShowDescription(
						this.typeChoice[index].description, 
						this.typeChoice[index].Content.text, 
						this.GetPartContent(index));
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				
				ORK.GUI.SelectedShortcut = null;
				
				this.current = index;
				if(this.showEquipBox && 
					MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowEquips();
				}
			}
			// equips
			else if(this.box2 == origin)
			{
				if(this.equipChoice != null && 
					index >= 0 && index < this.equipChoice.Length)
				{
					this.screen.ShowDescription(
						this.equipChoice[index].description, 
						this.equipChoice[index].Content.text, 
						this.equips[index]);
					
					if(this.current >= 0 && this.current < this.typeChoice.Length)
					{
						ORK.GUI.SelectedShortcut = new EquipPartWrapperShortcut(
							this.typeAction[this.current], this.equips[index]);
					}
					else
					{
						ORK.GUI.SelectedShortcut = this.equips[index];
					}
				}
				else
				{
					this.screen.ShowDescription("", "", null);
					ORK.GUI.SelectedShortcut = null;
				}
				this.current2 = index;
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.Cancel(origin);
		}
		
		private void Cancel(GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				this.screen.Close();
			}
			// equips
			else if(this.box2 == origin)
			{
				if(MenuBoxDisplay.Same.Equals(this.display))
				{
					this.box = this.box2;
					this.box2 = null;
					this.ShowTypes();
				}
				else if(MenuBoxDisplay.One.Equals(this.display))
				{
					this.box2.InitOut();
				}
				else if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.box.SetFocus();
				}
				else if(MenuBoxDisplay.Sequence.Equals(this.display))
				{
					this.box2.InitOut();
					this.box.SetFocus();
				}
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public void Dropped(DragInfo drag)
		{
			this.Refresh();
		}
		
		public bool DroppedOnCombatant(Combatant c, DragInfo drag)
		{
			if(this.dropGive && this.box == drag.BoxOrigin)
			{
				if(drag.User != c && 
					c.Inventory.GetAllowedCount(drag.Shortcut) != 0)
				{
					this.giveQuantity.Call(
						new QuantityData(this.screen.pauseGame, this, drag.Shortcut, 
							c.Inventory.GetAllowedQuantity(drag.Shortcut, -1), 
							c.Inventory.GetCount(drag.Shortcut), 
							0, drag.User.Inventory.GetMoney(0), drag.Shortcut.BuyPrice, QuantitySelectionMode.Give, 
							c.Inventory.Add, drag.User.Inventory.Remove));
				}
				return true;
			}
			else if(this.equipDropGive && this.box2 == drag.BoxOrigin)
			{
				if(drag.User != c && 
					c.Inventory.GetAllowedCount(drag.Shortcut) != 0)
				{
					this.equipGiveQuantity.Call(
						new QuantityData(this.screen.pauseGame, this, drag.Shortcut, 
							c.Inventory.GetAllowedQuantity(drag.Shortcut, -1), 
							c.Inventory.GetCount(drag.Shortcut), 
							0, drag.User.Inventory.GetMoney(0), drag.Shortcut.BuyPrice, QuantitySelectionMode.Give, 
							c.Inventory.Add, drag.User.Inventory.Remove));
				}
				return true;
			}
			else if(drag.UseOn(c, true))
			{
				return true;
			}
			return false;
		}
		
		public bool DroppedToWorld(Vector3 position, DragInfo drag)
		{
			if(drag.Shortcut != null && drag.Shortcut.IsDropable())
			{
				if(this.dropToWorld && this.box == drag.BoxOrigin)
				{
					this.dropQuantity.Call(
						new QuantityData(this.screen.pauseGame, this, drag.Shortcut, drag.Shortcut.Quantity, 
							drag.User.Inventory.GetCount(drag.Shortcut), 
							0, drag.User.Inventory.GetMoney(0), drag.Shortcut.BuyPrice, 
							QuantitySelectionMode.Drop, null, drag.User.Inventory.Drop));
					return true;
				}
				else if(this.equipDropToWorld && this.box2 == drag.BoxOrigin)
				{
					this.equipDropQuantity.Call(
						new QuantityData(this.screen.pauseGame, this, drag.Shortcut, drag.Shortcut.Quantity, 
							drag.User.Inventory.GetCount(drag.Shortcut), 
							0, drag.User.Inventory.GetMoney(0), drag.Shortcut.BuyPrice, 
							QuantitySelectionMode.Drop, null, drag.User.Inventory.Drop));
					return true;
				}
			}
			return false;
		}
		
		public void ChoiceDropped(int index, GUIBox origin, DragInfo drag)
		{
			if(drag.Shortcut is EquipShortcut)
			{
				if(this.box == origin && 
					index >= 0 && index < this.typeAction.Length && 
					this.typeAction[index] != -1)
				{
					if(drag.User != null)
					{
						drag.User.Equipment.Unequip(drag.Shortcut as EquipShortcut, drag.User.Inventory);
					}
					if(this.screen.Combatant.Equipment.Equip(this.typeAction[index], 
						drag.Shortcut as EquipShortcut, 
						drag.User != null ? drag.User.Inventory : null, true))
					{
						this.box.Content.Selection = index;
						this.current = index;
						
						if(MenuBoxDisplay.Sequence.Equals(this.display) && this.box2 != null)
						{
							this.box2.InitOut();
						}
						this.box.SetFocus();
					}
				}
				else if(this.box2 == origin && drag.User != null)
				{
					drag.User.Equipment.Unequip(drag.Shortcut as EquipShortcut, drag.User.Inventory);
				}
			}
			else if(drag.Shortcut is ItemShortcut && this.box2 == origin)
			{
				if(drag.User == null)
				{
					this.screen.Combatant.Inventory.Add(drag.Shortcut, true, true);
				}
				else if(drag.User.Inventory != this.screen.Combatant.Inventory)
				{
					drag.User.Inventory.Remove(drag.Shortcut, true, true);
					this.screen.Combatant.Inventory.Add(drag.Shortcut, true, true);
				}
			}
		}
		
		
		/*
		============================================================================
		Quantity callback functions
		============================================================================
		*/
		public void QuantityCallback(IShortcut shortcut, int quantity, QuantitySelectionMode mode)
		{
			if(quantity > 0 && shortcut is EquipShortcut)
			{
				this.screen.Combatant.Equipment.Unequip(shortcut as EquipShortcut, null);
			}
		}
	}
}
