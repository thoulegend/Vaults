
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Status Value Upgrade", "Displays a combatant's status values and available upgrades.", "")]
	public class StatusValueUpgradeMenuPart : BaseMenuPart, IChoice
	{
		[ORKEditorHelp("Close After Use", "Close this menu screen after upgrading a status value.", "")]
		public bool closeAfter = false;
		
		[ORKEditorHelp("Don't Return", "Don't return to previously opened menu screens when " +
			"closing the screen after upgrading a status value.", "")]
		[ORKEditorLayout("closeAfter", true, endCheckGroup=true)]
		public bool closeAfterNoReturn = false;
		
		
		// status value settings
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the status values.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID2 = 0;
		
		// options
		[ORKEditorHelp("Show Upgradeable", "Show upgradeable status values " +
			"(i.e. upgrade available and useable).", "")]
		[ORKEditorInfo(separator=true)]
		public bool addUpgradeable = true;
		
		[ORKEditorHelp("Show Not Upgradeable", "Show not upgradeable status value " +
			"(i.e. upgrade available but not useable due to costs, but the requirements are valid).", "")]
		public bool addNotUpgradeable = true;
		
		[ORKEditorHelp("Show No Upgrade Req.", "Show status values without available upgrades " +
			"(i.e. no upgrade available due to requirements).", "")]
		public bool addNoUpgradeReq = true;
		
		[ORKEditorHelp("Show No Upgrade", "Show status values without available upgrades " +
			"(i.e. no upgrade available at all).", "")]
		public bool addNoUpgrade = true;
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the status value list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBack = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBack", true, endCheckGroup=true)]
		public bool backFirst = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = combatante name"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		// tooltip
		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a menu item.", "")]
		[ORKEditorInfo(separator=true)]
		public bool enableTooltip = false;
		
		// layout
		[ORKEditorInfo("Content Layout", "Define the layout of the status value buttons.\n" +
			"The info text (%) displays the current value of the status value.", "", 
			endFoldout=true)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.LevelUpCost);
		
		// special layouts
		[ORKEditorHelp("Advanced Layout", "Define different content layouts for upgradeable, " +
			"not upgradeable (due to requirements) and no upgrade available.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useAdvancedLayout = false;
		
		[ORKEditorInfo("Upgradeable Content Layout", 
			"Define the layout of the upgradeable status value buttons.\n" +
			"Used for status values that can be upgraded.\n" +
			"The info text (%) displays the current value of the status value.", "", 
			endFoldout=true)]
		[ORKEditorLayout("useAdvancedLayout", true, autoInit=true, 
			constTypes=new System.Type[] {typeof(ContentLayoutType), typeof(ContentLayoutInfoType)}, 
			constValues=new System.Object[] {ContentLayoutType.Both, ContentLayoutInfoType.LevelUpCost})]
		public ContentLayout upgradeableContentLayout;
		
		[ORKEditorInfo("Not Upgradeable Content Layout", 
			"Define the layout of the not upgradeable (costs) status value buttons.\n" +
			"Used for status values with upgrades available, but can't be upgraded due to costs.\n" +
			"The info text (%) displays the current value of the status value.", "", 
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true, 
			constTypes=new System.Type[] {typeof(ContentLayoutType), typeof(ContentLayoutInfoType)}, 
			constValues=new System.Object[] {ContentLayoutType.Both, ContentLayoutInfoType.LevelUpCost})]
		public ContentLayout notUpgradeableContentLayout;
		
		[ORKEditorInfo("No Upgrade Req. Content Layout", 
			"Define the layout of the status value buttons with no available upgrade due to requirements.\n" +
			"Used for status values with upgrades, but can't be upgraded due to requirements.\n" +
			"The info text (%) displays the current value of the status value.", "", 
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true, 
			constTypes=new System.Type[] {typeof(ContentLayoutType), typeof(ContentLayoutInfoType)}, 
			constValues=new System.Object[] {ContentLayoutType.Both, ContentLayoutInfoType.LevelUpCost})]
		public ContentLayout noUpgradeReqContentLayout;
		
		[ORKEditorInfo("No Upgrade Content Layout", 
			"Define the layout of the status value buttons with no available upgrade.\n" +
			"Used for status values without any upgrades.\n" +
			"The info text (%) displays the current value of the status value.", "", 
			endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true, 
			constTypes=new System.Type[] {typeof(ContentLayoutType), typeof(ContentLayoutInfoType)}, 
			constValues=new System.Object[] {ContentLayoutType.Both, ContentLayoutInfoType.LevelUpCost})]
		public ContentLayout noUpgradeContentLayout;
		
		
		// learn question
		[ORKEditorHelp("Show Upgrade Question", "Show a question dialogue before upgrading a status value.", "")]
		[ORKEditorInfo("Upgrade Question Dialogue", "You can display a question dialogue to confirm " +
			"upgrading a status value when selecting it.\n" +
			"The info text (%) displays the current value of the status value.", "")]
		public bool showLearnQuestion = false;
		
		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLayout("showLearnQuestion", true, endCheckGroup=true, autoInit=true)]
		public ContentQuestionChoice learnQuestion;
		
		
		// ingame
		private GUIBox box;
		
		private int current = 0;
		
		private bool exitFlag = false;
		
		
		// upgrades
		private ChoiceContent[] statusChoice;
		
		private List<StatusValueLeafShortcut> upgrades;
		
		public StatusValueUpgradeMenuPart()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public override bool Controlable
		{
			get{ return this.IsOpened;}
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsOpened
		{
			get
			{
				return this.box == null || this.box.FadedIn;
			}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Choice creation functions
		============================================================================
		*/
		private void CreateChoices()
		{
			this.upgrades = null;
			this.statusChoice = null;
			
			if(this.screen.Combatant != null)
			{
				StatusDevelopment comDev = this.screen.Combatant.Setting.GetStatusDevelopment();
				StatusDevelopment classDev = ORK.Classes.Get(this.screen.Combatant.ClassID).GetStatusDevelopment();
				
				List<ChoiceContent> cc = new List<ChoiceContent>();
				this.upgrades = new List<StatusValueLeafShortcut>();
				
				for(int i=0; i<ORK.StatusValues.Count; i++)
				{
					if(this.screen.Combatant.Status[i].IsNormal())
					{
						// get upgrade
						StatusValueLeafShortcut shortcut = null;
						if(comDev != null)
						{
							shortcut = comDev.GetUpgrade(i, this.screen.Combatant);
						}
						if(classDev != null && 
							(shortcut == null || shortcut.Setting == null))
						{
							shortcut = classDev.GetUpgrade(i, this.screen.Combatant);
						}
						
						if((this.addNoUpgrade && shortcut.Setting == null) || 
							(this.addUpgradeable && shortcut.Setting != null && 
								shortcut.Setting.CanLearn(this.screen.Combatant)) || 
							(this.addNotUpgradeable && shortcut.Setting != null && 
								!shortcut.Setting.CheckCosts(this.screen.Combatant) && 
								shortcut.Setting.CheckRequirements(this.screen.Combatant)) || 
							(this.addNoUpgradeReq && shortcut.Setting != null && 
								!shortcut.Setting.CheckRequirements(this.screen.Combatant)))
						{
							ChoiceContent content = null;
							
							if(this.useAdvancedLayout)
							{
								// no upgrade available
								if(shortcut.Setting == null)
								{
									content = this.noUpgradeContentLayout.GetChoiceContent(shortcut, this.screen.Combatant);
								}
								else if(shortcut.Setting.CanLearn(this.screen.Combatant))
								{
									content = this.upgradeableContentLayout.GetChoiceContent(shortcut, this.screen.Combatant);
								}
								else if(shortcut.Setting.CheckRequirements(this.screen.Combatant))
								{
									content = this.notUpgradeableContentLayout.GetChoiceContent(shortcut, this.screen.Combatant);
								}
								else
								{
									content = this.noUpgradeReqContentLayout.GetChoiceContent(shortcut, this.screen.Combatant);
								}
							}
							else
							{
								content = this.contentLayout.GetChoiceContent(shortcut, this.screen.Combatant);
							}
							
							content.Active = shortcut.Setting != null && shortcut.Setting.CanLearn(this.screen.Combatant);
							
							// drag and drop, tooltip, level points display
							content.isTooltip = this.enableTooltip;
							if(content.isTooltip)
							{
								content.drag = shortcut.GetDrag(null, this.screen.Combatant);
							}
							cc.Add(content);
							this.upgrades.Add(shortcut);
						}
					}
				}
				
				// back first
				if(this.addBack)
				{
					if(this.backFirst)
					{
						cc.Insert(0, this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.upgrades.Insert(0, null);
					}
					else
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.upgrades.Add(null);
					}
				}
				
				this.statusChoice = cc.ToArray();
			}
		}
		
		
		/*
		============================================================================
		Screen functions
		============================================================================
		*/
		public override bool ShowFirstDescription()
		{
			if(this.box != null && this.statusChoice != null && 
				this.current >= 0 && this.current < this.statusChoice.Length)
			{
				this.screen.ShowDescription(
					this.statusChoice[this.current].description, 
					this.statusChoice[this.current].Content.text, 
					this.upgrades[this.current]);
				return true;
			}
			return false;
		}
		
		public override bool FocusFirst()
		{
			if(this.box != null)
			{
				this.box.SetFocus();
				return true;
			}
			return false;
		}
		
		public override bool IsFocused()
		{
			return this.box != null && this.box.Focused;
		}
		
		public override void Refresh()
		{
			if(this.box != null)
			{
				this.ShowUpgrades();
			}
		}
		
		public override void Show(MenuScreen s)
		{
			this.screen = s;
			this.screen.Combatant.Changed += this.CombatantChanged;
			
			this.Show();
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			old.Changed -= this.CombatantChanged;
			this.screen.Combatant.Changed += this.CombatantChanged;
			this.Refresh();
		}
		
		public override void CloseImmediate()
		{
			this.screen.Combatant.Changed -= this.CombatantChanged;
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
		}
		
		public override void Close()
		{
			this.screen.Combatant.Changed -= this.CombatantChanged;
			this.exitFlag = true;
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
		}
		
		public void CombatantChanged(Combatant c)
		{
			this.Refresh();
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			if(!this.screen.RememberSelection)
			{
				this.current = 0;
			}
			
			this.ShowUpgrades();
		}
		
		public void FocusGained(GUIBox origin)
		{
			if(this.box == origin && !this.box.FadingOut && !this.box.FadedOut && 
				this.statusChoice != null && 
				this.current >= 0 && this.current < this.statusChoice.Length)
			{
				this.screen.ShowDescription(
					this.statusChoice[this.current].description, 
					this.statusChoice[this.current].Content.text, 
					this.upgrades[this.current]);
			}
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		private void ShowUpgrades()
		{
			this.CreateChoices();
			
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID2);
				this.box.inPause = this.screen.pauseGame;
				this.box.InitIn();
			}
			
			if(this.statusChoice == null)
			{
				this.current = 0;
			}
			else
			{
				ValueHelper.Limit(ref this.current, 0, this.statusChoice.Length - 1);
			}
			
			if(this.box.Content == null)
			{
				this.box.Content = new DialogueContent("", this.GetTitle(), 
					this.statusChoice, this, this.current);
			}
			else
			{
				((DialogueContent)this.box.Content).Update("", this.GetTitle(), 
					this.statusChoice, this.current, null, null);
			}
			if(this.box.Focused)
			{
				this.SelectionChanged(this.current, this.box);
			}
		}
		
		private string GetTitle()
		{
			if(this.useTitle)
			{
				return this.title[ORK.Game.Language].Replace("%n", this.screen.Combatant.GetName());
			}
			return "";
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.exitFlag)
			{
				if(this.box == origin)
				{
					this.box = null;
					this.exitFlag = false;
				}
			}
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			if(this.box == origin && this.statusChoice != null && 
				index >= 0 && index < this.statusChoice.Length)
			{
				this.current = index;
				// cancel
				if(this.upgrades[this.current] == null)
				{
					this.Cancel(this.box);
				}
				// learn
				else
				{
					if(this.upgrades[this.current].Setting != null && 
						this.upgrades[this.current].Setting.CanLearn(this.screen.Combatant))
					{
						if(this.showLearnQuestion)
						{
							this.learnQuestion.Show(this.upgrades[this.current], 
								this.QuestionClosed, this.screen.Combatant);
						}
						else
						{
							this.upgrades[this.current].Setting.Learn(this.screen.Combatant);
							
							this.Refresh();
							if(this.closeAfter)
							{
								if(this.closeAfterNoReturn)
								{
									this.screen.Clear();
								}
								this.screen.Close();
							}
						}
					}
				}
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			if(this.box == origin)
			{
				if(this.statusChoice != null && 
					index >= 0 && index < this.statusChoice.Length)
				{
					this.screen.ShowDescription(
						this.statusChoice[index].description, 
						this.statusChoice[index].Content.text, 
						this.upgrades[index]);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				this.current = index;
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.Cancel(origin);
		}
		
		private void Cancel(GUIBox origin)
		{
			if(this.box == origin)
			{
				this.screen.Close();
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public void QuestionClosed(bool accepted)
		{
			if(this.box != null)
			{
				this.box.SetFocus();
			}
			if(accepted)
			{
				if(this.upgrades[this.current].Setting != null && 
						this.upgrades[this.current].Setting.CanLearn(this.screen.Combatant))
				{
					this.upgrades[this.current].Setting.Learn(this.screen.Combatant);
					
					this.Refresh();
					if(this.closeAfter)
					{
						if(this.closeAfterNoReturn)
						{
							this.screen.Clear();
						}
						this.screen.Close();
					}
				}
			}
		}
	}
}
