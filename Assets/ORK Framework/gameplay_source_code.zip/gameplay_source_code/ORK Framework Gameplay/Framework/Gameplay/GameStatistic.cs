
using UnityEngine;

namespace ORKFramework
{
	public class GameStatistic : BaseData, ISaveData
	{
		// enemies
		[ORKEditorHelp("Total Killed", "The sum of all killed enemies will be logged.", "")]
		[ORKEditorInfo(labelText="Enemy Statistics")]
		public bool logKilledEnemies = false;
		
		[ORKEditorHelp("Single Killed", "The number of killed enemies will be logged separated by enemy.", "")]
		public bool logSingleEnemies = false;
		
		
		// items
		[ORKEditorHelp("Total Used", "The sum of all used items will be logged.", "")]
		[ORKEditorInfo(separator=true, labelText="Item Statistics")]
		public bool logUsedItems = false;
		
		[ORKEditorHelp("Single Used", "The number of used items will be logged, separated by item.", "")]
		public bool logSingleItems = false;
		
		[ORKEditorHelp("Total Created", "The sum of all created items (using crafting recipes) will be logged.", "")]
		public bool logCreatedItems = false;
		
		[ORKEditorHelp("Single Created", "The number of created items (using crafting recipes) will be logged, separated by item.", "")]
		public bool logSingleCreated = false;
		
		
		// battles
		[ORKEditorHelp("Total Battles", "The sum of all battles will be logged.", "")]
		[ORKEditorInfo(separator=true, labelText="Battle Statistics")]
		public bool logBattles = false;
		
		[ORKEditorHelp("Won Battles", "The sum of battles won by the party will be logged.", "")]
		public bool logWonBattles = false;
		
		[ORKEditorHelp("Lost Battles", "The sum of battles lost by the party will be logged.", "")]
		public bool logLostBattles = false;
		
		[ORKEditorHelp("Escaped Battles", "The sum of battles where the party escaped will be logged.", "")]
		public bool logEscapedBattles = false;
		
		
		// custom
		[ORKEditorHelp("Custom", "Custom statistics will be logged.\n" +
			"Custom statistics can be added by using game events and battle animations.", "")]
		[ORKEditorInfo(separator=true, labelText="Custom Statistics")]
		public bool logCustom = false;
		
		
		// ingame
		// enemies
		private int killedEnemies = 0; // #*ke
		private int[] singleEnemies = new int[0]; // #*seX#
		
		// items
		private int usedItems = 0; // #*ui
		private int[] singleItems = new int[0]; // #*siX#
		private int createdItems = 0; // #*cr
		private int[] singleCreatedItems = new int[0]; // #*ciX#
		private int[] singleCreatedWeapons = new int[0]; // #*cwX#
		private int[] singleCreatedArmors = new int[0]; // #*caX#
		
		// battles
		private int battles = 0; // #*ba
		private int wonBattles = 0; // #*bw
		private int lostBattles = 0; // #*bl
		private int escapedBattles = 0; // #*be
		
		// custom
		private int[] custom = new int[0]; // #*cuX#
		
		public GameStatistic()
		{
			
		}
		
		public void Clear()
		{
			if(this.logKilledEnemies)
				this.killedEnemies = 0;
			if(this.logSingleEnemies)
				this.singleEnemies = new int[ORK.Combatants.Count];
			if(this.logUsedItems)
				this.usedItems = 0;
			if(this.logSingleItems)
				this.singleItems = new int[ORK.Items.Count];
			if(this.logUsedItems)
				this.createdItems = 0;
			if(this.logSingleItems)
				this.singleCreatedItems = new int[ORK.Items.Count];
			if(this.logSingleItems)
				this.singleCreatedWeapons = new int[ORK.Weapons.Count];
			if(this.logSingleItems)
				this.singleCreatedArmors = new int[ORK.Armors.Count];
			if(this.logBattles)
				this.battles = 0;
			if(this.logWonBattles)
				this.wonBattles = 0;
			if(this.logLostBattles)
				this.lostBattles = 0;
			if(this.logEscapedBattles)
				this.escapedBattles = 0;
			if(this.logCustom)
				this.custom = new int[0];
		}
		
		
		/*
		============================================================================
		Type functions
		============================================================================
		*/
		public void Clear(StatisticType type, int index)
		{
			if(StatisticType.TotalKilled.Equals(type))
			{
				this.killedEnemies = 0;
			}
			else if(StatisticType.SingleKilled.Equals(type))
			{
				if(index >= 0 && index < this.singleEnemies.Length)
				{
					this.singleEnemies[index] = 0;
				}
			}
			else if(StatisticType.TotalUsed.Equals(type))
			{
				this.usedItems = 0;
			}
			else if(StatisticType.SingleUsed.Equals(type))
			{
				if(index >= 0 && index < this.singleItems.Length)
				{
					this.singleItems[index] = 0;
				}
			}
			else if(StatisticType.TotalCreated.Equals(type))
			{
				this.createdItems = 0;
			}
			else if(StatisticType.SingleCreatedItem.Equals(type))
			{
				if(index >= 0 && index < this.singleCreatedItems.Length)
				{
					this.singleCreatedItems[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedWeapon.Equals(type))
			{
				if(index >= 0 && index < this.singleCreatedWeapons.Length)
				{
					this.singleCreatedWeapons[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedArmor.Equals(type))
			{
				if(index >= 0 && index < this.singleCreatedArmors.Length)
				{
					this.singleCreatedArmors[index] = 0;
				}
			}
			else if(StatisticType.TotalBattles.Equals(type))
			{
				this.battles = 0;
			}
			else if(StatisticType.WonBattles.Equals(type))
			{
				this.wonBattles = 0;
			}
			else if(StatisticType.LostBattles.Equals(type))
			{
				this.lostBattles = 0;
			}
			else if(StatisticType.EscapedBattles.Equals(type))
			{
				this.escapedBattles = 0;
			}
			else if(StatisticType.Custom.Equals(type))
			{
				if(index >= 0 && index < this.custom.Length)
				{
					this.custom[index] = 0;
				}
			}
		}
		
		public int Get(StatisticType type, int index)
		{
			if(StatisticType.TotalKilled.Equals(type))
			{
				return this.killedEnemies;
			}
			else if(StatisticType.SingleKilled.Equals(type))
			{
				if(index >= 0 && index < this.singleEnemies.Length)
				{
					return this.singleEnemies[index];
				}
			}
			else if(StatisticType.TotalUsed.Equals(type))
			{
				return this.usedItems;
			}
			else if(StatisticType.SingleUsed.Equals(type))
			{
				if(index >= 0 && index < this.singleItems.Length)
				{
					return this.singleItems[index];
				}
			}
			else if(StatisticType.TotalCreated.Equals(type))
			{
				return this.createdItems;
			}
			else if(StatisticType.SingleCreatedItem.Equals(type))
			{
				if(index >= 0 && index < this.singleCreatedItems.Length)
				{
					return this.singleCreatedItems[index];
				}
			}
			else if(StatisticType.SingleCreatedWeapon.Equals(type))
			{
				if(index >= 0 && index < this.singleCreatedWeapons.Length)
				{
					return this.singleCreatedWeapons[index];
				}
			}
			else if(StatisticType.SingleCreatedArmor.Equals(type))
			{
				if(index >= 0 && index < this.singleCreatedArmors.Length)
				{
					return this.singleCreatedArmors[index];
				}
			}
			else if(StatisticType.TotalBattles.Equals(type))
			{
				return this.battles;
			}
			else if(StatisticType.WonBattles.Equals(type))
			{
				return this.wonBattles;
			}
			else if(StatisticType.LostBattles.Equals(type))
			{
				return this.lostBattles;
			}
			else if(StatisticType.EscapedBattles.Equals(type))
			{
				return this.escapedBattles;
			}
			else if(StatisticType.Custom.Equals(type))
			{
				if(index >= 0 && index < this.custom.Length)
				{
					return this.custom[index];
				}
			}
			return 0;
		}
		
		
		/*
		============================================================================
		Text functions
		============================================================================
		*/
		public void GetStatisticText(ref string text)
		{
			if(text.Contains("#*"))
			{
				// enemies
				text = text.Replace(TextCode.Statistic_KilledTotal, this.GetKilledEnemies().ToString());
				
				int replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_KilledEnemy, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_KilledEnemy + replace + "#", this.GetKilledEnemy(replace).ToString());
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_KilledEnemy, 0);
				}
				
				// items
				text = text.Replace(TextCode.Statistic_UsedTotal, this.GetUsedItems().ToString());
				
				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_UsedItem, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_UsedItem + replace + "#", this.GetUsedItem(replace).ToString());
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_UsedItem, 0);
				}
				
				// created items
				text = text.Replace(TextCode.Statistic_CreatedTotal, this.GetCreatedItems().ToString());
				
				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedItem, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_CreatedItem + replace + "#", this.GetCreatedItem(replace).ToString());
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedItem, 0);
				}
				
				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedWeapon, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_CreatedWeapon + replace + "#", this.GetCreatedWeapon(replace).ToString());
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedWeapon, 0);
				}
				
				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedArmor, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_CreatedArmor + replace + "#", this.GetCreatedArmor(replace).ToString());
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedArmor, 0);
				}
				
				// battles
				text = text.Replace(TextCode.Statistic_BattlesTotal, this.GetBattles().ToString());
				text = text.Replace(TextCode.Statistic_BattlesWon, this.GetWonBattles().ToString());
				text = text.Replace(TextCode.Statistic_BattlesLost, this.GetLostBattles().ToString());
				text = text.Replace(TextCode.Statistic_BattlesEscaped, this.GetEscapedBattles().ToString());
				
				// custom
				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_Custom, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_Custom + replace + "#", this.GetCustom(replace).ToString());
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_Custom, 0);
				}
			}
		}
		
		
		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public void EnemyKilled(int id)
		{
			if(this.logKilledEnemies)
			{
				this.killedEnemies++;
			}
			if(this.logSingleEnemies && id < this.singleEnemies.Length)
			{
				this.singleEnemies[id]++;
			}
		}
		
		public int GetKilledEnemies()
		{
			return this.killedEnemies;
		}
		
		public int GetKilledEnemy(int id)
		{
			if(id < this.singleEnemies.Length)
			{
				return this.singleEnemies[id];
			}
			else
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Item functions
		============================================================================
		*/
		public void ItemUsed(int id)
		{
			if(this.logUsedItems)
			{
				this.usedItems++;
			}
			if(this.logSingleItems && id < this.singleItems.Length)
			{
				this.singleItems[id]++;
			}
		}
		
		public int GetUsedItems()
		{
			return this.usedItems;
		}
		
		public int GetUsedItem(int id)
		{
			if(id < this.singleItems.Length)
			{
				return this.singleItems[id];
			}
			else
			{
				return 0;
			}
		}
		
		public void ItemCreated(int id, ItemDropType t)
		{
			if(this.logCreatedItems)
			{
				this.createdItems++;
			}
			if(this.logSingleCreated)
			{
				if(ItemDropType.Item.Equals(t) &&
					id < this.singleCreatedItems.Length)
				{
					this.singleCreatedItems[id]++;
				}
				else if(ItemDropType.Weapon.Equals(t) &&
					id < this.singleCreatedWeapons.Length)
				{
					this.singleCreatedWeapons[id]++;
				}
				else if(ItemDropType.Armor.Equals(t) &&
					id < this.singleCreatedArmors.Length)
				{
					this.singleCreatedArmors[id]++;
				}
			}
		}
		
		public int GetCreatedItems()
		{
			return this.createdItems;
		}
		
		public int GetCreatedItem(int id)
		{
			if(id < this.singleCreatedItems.Length)
				return this.singleCreatedItems[id];
			else
				return 0;
		}
		
		public int GetCreatedWeapon(int id)
		{
			if(id < this.singleCreatedWeapons.Length)
				return this.singleCreatedWeapons[id];
			else
				return 0;
		}
		
		public int GetCreatedArmor(int id)
		{
			if(id < this.singleCreatedArmors.Length)
				return this.singleCreatedArmors[id];
			else
				return 0;
		}
		
		
		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		public void BattleStarted()
		{
			if(this.logBattles)
				this.battles++;
		}
		
		public void BattleWon()
		{
			if(this.logWonBattles)
				this.wonBattles++;
		}
		
		public void BattleLost()
		{
			if(this.logLostBattles)
				this.lostBattles++;
		}
		
		public void BattleEscaped()
		{
			if(this.logEscapedBattles)
				this.escapedBattles++;
		}
		
		public int GetBattles()
		{
			return this.battles;
		}
		
		public int GetWonBattles()
		{
			return this.wonBattles;
		}
		
		public int GetLostBattles()
		{
			return this.lostBattles;
		}
		
		public int GetEscapedBattles()
		{
			return this.escapedBattles;
		}
		
		
		/*
		============================================================================
		Custom functions
		============================================================================
		*/
		public void CustomChanged(int index, int add)
		{
			if(this.logCustom && index >= 0)
			{
				if(index >= this.custom.Length)
				{
					int[] tmp = this.custom;
					this.custom = new int[index + 1];
					System.Array.Copy(tmp, this.custom, tmp.Length);
				}
				this.custom[index] += add;
			}
		}
		
		public int GetCustom(int index)
		{
			if(index >= 0 && index < this.custom.Length)
				return this.custom[index];
			else
				return 0;
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			// enemies
			data.Set("killedEnemies", this.killedEnemies);
			data.Set("singleEnemies", this.singleEnemies);
			
			// items
			data.Set("usedItems", this.usedItems);
			data.Set("singleItems", this.singleItems);
			data.Set("createdItems", this.createdItems);
			data.Set("singleCreatedItems", this.singleCreatedItems);
			data.Set("singleCreatedWeapons", this.singleCreatedWeapons);
			data.Set("singleCreatedArmors", this.singleCreatedArmors);
			
			// battles
			data.Set("battles", this.battles);
			data.Set("wonBattles", this.wonBattles);
			data.Set("lostBattles", this.lostBattles);
			data.Set("escapedBattles", this.escapedBattles);
			
			// custom
			data.Set("custom", this.custom);
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				// enemies
				data.Get("killedEnemies", ref this.killedEnemies);
				data.Get("singleEnemies", out this.singleEnemies);
				
				// items
				data.Get("usedItems", ref this.usedItems);
				data.Get("singleItems", out this.singleItems);
				data.Get("createdItems", ref this.createdItems);
				data.Get("singleCreatedItems", out this.singleCreatedItems);
				data.Get("singleCreatedWeapons", out this.singleCreatedWeapons);
				data.Get("singleCreatedArmors", out this.singleCreatedArmors);
				
				// battles
				data.Get("battles", ref this.battles);
				data.Get("wonBattles", ref this.wonBattles);
				data.Get("lostBattles", ref this.lostBattles);
				data.Get("escapedBattles", ref this.escapedBattles);
				
				// custom
				data.Get("custom", out this.custom);
			}
		}
	}
}
